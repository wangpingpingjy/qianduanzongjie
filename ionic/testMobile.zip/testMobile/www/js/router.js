 app.config(function($stateProvider,$urlRouterProvider){
		$stateProvider.state('tabs.login',{
			url:'/login',
			cache:false,
			templateUrl:'components/login/login.html',
			controller:'loginCtrl',
			resolve:{
				load:['$ocLazyLoad',function($ocLazyLoad){
					return $ocLazyLoad.load(['components/login/login.js','components/login/login.css']);
				}]
			}
		}).state('tabs', {
            url: "/tab",
            controller: 'baseCtrl',//控制器
            templateUrl: "components/base/base.html",//对应页面显示
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(["components/base/parentCtrl.js", "components/base/base.js"]);//加载所需文件
                }]
            }
        })
		$urlRouterProvider.otherwise("/tab");
    }
 )