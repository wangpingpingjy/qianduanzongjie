var store = {
		_cacheData:{},
		/**
		 * 添加一个临时存储的数据
		 * @param key:String
		 * @param data:Object
		 */
		setTempData:function(key,data){
			this._cacheData[key]=data;
		},
		/**
		 * 获取一个临时存储的数据
		 * @param key:String
		 */
		getTempData:function(key){
			 return this._cacheData[key];
		},
		/**
		 * 添加一个基于HMTL5本地存储的数据
		 * @param key:String
		 * @param data:Object
		 */
		setData:function(key,data){
			// 对最近登录信息的服务代码和用户名进行加密存储
			if(key === '$lastLoginInfo'){
				var dataClone = _.clone(data);
				dataClone.serviceCode = utils.encryptAES(dataClone.serviceCode, '0123456789abcdef', '0123456789abcdef');
				dataClone.account = utils.encryptAES(dataClone.account, '0123456789abcdef', '0123456789abcdef');
				window.localStorage.setItem(key,utils.jsonToString(dataClone));
			} else {
				window.localStorage.setItem(key,utils.jsonToString(data));
			}
			//this.setTempData('$localCache_'+key,data);
		},
		/**
		 * 获取一个基于HMTL5本地存储的数据
		 * @param key:String
		 */
		getData:function(key){

			var _data= null;
			try{
				_data=utils.stringToJson(window.localStorage.getItem(key));
				// 对最近登录信息的服务代码和用户名进行解密
				if(key === '$lastLoginInfo'){
					_data.serviceCode = utils.decryptAES(_data.serviceCode, '0123456789abcdef', '0123456789abcdef');
					_data.account = utils.decryptAES(_data.account, '0123456789abcdef', '0123456789abcdef');
				}
			}catch(ex){}

			return _data;
		},

		removeData:function(key){
			window.localStorage.removeItem(key);
		},

		setToken:function(token){
			this.setData('$token',token);
		},

		getToken:function(){
			return this.getData('$token');
		},
		setMyInfo:function(_data){
			this.setData('$myinfo',_data);
		},
		getMyInfo:function(noCache){
			return this.getData('$myinfo',noCache) || {};
		},
		setNationData:function(data){
			this.setData('$nation_data',data);
		},
		getNationData:function(){
			return this.getData("$nation_data");
		},
		setMyServiceCode:function(_data){
			this.setData('$myservicecode',_data);
		},
		getMyserviceCode:function(noCache){
			return this.getData('$myservicecode',noCache) || {};
		},
		/**
		 * 获取消息提醒类型
		 */
		getNoteType:function(){
			return this.getData("$Note_Type");
		},
		/**
		 * 获取消息提醒行程号
		 */
		getNoteJourneyNo:function(){
			return this.getData("$Note_JourneyNo");
		},
		/**
		 * 获取消息内容
		 */
		getNoteMessageContent:function(){
			return this.getData("$Note_MessageContent");
		},

		/**
		 * 获取是否是新启动应用
		 */
		getFirstFlag4Notification:function(){
			return this.getData("$firstFlag4Notification");
		},

		/**
		 * 判断系统语言
		 * 仅第一次加载系统的时候判断
		 */
		getLang:function(){
			var lang = this.getData('$lang') || navigator.language || navigator.browserLanguage|| 'zh-cn';
			if('zh-tw' == lang){
				
			}
			else if(/zh\-\w+/i.test(lang)){
				lang = "zh-cn";
			}else{
				lang = "en-us";
			}
			return lang;

		},
		setLang:function(name){
			this.setData('$lang',name);
			utils.lang = name;
		},
		/**
		 * 存储当前界面
		 */
		setPageCache:function(name){
			this.setData('$page-cache',name);
		},
		/**
		 * 获取当前页面值
		 */
		getPageCache:function(){
			return this.getData('$page-cache');
		},
		/**
		 * 存储临时用户信息
		 * @param data
		 */
		setTempUserInfo:function(data){
			this.setData('$tmpUserInfo',data);
		},
		/**
		 * 获取临时用户信息
		 */
		getTempUserInfo:function(){
			return this.getData('$tmpUserInfo');
		},
		/**
		 * 设置商旅服务商
		 * @param agentConfig
		 */
		setAgentConfig:function(agentConfig){
			this.setData('$agentConfig',agentConfig);
		},
		/**
		 * 获取商旅服务商
		 * @returns
		 */
		getAgentConfig:function(){
			return this.getData('$agentConfig');
		},
		/**
		 * 设置供应商标志
		 * @param flag
		 */
		setAgentFlag:function(flag){
			this.setData('$agentFlag', flag);
		},
		/**
		 * 获取是否有供应商
		 * @returns
		 */
		getAgentFlag:function(){
			return this.getData('$agentFlag');
		},
		/**
		 * 国际航班查询起降时间提示
		 */
		setNoticeData:function(data){
			this.setData('$noticeData',data);
		},
		/**
		 * 获取国际航班查询起降时间提示标志
		 */
		getNoticeData:function(){
			return this.getData('$noticeData');
		},
		/**
		 * 设置是否按的android实体返回键
		 */
		setAndroidBackBtn:function(flag){
			this.setData('$androidBackBtn',flag);
		},
		/**
		 * 获取是否android实体返回键是否按下值
		 */
		getAndroidBackBtn:function(){
			return this.getData('$androidBackBtn');
		},


		_getDeviceCode: function() {
			var _key = '$device-code';
			var _deviceToken = this.getData(_key);
			if (_deviceToken == null) {
				_deviceToken = utils.genGuid();
				this.setData(_key, _deviceToken);
			}
			return _deviceToken;
		},

		getDeviceCode:function(callback){
			if (window.plugins && window.plugins.pushMessage){
				if(utils.browerVersion('iOS')){
					if (callback) callback(window.device.token || this._getDeviceCode());
				}else if(utils.browerVersion('android')){
					window.plugins.pushMessage.getDeviceCode(function(_token) {
						if (callback) callback(_token || this._getDeviceCode());
					});
				}
			}else{
				if (callback) callback(this._getDeviceCode());
			}
		},
		getDeviceCode2:function(callback){
			if(utils.browerVersion('iOS')){
				this.getDeviceCode(callback);
			}else if(utils.browerVersion('android')){
				if(typeof Cordova == "undefined"){//android有些手机走这个方法，有些直接走下面那方法
					var exec = cordova.require('cordova/exec');
					exec(function(result){
							if(callback){
								callback(result);
							}
						}, null, 'PushMessage',"getDeviceToken", new Array({}));
				}
				else {
					Cordova.exec(function(result){
							if(callback){
								callback(result);
							}
						}, function(){}, 'PushMessage',"getDeviceToken", []);
				}
			}
		},
		/**
		* 获取手机IMEI号
		*/
		initDeviceCode:function(SGPlugin){
			var self = this;
			var deviceCode = "";
			if(utils.browerVersion('iOS')){
				this.getDeviceCode(function(code){
					deviceCode = code;
					self.setData("$device-code",deviceCode);
				});
			}else if(utils.browerVersion('android')){
				if(SGPlugin){
					SGPlugin.getDeviceCode(function(array){
						deviceCode = array[0];
						if(deviceCode == null || deviceCode == ''){//有些设备获取不到deviceCode
							deviceCode = this._getDeviceCode();
						}
						self.setData("$device-code",deviceCode);
					});
				}
				else {
					this.getDeviceCode2(function(array){
						deviceCode = array[0];
						if(deviceCode == null || deviceCode == ''){//有些设备获取不到deviceCode
							deviceCode = this._getDeviceCode();
						}
						self.setData("$device-code",deviceCode);
					});
				}
			}else {
				deviceCode = self._getDeviceCode();
			}
		},
		getOnlyDeviceCode:function(){
			return this.getData("$device-code");
		},
		/**
		 * _code 机场三字码，城市三字码
		 * _isAp boolean 是否是机场
		 */
		getAirportWithCode:function(_code,_isAp){
			//获取国内机场
			var airports = this.getData('$airports');
			var data = Enumerable.From(airports).Where(function(x){
				if(utils.ifEmpty(_isAp)){
					return x.code == _code;
				}
			}).ToArray()[0];
			//国内没有匹配数据在查找国际数据
			if(_.isEmpty(data)){
        var intlairport = store.getLang() == 'en-us' ? intlairportEn : intlairportCh;
				//机场三字码查询,按城市三字码查询
				data=Enumerable.From(intlairport).Where(function(x){
					if(utils.ifEmpty(_isAp)){
						return x.code == _code;
					}else {
						return x.code == _code && x.isAp == _isAp;
					}
				}).ToArray()[0];
				//国际机场数据需根据中英文进行从新转换
				if(data){
					//data = utils.convertCityAir(store,data);
				}
			}
			airports = null;
			return data;
		},
		getAirportWithCity:function(_city){
			var airports = this.getData('$airports');

			return Enumerable.From(airports).Where(function(x){
				return x.city == _city;
			}).ToArray();
		},

		//save the name of the train station
		setLastStation:function(station){
			var self = this;
			var lastData = self.getLastStation();
			var _exist = false;
			$.each(lastData,function(i){

				if(lastData[i].nameCN.toString() == station.nameCN){
					_exist = true;
				}
			});

			if(_exist) return;

			if(lastData.length > 5){
				lastData.pop();
			}

			lastData.unshift(station);
			this.setData("$last-station",lastData);

		},

		//get the station of the train
		getLastStation:function(){
			return this.getData("$last-station") || [];
		},




		/**
		save the code of airport that was clicked recently to the local store cache.
		**/
		setLastCity:function(_city){
			var self = this;
			var lastData = self.getLastCity();
			var _exist=false;
			$.each(lastData,function(){
				if(this.toString() == _city){
					_exist = true;
				}
			});
			if(_exist) return;
			if(lastData.length>5){
				lastData.pop();
			}

			lastData.unshift(_city);
			this.setData("$last-city",lastData);
		},
		/**
		Get the code array of airport that was clicked recently from the local store cache.
		**/
		getLastCity:function(){
			return this.getData("$last-city") || [];
		},

		/**
		 *	国籍
		**/
		setLastNation:function(_nation){
			var self = this;
			var lastData = self.getLastNation();
			var _exist=false;
			$.each(lastData,function(){
				if(this.toString() == _nation){
					_exist = true;
				}
			});
			if(_exist) return;
			if(lastData.length>5){
				lastData.pop();
			}

			lastData.unshift(_nation);
			this.setData("$last-nationality",lastData);
		},
		/**
		 *国籍
		**/
		getLastNation:function(){
			return this.getData("$last-nationality") || [];
		},

		/**
		 * 国际直接保存对象
		 */
		setLastIntlCity:function(_city){
			var self = this;
			var lastData = self.getLastIntlCity();
			var _exist=false;
			$.each(lastData,function(){
				if(_.isEqual(this.code, _city.code)){
					_exist = true;
				}
			});
			if(_exist) return;
			if(lastData.length>5){
				lastData.pop();
			}

			lastData.unshift(_city);
			this.setData("$last-intlCity",lastData);
		},
		/**
		 * 获取国际城市
		 */
		getLastIntlCity:function(){
			return this.getData("$last-intlCity") || [];
		},

		setOrderListIndex:function(index){
			this.setData('$orderlist-index',index);
		},
		getOrderListIndex:function(){
			return this.getData('$orderlist-index');
		},
		setReviewListIndex:function(index){
			this.setData('$reviewlist-index',index);
		},
		getReviewListIndex:function(){
			return this.getData('$reviewlist-index');
		},
		/**
		设置主题
		**/
		setLinkTheme:function(_themeStyle){
			var link = $('#ThemeStyle');

			if(_themeStyle == 'blue' || _themeStyle == 'green' || _themeStyle == ""){
				_themeStyle = 'default';
			}

			var cssLink = 'css/' + _themeStyle + ".css";
			link.attr('href',cssLink);
		},
		/**
		 * 存储当前主题
		 * @param _themeStyle
		 */
		setTheme:function(_themeStyle){
			this.setData('$theme',_themeStyle);
		},
		/**
		 * 获取主题
		 */
		getTheme:function(){
			return this.getData('$theme');
		},
		/**
		 * 添加关注
		 * @param favoriteList
		 */
		setFavoritelist:function(favoriteList){
			this.setData('$favourateList',favoriteList);
		},
		/**
		 * 获取关注
		 */
		getFavoritelist:function(){
			return this.getData('$favourateList');
		},
		/**
		 * 设置排序状态
		 * 0：时间升序  1：价格升序  2：时间降序   3：价格降序
		 * @param sortType
		 */
		setSortType:function(sortType){
			this.setData('$sortType',sortType);
		},
		/**
		 * 获取排序状态
		 */
		getSortType:function(){
			return this.getData('$sortType');
		},

		/**
		 * 存储航班公司信息
		 */
		setAirCompany:function(airCompanyList){
			this.setData('$airCompanyList',airCompanyList);
		},
		/**
		 * 获取航班公司信息
		 */
		getAirCompany:function(){
			return this.getData('$airCompanyList');
		},
		/**
		 * 存储常旅卡临时数据
		 */
		setTempOftenTripCardInfoList:function(tempList){
			this.setData('$tempOfterTridCardList', tempList);
		},
		/**
		 * 获取常旅卡临时数据
		 * @returns
		 */
		getTempOftenTripCardInfoList:function(){
			return this.getData('$tempOfterTridCardList');
		},
		/**
		 * 设置关注状态
		 */
		setFavoriteState:function(isFavorite){
			this.setData('$favoriteState',isFavorite);
		},


		/**
		 * 获取关注状态
		 * @returns
		 */
		getFavoriteState:function(){
			return this.getData('$favoriteState');
		},
		/**
		 * 设置秘钥数据
		 * @param data
		 */
		setKeyData:function(data){
			this.setData('$keyData', data);
		},
		/**
		 * 获取秘钥数据
		 */
		getKeyData:function(){
			return this.getData('$keyData');
		},
		/**
		 * 设置秘钥数据
		 * @param data
		 */
		setKeyData:function(data){
			this.setData('$keyData', data);
		},
		/**
		 * 西门子配送地址
		 */
		setDeliveryAddress:function(address){
			this.setData('$DeliveryAddress',address);
		},
		getDeliveryAddress:function(){
			return this.getData('$DeliveryAddress');
		},
		/**
		配送城市列表
		**/
		setDeliveryCity:function(city){
			this.setData('$DeliveryCity',city);
		},
		getDeliveryCity:function(){

			return this.getData('$DeliveryCity');
		},
		/**
		 * 运通用户 记录用户审批模式
		 */
		setApprModel:function(model){
			this.setData('$model', model);
		},
		getApprModel:function(){
			return this.getData('$model');
		},
		setNumber:function(number){
			this.setData('$number',number);
		},

		getNumber:function(){
			return this.getData('$number');
		},
		/**
		 * 记录应用启动时间点，判断释放load配置数据 3小时
		 */
		setTimePoint:function(point){
			this.setData('$time-point', point);
		},
		getTimePoint:function(){
			return this.getData('$time-point');
		},
		/**
		 *  10分钟间隔
		 */
		set10MinPoint:function(point){
			this.setData('$10min-point', point);
		},
		get10MinPoint:function(){
			return this.getData('$10min-point');
		},
		/**
		设置拒绝原因,key值为$reasonArray,最多5条
		**/
		setRefuseReason:function(_reasonStr){
			var self = this;

			if(!_reasonStr || _reasonStr == ''){
				return;
			}

			var reasonArray = self.getRefuseReason();
			if(_.isEmpty(reasonArray)){
				reasonArray = new Array();
				reasonArray.push(_reasonStr);
			}else{
				if(reasonArray.length >= 5){
					reasonArray.splice(0,1);
				}
				//循环判断是否有重复数据
				for(var i in reasonArray){
					if(!_.isEqual(reasonArray[i], _reasonStr)){
						reasonArray.push(_reasonStr);
					}
				}
			}
			self.setData('$reasonArray',reasonArray);
		},
		/**
		获取拒绝原因数组
		**/
		getRefuseReason:function(){
			var self = this;
			var reasonArray = self.getData('$reasonArray');
			if(!reasonArray){
				reasonArray = new Array();
			}
			return reasonArray;
		},
		/**
		缓存公司个性化配置项
		**/
		setAppConfig:function(_data){
			this.setData('$BlueSkyConfig',_data);
		},
		/**
		获取公司个性化配置项
		**/
		getAppConfig:function(){
			return this.getData('$BlueSkyConfig');
		},
		setCfgVersion:function(_data){
			this.setData('$cfgVersion',_data);
		},
		getCfgVersion:function(){
			return this.getData('$cfgVersion');
		},
		/**
		 * 切换中英文时，需根据语言环境更新国际机场历史数据
		 */
		updateIntAirHistory:function(){
			var intAirHis = _.clone(this.getLastIntlCity());
			this.setData("$last-intlCity",null);
			if(intAirHis){
				for(var i = 0, len =intAirHis.length;i<len;i++){
					var _intAir = intAirHis[i];
					if(_intAir && !_.isString(_intAir)){
            var intlairport = store.getLang() == 'en-us' ? intlairportEn : intlairportCh;
						var airObj = Enumerable.From(intlairport).Where(function (x) {
					    	return (x.code == _intAir.code && x.isAp == _intAir.isAp);
				    	}).ToArray()[0];
						if(airObj){
							airObj.filter_char ="#";
							airObj.kw = "#";
							var _air = airObj;//utils.convertCityAir(store,airObj);
							this.setLastIntlCity(_air);
							_air = null;
						}
						airObj = null;
					}
				}
			}
		},
		/**
		 * 根据三字码，获取国际热门城市
		 */
		updateIntAirHot:function(){
			var intAirHis = this.getData("$top-city-airport");
			var tempAry=[];
			$.each(intAirHis,function(){
				var that = this;
				var airObj = null;
				if(_.isString(that)){//判断是否是字符串，主要根据城市三字码，或城市对象
          var intlairport = store.getLang() == 'en-us' ? intlairportEn : intlairportCh;
					airObj = Enumerable.From(intlairport).Where(function (x) {
						    	return (x.code == that.toString() && x.isAp == "FALSE");
						    	}).ToArray()[0];
					if(airObj){
						var _air = airObj;//utils.convertCityAir(store,airObj);
						_air.filter_char ="*";
						_air.kw = "*";
						tempAry.push(_air);
						_air = null;
					}
					airObj = null;
				}else if(_.isObject(that)){//判断是否是城市对象，用于中英文切换后，中英数据同步问题
					var _air = that;//utils.convertCityAir(store,that);
					_air.filter_char ="*";
					_air.kw = "*";
					tempAry.push(_air);
					 _air = null;
				}

			});
			store.setData("$top-city-airport",tempAry);
			tempAry = null;
		},

		/**
		存储配置的火车站
		**/
		setAddingTrainStations:function(data){
			this.setData('$AddingTrainStations', data);
		},
		/**
			获取配置的火车站
		**/
		getAddingTrainStations:function(){
			return this.getData('$AddingTrainStations');
		},

		/**
			搜索关键字历史记录，按时间排序最多5条
		**/
		setLastSearchHis:function(localStoreName, searchTxt){
			var self = this;
			var lastData = self.getLastSearchHis(localStoreName);
			var _exist = false;
			$.each(lastData,function(){
				if(this.toString() == searchTxt){
					_exist = true;
				}
			});
			if(_exist) return;
			if(lastData.length > 4){
				lastData.pop();
			}

			lastData.unshift(searchTxt);
			this.setData(localStoreName, lastData);
		},
		/**
			获取搜索关键字历史记录
		**/
		getLastSearchHis:function(localStoreName){
			return this.getData(localStoreName) || [];
		}
	}
