var utils = {
    _self: this,
    router: null,
    lang: '',
    select_userTmpData: {
        searchVal: '',
        foundData: [],
        selectedData: []
    },
    /**
     app config infomation
     **/
    config: Config,
    userAgent: navigator.userAgent.toLowerCase(),
    /**
     perform a function async
     **/
    async: function (fn, delay) {
        if (!fn) return;
        delay = delay | 0;
        if (fn && fn._asyncTimer) {
            clearTimeout(fn._asyncTimer);
        }
        fn._asyncTimer = setTimeout(fn, delay);
        return fn._asyncTimer;
    },
    getBrowser: function () {
        var browser = {
            iPhone: this.userAgent.indexOf('iphone') > -1,
            iPad: this.userAgent.indexOf('ipad') > -1,
            iOS: this.userAgent.indexOf('ipad') > -1 || this.userAgent.indexOf('iphone') > -1,
            android: this.userAgent.indexOf('android') > -1,
            windowPhone: this.userAgent.indexOf('window') > -1
        };
        return browser;
    },
    /**
     system web brower version
     **/
    browerVersion: function (_version) {
        var result = false;
        if (_version == 'iphone') {
            result = this.userAgent.indexOf('iphone') > -1 ? true : false;
        } else if (_version == 'ipad') {
            result = this.userAgent.indexOf('ipad') > -1 ? true : false;
        } else if (_version == 'android') {
            result = this.userAgent.indexOf('android') > -1 ? true : false;
        } else if (_version == 'window') {
            result = this.userAgent.indexOf('window') > -1 ? true : false;
        } else if (_version == 'iOS') {
            if (this.userAgent.indexOf('iphone') > -1 || this.userAgent.indexOf('ipad') > -1) {
                result = true;
            } else {
                result = false;
            }
        }

        return result;
    },
    //比较日期大小 格式  yyyy-mm-dd
    compareDate: function (date1, date2) {
        date1 = date1.replace(/\-/gi, "/");
        date2 = date2.replace(/\-/gi, "/");
        var time1 = new Date(date1).getTime();
        var time2 = new Date(date2).getTime();

        if (time1 > time2) {
            return 1;//大于
        } else if (time1 == time2) {
            return 0;//相等
        } else {
            return -1;//小于
        }
    },
    /**
     * 阻止事件冒泡
     */
    stopBubble: function (e) {
        e = window.event || e;
        if (!e)return false;
        if (e.stopPropagation) {
            e.stopPropagation();
        }
        else {
            e.cancelBubble = true;
        }
        return false;
    },
    /**
     convert string to object of json
     **/
    stringToJson: function (str) {
        if (null == str || "" == str) {
            str = 'null';
        }
        if (window.JSON && window.JSON.parse) {
            return window.JSON.parse(str);
        }
    },
    /**
     convert object of json to string
     **/
    jsonToString: function (obj) {
        if (window.JSON && window.JSON.stringify) {
            return window.JSON.stringify(obj);
        }
    },


    /**
     * 生成一个GUID
     * @returns {String}
     */
    genGuid: function () {
        var S4 = function () {
            return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
        };
        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
    },

    setRouter: function (_router) {
        this.router = _router;
    },

    getRouter: function () {
        return this.router;
    },
    /**
     * 根据servicecode判断是否有符合需求
     * 优先级：先判断功能模块，然后serviceCode优先，serviceCode没有判断angentId
     * @param store
     * @returns {Boolean}
     */
    isServiceCodeNeed: function (store, str) {
        if (!store.getMyserviceCode()) {
            return false;
        }
        var myServiceCode = store.getMyserviceCode();
        var tempAgentId = null;
        var flag = false;
        switch (str) {
            case 1://显示全天加时间段
                var searchFlight = myServiceCode.FlightSearch_hour ? myServiceCode.FlightSearch_hour : null;
                tempAgentId = searchFlight ? searchFlight.agentId : '';//获取agentID
                myServiceCode = searchFlight ? (searchFlight.serviceCode ? searchFlight.serviceCode.toLocaleLowerCase() : '') : '';//获取需求serviceCode字符串
                break;
            case 2://flight_list
                tempAgentId = myServiceCode.FlightList_tripleprotocol ? myServiceCode.FlightList_tripleprotocol.agentId : '';//获取agentID
                myServiceCode = myServiceCode.FlightList_tripleprotocol ? (myServiceCode.FlightList_tripleprotocol.serviceCode ? myServiceCode.FlightList_tripleprotocol.serviceCode.toLocaleLowerCase() : '') : '';//获取需求serviceCode字符串
                break;
            case 3://order_info
                tempAgentId = myServiceCode.OrderInfo_issueNow ? myServiceCode.OrderInfo_issueNow.agentId : '';//获取agentID
                myServiceCode = myServiceCode.OrderInfo_issueNow ? (myServiceCode.OrderInfo_issueNow.serviceCode ? myServiceCode.OrderInfo_issueNow.serviceCode.toLocaleLowerCase() : '') : '';//获取需求serviceCode字符串
                break;
            case 4://flight_review_node
                tempAgentId = myServiceCode.FlightReviewNode_email ? myServiceCode.FlightReviewNode_email.agentId : '';//获取agentID
                myServiceCode = myServiceCode.FlightReviewNode_email ? (myServiceCode.FlightReviewNode_email.serviceCode ? myServiceCode.FlightReviewNode_email.serviceCode.toLocaleLowerCase() : '') : '';//获取需求serviceCode字符串
                break;
            case 5://setting
                tempAgentId = myServiceCode.Setting_readonly ? myServiceCode.Setting_readonly.agentId : '';//获取agentID
                myServiceCode = myServiceCode.Setting_readonly ? (myServiceCode.Setting_readonly.serviceCode ? myServiceCode.Setting_readonly.serviceCode.toLocaleLowerCase() : '') : '';//获取需求serviceCode字符串
                break;
            case 6://西门子需求
                tempAgentId = myServiceCode.OrderInfo_issue_book ? myServiceCode.OrderInfo_issue_book.agentId : '';//获取agentID
                myServiceCode = myServiceCode.OrderInfo_issue_book ? (myServiceCode.OrderInfo_issue_book.serviceCode ? myServiceCode.OrderInfo_issue_book.serviceCode.toLocaleLowerCase() : '') : '';
                break;

            case 7://搜索框提示为“搜索城市”。
                tempAgentId = myServiceCode.Airport_searchCity ? myServiceCode.Airport_searchCity.agentId : '';//获取agentID
                myServiceCode = myServiceCode.Airport_searchCity ? (myServiceCode.Airport_searchCity.serviceCode ? myServiceCode.Airport_searchCity.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 8://"未选择最低票价时的提示：您选择的航班不是最低票价，是否继续？
                tempAgentId = myServiceCode.FlightList_lowestPrice ? myServiceCode.FlightList_lowestPrice.agentId : '';//获取agentID
                myServiceCode = myServiceCode.FlightList_lowestPrice ? (myServiceCode.FlightList_lowestPrice.serviceCode ? myServiceCode.FlightList_lowestPrice.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 9://"提醒：因私请拨打4006786097预订
                tempAgentId = myServiceCode.FlightSearch_cwtPrivate ? myServiceCode.FlightSearch_cwtPrivate.agentId : '';//获取agentID
                myServiceCode = myServiceCode.FlightSearch_cwtPrivate ? (myServiceCode.FlightSearch_cwtPrivate.serviceCode ? myServiceCode.FlightSearch_cwtPrivate.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 10://修改密码界面，输入密码提示
                tempAgentId = myServiceCode.ChangePassword_newPwd_issue ? myServiceCode.ChangePassword_newPwd_issue.agentId : '';//获取agentID
                myServiceCode = myServiceCode.ChangePassword_newPwd_issue ? (myServiceCode.ChangePassword_newPwd_issue.serviceCode ? myServiceCode.ChangePassword_newPwd_issue.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 11://是否需要酒店功能
                tempAgentId = myServiceCode.ServiceCode_AddHotel ? myServiceCode.ServiceCode_AddHotel.agentId : '';//获取agentID
                myServiceCode = myServiceCode.ServiceCode_AddHotel ? (myServiceCode.ServiceCode_AddHotel.serviceCode ? myServiceCode.ServiceCode_AddHotel.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 12://以航班为中心 ，时间段最低低价
                tempAgentId = myServiceCode.FlightList_lowestprice ? myServiceCode.FlightList_lowestprice.agentId : '';//获取agentID
                myServiceCode = myServiceCode.FlightList_lowestprice ? (myServiceCode.FlightList_lowestprice.serviceCode ? myServiceCode.FlightList_lowestprice.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 13://訂單詳情頁不需要+添加按鈕
                tempAgentId = myServiceCode.OrderInfo_addButton ? myServiceCode.OrderInfo_addButton.agentId : '';//获取agentID
                myServiceCode = myServiceCode.OrderInfo_addButton ? (myServiceCode.OrderInfo_addButton.serviceCode ? myServiceCode.OrderInfo_addButton.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 14://訂單詳情頁是否需要座位餐食偏好
                tempAgentId = myServiceCode.OrderInfo_mealAndSeat ? myServiceCode.OrderInfo_mealAndSeat.agentId : '';//获取agentID
                myServiceCode = myServiceCode.OrderInfo_mealAndSeat ? (myServiceCode.OrderInfo_mealAndSeat.serviceCode ? myServiceCode.OrderInfo_mealAndSeat.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 15://shellchina前端需求修改：只显示预订并送审按钮，不显示预订按钮
                tempAgentId = myServiceCode.OrderInfo_toApprove ? myServiceCode.OrderInfo_toApprove.agentId : '';//获取agentID
                myServiceCode = myServiceCode.OrderInfo_toApprove ? (myServiceCode.OrderInfo_toApprove.serviceCode ? myServiceCode.OrderInfo_toApprove.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 16://嘉信的测试服务代码cwtchina，请改为只有一个预订按钮
                tempAgentId = myServiceCode.OrderInfo_OnlySaveBtn ? myServiceCode.OrderInfo_OnlySaveBtn.agentId : '';//获取agentID
                myServiceCode = myServiceCode.OrderInfo_OnlySaveBtn ? (myServiceCode.OrderInfo_OnlySaveBtn.serviceCode ? myServiceCode.OrderInfo_OnlySaveBtn.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 17://成本中心页是否增加选择公司的选择项
                tempAgentId = myServiceCode.CostCenter_corp ? myServiceCode.CostCenter_corp.agentId : '';//获取agentID
                myServiceCode = myServiceCode.CostCenter_corp ? (myServiceCode.CostCenter_corp.serviceCode ? myServiceCode.CostCenter_corp.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 18://订单详情页增加是否需要旅行目的选项  ihg需求
                tempAgentId = myServiceCode.OrderInfo_travelPurpose ? myServiceCode.OrderInfo_travelPurpose.agentId : '';//获取agentID
                myServiceCode = myServiceCode.OrderInfo_travelPurpose ? (myServiceCode.OrderInfo_travelPurpose.serviceCode ? myServiceCode.OrderInfo_travelPurpose.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 19://订单详情页增加成本中心和project no输入框，fls需求
                tempAgentId = myServiceCode.OrderInfo_ccinfoAndProjectNo ? myServiceCode.OrderInfo_ccinfoAndProjectNo.agentId : '';//获取agentID
                myServiceCode = myServiceCode.OrderInfo_ccinfoAndProjectNo ? (myServiceCode.OrderInfo_ccinfoAndProjectNo.serviceCode ? myServiceCode.OrderInfo_ccinfoAndProjectNo.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 20://审批通过后订单页面改为出票按钮
                tempAgentId = myServiceCode.OrderInfo_issue ? myServiceCode.OrderInfo_issue.agentId : '';//获取agentID
                myServiceCode = myServiceCode.OrderInfo_issue ? (myServiceCode.OrderInfo_issue.serviceCode ? myServiceCode.OrderInfo_issue.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 21://配送地址选项
                tempAgentId = myServiceCode.OrderInfo_delivery ? myServiceCode.OrderInfo_delivery.agentId : '';//获取agentID
                myServiceCode = myServiceCode.OrderInfo_delivery ? (myServiceCode.OrderInfo_delivery.serviceCode ? myServiceCode.OrderInfo_delivery.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 22://登陆界面判断新旧版本入口
                tempAgentId = myServiceCode.Login_newVersion ? myServiceCode.Login_newVersion.agentId : '';//获取agentID
                myServiceCode = myServiceCode.Login_newVersion ? (myServiceCode.Login_newVersion.serviceCode ? myServiceCode.Login_newVersion.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 23://退票详情页提示框
                tempAgentId = myServiceCode.refundhint ? myServiceCode.refundhint.agentId : '';//获取agentID
                myServiceCode = myServiceCode.refundhint ? (myServiceCode.refundhint.serviceCode ? myServiceCode.refundhint.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 24://航班列表默认排序
                tempAgentId = myServiceCode.FlightSort_price ? myServiceCode.FlightSort_price.agentId : '';//获取agentID
                myServiceCode = myServiceCode.FlightSort_price ? (myServiceCode.FlightSort_price.serviceCode ? myServiceCode.FlightSort_price.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 25://已当前选择的航班时间为中心，判断上下N小时最低价舱位
                tempAgentId = myServiceCode.FlightList_lowestCabin ? myServiceCode.FlightList_lowestCabin.agentId : '';//获取agentID
                myServiceCode = myServiceCode.FlightList_lowestCabin ? (myServiceCode.FlightList_lowestCabin.serviceCode ? myServiceCode.FlightList_lowestCabin.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 26://新版航班查询页是否显示成本中心
                tempAgentId = myServiceCode.HasCostCenter ? myServiceCode.HasCostCenter.agentId : '';//获取agentID
                myServiceCode = myServiceCode.HasCostCenter ? (myServiceCode.HasCostCenter.serviceCode ? myServiceCode.HasCostCenter.serviceCode.toLocaleLowerCase() : '') : '';
                break;
            case 27://新版个人资料页是否隐藏成本中心
                tempAgentId = myServiceCode.HiddenCCInfo ? myServiceCode.HiddenCCInfo.agentId : '';//获取agentID
                myServiceCode = myServiceCode.HiddenCCInfo ? (myServiceCode.HiddenCCInfo.serviceCode ? myServiceCode.HiddenCCInfo.serviceCode.toLocaleLowerCase() : '') : '';
                break;
        }
        var myInfoServiceCode = store.getMyInfo().serviceCode;//获取用户serviceCode
        myInfoServiceCode = myInfoServiceCode ? myInfoServiceCode.toLocaleLowerCase() : '';
        if (myServiceCode != null && myServiceCode != '') {//serviceCode不为空
            var serviceArray = [];
            serviceArray = myServiceCode.split(",");
            for (var i = 0; i < serviceArray.length; i++) {
                if (serviceArray[i] == myInfoServiceCode) {//包含
                    flag = true;
                    break;
                }
            }
//				if(myServiceCode.indexOf(myInfoServiceCode) >= 0){//包含
//					flag = true;
//				}
        }
//			else {//serviceCode为空
        if (tempAgentId != null && tempAgentId != '') {//agentId不为空
            var agentIdArray = [];
            agentIdArray = tempAgentId.split(",");
            var agentId = store.getMyInfo().agentId;
            for (var i = 0; i < agentIdArray.length; i++) {
                if (agentIdArray[i] == agentId) {//包含
                    flag = true;
                    break;
                }
            }
//					var agentId = store.getMyInfo().agentId;
//					if(tempAgentId == agentId || tempAgentId.indexOf(agentId) >= 0){//包含
//						flag = true;
//					}
        }
//			}
        return flag;
    },
    /**
     * 判断酒店机票开关
     * 【运通需求】其他只有酒店开关
     */
    isHotelAndPlaneNeed: function (store) {
        var self = this;
        var appConfig = store.getAppConfig();
        var data = {//以往需求，机票有，酒店默认无，根据后台判断
            'hotelFlag': false,
            'planeFlag': true,
            'trainFlag': false
        };
        var myInfo = store.getMyInfo();
        var productCodes = (!self.ifArrEmpty(myInfo.productCodes) && !self.ifEmpty(myInfo.productCodes)) ? myInfo.productCodes : null;//运通需求
        if (null == productCodes && (self.isServiceCodeNeed(store, 11) || (appConfig && appConfig.hotelConfig == 'Y'))) {//以往根据后台servicecode数据列表判断是否有酒店功能
            data.hotelFlag = true;
            return data;
        }
        //新需求：根据配置判断是否有酒店，有则再根据运通判断是否有酒店   updated by zjf 7-1
        else if (self.isServiceCodeNeed(store, 11) || (appConfig && appConfig.hotelConfig == 'Y')) {
            //运通处理机票酒店按钮显示
            if (productCodes && productCodes.length > 0) {
                data.planeFlag = false;//运通需求，机票酒店都默认为无，根据值判断
                for (var i = 0; i < productCodes.length; i++) {
                    var item = productCodes[i];//
                    if (item && item.productId == '1') {//机票
                        data.planeFlag = true;
                        continue;
                    }
                    if (item && item.productId == '5') {//酒店
                        //之前这个字段值为3为酒店，现与ssy确认5为酒店  update by zjf 6-10
                        data.hotelFlag = true;
                        continue;
                    }
                }
            }
        }
        return data;
    },
    genGuid: function () {

        var S4 = function () {

            return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);

        };

        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());

    },
    getPhoneName: function () {
        var phoneName = 'unknown';
        if (window.device) {
            phoneName = window.device.name;
        }
        return phoneName;
    },
    showMask: function () {
        $('body').append("<div class='loading-mask'></div>");
    },
    hideMask: function () {
        $('.loading-mask').remove();
    },
    showMessageCallback: function (text, delay, service, callback) {
        var self = this;
        self.showMask();
        $('body').append("<div class='loading'><div class='loading-gif'></div><div class='loading-title'>" + text + "</div></div>");
        var msgBox = $('.loading');

        var bodyHeight = document.body.clientHeight;
        var bodyWidth = document.body.clientWidth;

        msgBox.css('top', bodyHeight / 2 - (msgBox.height() / 2) + 'px');
        msgBox.css('left', bodyWidth / 2 - (msgBox.width() / 2) + 'px');

        self.async(function () {
            var message_mask = $("div.loading-mask");
            var message = $("div.loading");
            message_mask.unbind('vmousedown').bind('vmousedown', function (event) {
                self.hideMessage();
                service.abortAjax();
                if (typeof(callback) == "function") {
                    callback();
                }
                return false;
            }).unbind('vmousemove').bind('vmousemove', function (event) {
                return false;
            });
            message.unbind('vmousedown').bind('vmousedown', function (event) {
                self.hideMessage();
                service.abortAjax();
                if (typeof(callback) == "function") {
                    callback();
                }
                return false;
            }).unbind('vmousemove').bind('vmousemove', function (event) {
                return false;
            });
        }, 500);
        if (delay) {

            self.async(function () {

                self.hideMessage();

            }, delay);

        }
    },
    showMessage: function (text, delay, sgClient, flag, callback) {
        var self = this;
        self.showMask();

        $('body').append("<div class='loading'><div class='loading-gif'></div><div class='loading-title'>" + text + "</div></div>");
        var msgBox = $('.loading');

        var bodyHeight = document.body.clientHeight;
        var bodyWidth = document.body.clientWidth;

        msgBox.css('top', bodyHeight / 2 - (msgBox.height() / 2) + 'px');
        msgBox.css('left', bodyWidth / 2 - (msgBox.width() / 2) + 'px');

        self.async(function () {
            var message_mask = $(".loading-mask");
            var message = $(".loading");
            message_mask.unbind('vmousedown').bind('vmousedown', function (event) {
                if (flag) {
                    return false;
                }
                self.hideMessage();
                sgClient.abortAjax();
                if (callback) {
                    callback();
                }
                return false;
            }).unbind('vmousemove').bind('vmousemove', function (event) {
                return false;
            });
            message.unbind('vmousedown').bind('vmousedown', function (event) {
                if (flag) {
                    return false;
                }
                self.hideMessage();
                sgClient.abortAjax();
                if (callback) {
                    callback();
                }
                return false;
            }).unbind('vmousemove').bind('vmousemove', function (event) {
                return false;
            });
        }, 500);

    },
    _showMessage: function (text, delay, service) {
        var self = this;
        this.showMask();
        $('body').append("<div class='loading'><div class='loading-gif'></div><div class='loading-title'>" + text + "</div></div>");
        var msgBox = $('.loading');

        var bodyHeight = document.body.clientHeight;
        var bodyWidth = document.body.clientWidth;

        msgBox.css('top', bodyHeight / 2 - (msgBox.height() / 2) + 'px');
        msgBox.css('left', bodyWidth / 2 - (msgBox.width() / 2) + 'px');

        if (delay) {

            self.async(function () {

                self.hideMessage();

            }, delay);

        }
    },
    hideMessage: function () {
        $('.loading').remove();

        this.hideMask('message');

    },
    //开启消息推送服务
    generatePushClientAccount: function (data) {
        if (window.plugins && window.plugins.asmackPush) {
            window.plugins.asmackPush.generatePushClientAccount(data);
        }
    },
    isCordova: function () {
        return (window.navigator && window.navigator.notification && window.navigator.notification.alert && window.navigator.notification.confirm);
    },
    alertIsShow: false,
    _alert: function (option) {
        var self = this;
        self.alertIsShow = false;
        if (option.text && option.onOk && option.onCancel) {
            if (confirm(option.text))
                option.onOk();
            else
                option.onCancel();
        } else if (option.text && option.onOk && !option.onCancel) {
            alert(option.text);
            option.onOk();
        } else if (option.text) {
            alert(option.text);
        }
    },
    /**
     * 微信分享弹出框
     */
    showWeChatPanel: function (callback) {
        var self = this;
        var html = '<div class="f-sort-panel wechat-panel" style="display:none;">';
        html += '<ul id="wechatList" class="font-wechatList" >';
        html += '<li class="font-wechat font-border-li shareWechat"><span class="zjf-icon icon-share-wechat"></span><strong>' + self.lang.share_to_wechat + '</strong></li>';
        html += '<li class="font-wechat font-border-li shareFriend"><span class="zjf-icon icon-share-friend"></span><strong>' + self.lang.share_to_friend + '</strong></li>';
        html += '<li class="font-wechat-cancel font-border-li  shareCancel"><strong>' + self.lang.cancel + '</strong></li>';
        html += '</ul>';
        html += '</div>';
        $('body').append(html);
        var page = $('div[data-role="page"]');
        $.each(page.children(), function () {
            $(this).addClass('frosted-glass');
        });
        var panel = $('.wechat-panel');
        panel.show();
        //分享到微信
        $('.shareWechat').unbind('click').bind('click', function () {
            console.log(111112231212312);

            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            if (callback) {
                callback(1);
            }
        });
        //分享给朋友圈
        $('.shareFriend').unbind('click').bind('click', function () {
            console.log(111112231212312);

            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            if (callback) {
                callback(2);
            }
        });
        //取消
        $('.shareCancel').unbind('click').bind('click', function () {
            console.log(111112231212312);

            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
        });
    },

    /**
     * 火车筛选弹出框
     */
    showBookTrainListPanel: function (callback,bookCode) {
        var self = this;

        var show1 = callback[1].isSelected;
        var show2 = callback[2].isSelected;
        var show3 = callback[3].isSelected;
        var show4 = callback[4].isSelected;
        var show1class1 = "";
        var show1class2 = "";
        var show1class2 = "";
        var show2class1 = "";
        var show2class2 = "";
        var show3class1 = "";
        var show3class2 = "";
        var show4class1 = "";
        var show4class2 = "";

        var html = '<div  class="f-sort-panel book_panel boo_goList" style="display:none;">';
        html += '<ul id="book_wechatList" class="font-wechatList" >';
        // html += '<li class="font-wechat font-border-li method_sort" style="  text-align: left;color: #464749;font-size: 14px;padding-left: 30px;font-weight: normal;"><div style=" width: 80%;text-align: left;float: left;">' + self.lang.int_schema_method_sort + '</div> <i class="icon ion-android-checkbox-outline-blank theme-color show1class1 " style=" text-align: right;font-size: 25px !important;" ></i> <i class="icon ion-android-checkbox theme-color show1class2" style=" text-align: right;font-size: 25px !important;"></i></li>';
        html += '<li class="font-wechat font-border-li earlydepPanel" style="  text-align: left;color: #464749;font-size: 14px;padding-left: 30px;font-weight: normal;"><div style=" width: 80%;text-align: left;float: left;">' + self.lang.book_Earlydep + '</div> <i class="icon ion-android-checkbox-outline-blank theme-color show2class1" style=" text-align: right;font-size: 25px !important;" ></i> <i class="icon ion-android-checkbox theme-color show2class2" style=" text-align: right;font-size: 25px !important;"></i></li>';
        html += '<li class="font-wechat font-border-li laterdepPanel" style="  text-align: left;color: #464749;font-size: 14px;padding-left: 30px;font-weight: normal;"><div style=" width: 80%;text-align: left;float: left;">' + self.lang.book_Laterdep + '</div> <i class="icon ion-android-checkbox-outline-blank theme-color show3class1" style=" text-align: right;font-size: 25px !important;" ></i> <i class="icon ion-android-checkbox theme-color show3class2" style=" text-align: right;font-size: 25px !important;"></i></li>';
        html += '<li class="font-wechat font-border-li earlycostPanel" style="  text-align: left;color: #464749;font-size: 14px;padding-left: 30px;font-weight: normal;"><div style=" width: 80%;text-align: left;float: left;">' + self.lang.book_Earlycost + '</div> <i class="icon ion-android-checkbox-outline-blank theme-color show4class1" style=" text-align: right;font-size: 25px !important;"></i> <i class="icon ion-android-checkbox theme-color show4class2" style=" text-align: right;font-size: 25px !important;"></i></li>';

        html += '</ul>';
        html += '</div>';
        $('#book_train_list').append(html);
        var page = $('div[data-role="page"]');
        $.each(page.children(), function () {
            $(this).addClass('frosted-glass');
        });
        var panel = $('.book_panel');
        panel.show();

        if (show1) {
            $('.show1class1').css('display', 'none');
        } else {
            $('.show1class2').css('display', 'none');
        }
        if (show2) {
            $('.show2class1').css('display', 'none');
        } else {
            $('.show2class2').css('display', 'none');
        }
        if (show3) {
            $('.show3class1').css('display', 'none');
        } else {
            $('.show3class2').css('display', 'none');

        }
        if (show4) {
            $('.show4class1').css('display', 'none');
        } else {
            $('.show4class2').css('display', 'none');
        }


        $('.earlydepPanel').unbind('click').bind('click', function () {
            console.log('最早出发');

            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            if(callback[2].isSelected){
                callback[2].isSelected = false;
            } else {
                callback[2].isSelected = true;
            }
            if (callback) {
                bookCode(callback,2);
            }
        });

        $('.laterdepPanel').unbind('click').bind('click', function () {
            console.log('最晚出发');

            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            if(callback[3].isSelected){
                callback[3].isSelected = false;
            } else {
                callback[3].isSelected = true;
            }
            if (callback) {
                bookCode(callback,3);
            }
        });

        $('.earlycostPanel').unbind('click').bind('click', function () {
            console.log('耗时最短');

            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            if(callback[4].isSelected){
                callback[4].isSelected = false;
            } else {
                callback[4].isSelected = true;
            }
            if (callback) {
                bookCode(callback,4);
            }
        });

        //取消
        $('.boo_goList').unbind('click').bind('click', function () {
            console.log(111112231212312);

            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
        });
    },

    /**
     * 火车筛选车型弹出框
     */
    showBookTrainbook_all_type: function (callback,code) {
        var self = this;

        var show1 = callback[1].isSelected;
        var show2 = callback[2].isSelected;
        var show3 = callback[3].isSelected;
        var show4 = callback[4].isSelected;

        var show1class1 = "";
        var show1class2 = "";
        var show1class2 = "";
        var show2class1 = "";
        var show2class2 = "";
        var show3class1 = "";
        var show3class2 = "";
        var show4class1 = "";
        var show4class2 = "";

        var html = '<div  class="f-sort-panel wechat-panel goList" style="display:none;">';
        html += '<ul id="wechatList" class="font-wechatList" >';
        html += '<li class="font-wechat font-border-li method_sort" style="  text-align: left;color: #464749;font-size: 14px;padding-left: 30px;font-weight: normal;"><div style=" width: 80%;text-align: left;float: left;">' + self.lang.book_all_type + '</div> <i class="icon ion-android-checkbox-outline-blank theme-color show1class1 " style=" text-align: right;font-size: 25px !important;" ></i> <i class="icon ion-android-checkbox theme-color show1class2" style=" text-align: right;font-size: 25px !important;"></i></li>';
        html += '<li class="font-wechat font-border-li earlydep" style="  text-align: left;color: #464749;font-size: 14px;padding-left: 30px;font-weight: normal;"><div style=" width: 80%;text-align: left;float: left;">' + self.lang.showhighTrain + '</div> <i class="icon ion-android-checkbox-outline-blank theme-color show2class1" style=" text-align: right;font-size: 25px !important;" ></i> <i class="icon ion-android-checkbox theme-color show2class2" style=" text-align: right;font-size: 25px !important;"></i></li>';
        html += '<li class="font-wechat font-border-li laterdep" style="  text-align: left;color: #464749;font-size: 14px;padding-left: 30px;font-weight: normal;"><div style=" width: 80%;text-align: left;float: left;">' + self.lang.expressTrain + '</div> <i class="icon ion-android-checkbox-outline-blank theme-color show3class1" style=" text-align: right;font-size: 25px !important;" ></i> <i class="icon ion-android-checkbox theme-color show3class2" style=" text-align: right;font-size: 25px !important;"></i></li>';
        html += '<li class="font-wechat font-border-li earlycost" style="  text-align: left;color: #464749;font-size: 14px;padding-left: 30px;font-weight: normal;"><div style=" width: 80%;text-align: left;float: left;">' + self.lang.otherTrains + '</div> <i class="icon ion-android-checkbox-outline-blank theme-color show4class1" style=" text-align: right;font-size: 25px !important;"></i> <i class="icon ion-android-checkbox theme-color show4class2" style=" text-align: right;font-size: 25px !important;"></i></li>';

        html += '</ul>';
        html += '</div>';
        $('#book_train_list').append(html);
        var page = $('div[data-role="page"]');
        $.each(page.children(), function () {
            $(this).addClass('frosted-glass');
        });
        var panel = $('.wechat-panel');
        panel.show();

        if (show1) {
            $('.show1class1').css('display', 'none');
        } else {
            $('.show1class2').css('display', 'none');
        }
        if (show2) {
            $('.show2class1').css('display', 'none');
        } else {
            $('.show2class2').css('display', 'none');
        }
        if (show3) {
            $('.show3class1').css('display', 'none');
        } else {
            $('.show3class2').css('display', 'none');

        }
        if (show4) {
            $('.show4class1').css('display', 'none');
        } else {
            $('.show4class2').css('display', 'none');
        }

        //
        $('.method_sort').unbind('click').bind('click', function () {
            console.log('全部车型');

            panel.css('display', 'none');
            panel.remove();

            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            if(callback[1].isSelected){
                callback[1].isSelected = false;
            } else {
                callback[1].isSelected = true;
            }
            if (callback) {
                code(callback,1);
            }
        });

        $('.earlydep').unbind('click').bind('click', function () {
            console.log('高铁动车');

            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            if(callback[2].isSelected){
                callback[2].isSelected = false;
            } else {
                callback[2].isSelected = true;
            }
            if (callback) {
                code(callback,2);
            }
        });

        $('.laterdep').unbind('click').bind('click', function () {
            console.log('特快直达');

            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            if(callback[3].isSelected){
                callback[3].isSelected = false;
            } else {
                callback[3].isSelected = true;
            }
            if (callback) {
                code(callback,3);
            }
        });

        $('.earlycost').unbind('click').bind('click', function () {
            console.log('其他车型');

            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            if(callback[4].isSelected){
                callback[4].isSelected = false;
            } else {
                callback[4].isSelected = true;
            }
            if (callback) {
                code(callback,4);
            }
        });

        //取消
        $('.goList').unbind('click').bind('click', function () {
            console.log('取消');

            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
        });
    },




    /**
     * 火车票选座
     */
    showClickSeatSelection: function (callback,getSeatListData,getShowSeatListData,$ionicPopup,$state, $cacheFactory, code) {
        var self = this;

        var myCache = $cacheFactory.get('myAppCache') || $cacheFactory('myAppCache');//缓存对象

        var showNub =callback.passengerInfoList.length;

        var  showTitle = self.lang.please_choose +showNub +self.lang.book_select_seat;

        var html = '<div  class="f-sort-panel wechat-panel " style="display:none;">';
        html += '<ul id="wechatList" class="font-wechatList" >';

        html += '<li class="font-wechat font-border-li method_sort" style="  text-align: left;font-size: 14px;font-weight: normal;"><div id="goList" style="text-align: right;float: left;color: #3E7FEF;width: 15%;">' + self.lang.h_filter_cancle + '</div> <div style=" width: 70%;text-align: center;float: left;color: #616161;">' + showTitle + '</div> <div id="goListOK" style=" width: 15%;text-align: left;float: left;color: #3E7FEF;">' + self.lang.packing_list_luggage_quick_add_confirm + '</div>  </li>';

        html += '<li class="font-wechat font-border-li method_sort" style="  text-align: left;font-size: 12px;font-weight: normal; height:auto; padding-top:0px"><div  style="text-align: left; background:#FFF7DE; padding-left: 20px;">' + self.lang.book_showAlert + '</div> </li>';

        if(showNub>1){

            if( callback.selectedSeatPrice.nameEN =='First Class' ){
                html += '<li class="font-wechat font-border-li method_sort" style="  color: #ADADAD;font-size: 14px;font-weight: normal;background: #EDEDED;display: flex;font-size: 12px;"><div style=" width: 20%;text-align: right;float: left;">' + self.lang.book_window + '</div> <div id="seatA"  class="font-border-train-check font-border-train-SeatA" style="margin-left: 2%;"></div>  <div id="seatC" class="font-border-train-check font-border-train-SeatC" style="margin-right: 0px;"></div>  <div style=" text-align: center;float: left;width: 14%;">' +self.lang. book_Aisle + '</div> <div id="seatD" class="font-border-train-check font-border-train-SeatD" style=" text-align: left;float: left;"></div> <div id="seatF" class="font-border-train-check font-border-train-SeatF" style=" margin-right: 2%;"></div> <div style=" width: 20%;text-align: left;float: left;">' + self.lang.book_window + '</div> </li>';
                html += '<li class="font-wechat font-border-li method_sort" style="  color: #ADADAD;font-size: 14px;font-weight: normal;background: #EDEDED;display: flex;font-size: 12px;"><div style=" width: 20%;text-align: right;float: left;">' + self.lang.book_window + '</div> <div id="seat1A"  class="font-border-train-check font-border-train-SeatA" style="margin-left: 2%;"></div>  <div id="seat1C" class="font-border-train-check font-border-train-SeatC" style="margin-right: 0px;"></div>  <div style=" text-align: center;float: left;width: 14%;">' +self.lang. book_Aisle + '</div> <div id="seat1D" class="font-border-train-check font-border-train-SeatD" style=" text-align: left;float: left;"></div> <div id="seat1F" class="font-border-train-check font-border-train-SeatF" style=" margin-right: 2%;"></div> <div style=" width: 20%;text-align: left;float: left;">' + self.lang.book_window + '</div> </li>';

            } else  if(callback.selectedSeatPrice.nameEN =='Second Class'){
                html += '<li class="font-wechat font-border-li method_sort" style="  color: #ADADAD;font-size: 14px;font-weight: normal;background: #EDEDED;display: flex;font-size: 12px;"><div style=" width: 20%;text-align: right;float: left;">' + self.lang.book_window + '</div> <div id="seatA"  class="font-border-train-check font-border-train-SeatA" style="margin-left: 2%;"></div>  <div id="seatB" class="font-border-train-check font-border-train-SeatB"></div> <div id="seatC" class="font-border-train-check font-border-train-SeatC" style="margin-right: 0px;"></div>  <div style=" text-align: center;float: left;width: 14%;">' +self.lang. book_Aisle + '</div> <div id="seatD" class="font-border-train-check font-border-train-SeatD" style=" text-align: left;float: left;"></div> <div id="seatF" class="font-border-train-check font-border-train-SeatF" style=" margin-right: 2%;"></div> <div style=" width: 20%;text-align: left;float: left;">' + self.lang.book_window + '</div> </li>';
                html += '<li class="font-wechat font-border-li method_sort" style="  color: #ADADAD;font-size: 14px;font-weight: normal;background: #EDEDED;display: flex;font-size: 12px;"><div style=" width: 20%;text-align: right;float: left;">' + self.lang.book_window + '</div> <div id="seat1A"  class="font-border-train-check font-border-train-SeatA" style="margin-left: 2%;"></div>  <div id="seat1B" class="font-border-train-check font-border-train-SeatB"></div> <div id="seat1C" class="font-border-train-check font-border-train-SeatC" style="margin-right: 0px;"></div>  <div style=" text-align: center;float: left;width: 14%;">' +self.lang. book_Aisle + '</div> <div id="seat1D" class="font-border-train-check font-border-train-SeatD" style=" text-align: left;float: left;"></div> <div id="seat1F" class="font-border-train-check font-border-train-SeatF" style=" margin-right: 2%;"></div> <div style=" width: 20%;text-align: left;float: left;">' + self.lang.book_window + '</div> </li>';

            } else  if (callback.selectedSeatPrice.nameEN =='Business Class'){
                html += '<li class="font-wechat font-border-li method_sort" style="  color: #ADADAD;font-size: 14px;font-weight: normal;background: #EDEDED;display: flex;font-size: 12px;"><div style=" width: 20%;text-align: right;float: left;">' + self.lang.book_window + '</div> <div id="seatA"  class="font-border-train-check font-border-train-SeatA" style="margin-left: 2%;"></div>   <div id="seatC" class="font-border-train-check font-border-train-SeatC" style="margin-right: 0px;"></div>  <div style=" text-align: center;float: left;width: 14%;">' +self.lang. book_Aisle + '</div>  <div id="seatF" class="font-border-train-check font-border-train-SeatF" style=" margin-right: 2%;"></div> <div style=" width: 20%;text-align: left;float: left;">' + self.lang.book_window + '</div> </li>';
                html += '<li class="font-wechat font-border-li method_sort" style="  color: #ADADAD;font-size: 14px;font-weight: normal;background: #EDEDED;display: flex;font-size: 12px;"><div style=" width: 20%;text-align: right;float: left;">' + self.lang.book_window + '</div> <div id="seat1A"  class="font-border-train-check font-border-train-SeatA" style="margin-left: 2%;"></div>   <div id="seat1C" class="font-border-train-check font-border-train-SeatC" style="margin-right: 0px;"></div>  <div style=" text-align: center;float: left;width: 14%;">' +self.lang. book_Aisle + '</div>  <div id="seat1F" class="font-border-train-check font-border-train-SeatF" style=" margin-right: 2%;"></div> <div style=" width: 20%;text-align: left;float: left;">' + self.lang.book_window + '</div> </li>';

            }
        } else {

            if( callback.selectedSeatPrice.nameEN =='First Class' ){
                html += '<li class="font-wechat font-border-li method_sort" style="  color: #ADADAD;font-size: 14px;font-weight: normal;background: #EDEDED;display: flex;font-size: 12px;"><div style=" width: 20%;text-align: right;float: left;">' + self.lang.book_window + '</div> <div id="seatA"  class="font-border-train-check font-border-train-SeatA" style="margin-left: 2%;"></div>  <div id="seatC" class="font-border-train-check font-border-train-SeatC" style="margin-right: 0px;"></div>  <div style=" text-align: center;float: left;width: 14%;">' +self.lang. book_Aisle + '</div> <div id="seatD" class="font-border-train-check font-border-train-SeatD" style=" text-align: left;float: left;"></div> <div id="seatF" class="font-border-train-check font-border-train-SeatF" style=" margin-right: 2%;"></div> <div style=" width: 20%;text-align: left;float: left;">' + self.lang.book_window + '</div> </li>';

            } else  if(callback.selectedSeatPrice.nameEN =='Second Class'){
                html += '<li class="font-wechat font-border-li method_sort" style="  color: #ADADAD;font-size: 14px;font-weight: normal;background: #EDEDED;display: flex;font-size: 12px;"><div style=" width: 20%;text-align: right;float: left;">' + self.lang.book_window + '</div> <div id="seatA"  class="font-border-train-check font-border-train-SeatA" style="margin-left: 2%;"></div>  <div id="seatB" class="font-border-train-check font-border-train-SeatB"></div> <div id="seatC" class="font-border-train-check font-border-train-SeatC" style="margin-right: 0px;"></div>  <div style=" text-align: center;float: left;width: 14%;">' +self.lang. book_Aisle + '</div> <div id="seatD" class="font-border-train-check font-border-train-SeatD" style=" text-align: left;float: left;"></div> <div id="seatF" class="font-border-train-check font-border-train-SeatF" style=" margin-right: 2%;"></div> <div style=" width: 20%;text-align: left;float: left;">' + self.lang.book_window + '</div> </li>';

            } else  if (callback.selectedSeatPrice.nameEN =='Business Class'){
                html += '<li class="font-wechat font-border-li method_sort" style="  color: #ADADAD;font-size: 14px;font-weight: normal;background: #EDEDED;display: flex;font-size: 12px;"><div style=" width: 20%;text-align: right;float: left;">' + self.lang.book_window + '</div> <div id="seatA"  class="font-border-train-check font-border-train-SeatA" style="margin-left: 2%;"></div>   <div id="seatC" class="font-border-train-check font-border-train-SeatC" style="margin-right: 0px;"></div>  <div style=" text-align: center;float: left;width: 14%;">' +self.lang. book_Aisle + '</div>  <div id="seatF" class="font-border-train-check font-border-train-SeatF" style=" margin-right: 2%;"></div> <div style=" width: 20%;text-align: left;float: left;">' + self.lang.book_window + '</div> </li>';
            }

        }



        html += '</ul>';
        html += '</div>';
        $('#book_train_check').append(html);
        var page = $('div[data-role="page"]');
        $.each(page.children(), function () {
            $(this).addClass('frosted-glass');
        });
        var panel = $('.wechat-panel');
        panel.show();


        var showSearA = 2;
        var showSearB = 2;
        var showSearC = 2;
        var showSearD = 2;
        var showSearF = 2;

        var showSear1A = 2;
        var showSear1B = 2;
        var showSear1C = 2;
        var showSear1D = 2;
        var showSear1F = 2;

        var seatList=new Array() ;
        var showSeatList=new Array() ;


         if(getSeatListData !=null &&getShowSeatListData!=null){

             seatList= getSeatListData;
             showSeatList = getShowSeatListData;
             if(showNub ==1){

                 // var result=  $.inArray("1A", getSeatListData)

                 if( $.inArray("1A", getSeatListData)!=-1){
                     $("#seatA").removeClass('font-border-train-SeatA');
                     $("#seatA").addClass('font-border-train-buleSeatA');
                     var showSearA = 3;
                 }
                 if( $.inArray("1B", getSeatListData)!=-1){
                     $("#seatB").removeClass('font-border-train-SeatB');
                     $("#seatB").addClass('font-border-train-buleSeatB');
                     var showSearB = 3;
                 }

                 if( $.inArray("1C", getSeatListData)!=-1){
                     $("#seatC").removeClass('font-border-train-SeatC');
                     $("#seatC").addClass('font-border-train-buleSeatC');
                     var showSearC = 3;

                 }
                 if( $.inArray("1D", getSeatListData)!=-1){
                     $("#seatD").removeClass('font-border-train-SeatD');
                     $("#seatD").addClass('font-border-train-buleSeatD');
                     var showSearD = 3;

                 }

                 if( $.inArray("1F", getSeatListData)!=-1){
                     $("#seatF").removeClass('font-border-train-SeatF');
                     $("#seatF").addClass('font-border-train-buleSeatF');
                     var showSearF = 3;

                 }




             } else {
                 if( $.inArray("1A", getSeatListData)!=-1){
                     $("#seatA").removeClass('font-border-train-SeatA');
                     $("#seatA").addClass('font-border-train-buleSeatA');
                     var showSearA = 3;
                 }
                 if( $.inArray("2A", getSeatListData)!=-1){
                     $("#seat1A").removeClass('font-border-train-SeatA');
                     $("#seat1A").addClass('font-border-train-buleSeatA');
                     var showSear1A = 3;
                 }
                 if( $.inArray("1B", getSeatListData)!=-1){
                     $("#seatB").removeClass('font-border-train-SeatB');
                     $("#seatB").addClass('font-border-train-buleSeatB');
                     var showSearB = 3;
                 }
                 if( $.inArray("2B", getSeatListData)!=-1){
                     $("#seat1B").removeClass('font-border-train-SeatB');
                     $("#seat1B").addClass('font-border-train-buleSeatB');
                     var showSear1B = 3;
                 }

                 if( $.inArray("1C", getSeatListData)!=-1){
                     $("#seatC").removeClass('font-border-train-SeatC');
                     $("#seatC").addClass('font-border-train-buleSeatC');
                     var showSearC = 3;
                 }
                 if( $.inArray("2C", getSeatListData)!=-1){
                     $("#seat1C").removeClass('font-border-train-SeatC');
                     $("#seat1C").addClass('font-border-train-buleSeatC');
                     var showSear1C = 3;
                 }
                 if( $.inArray("1D", getSeatListData)!=-1){
                     $("#seatD").removeClass('font-border-train-SeatD');
                     $("#seatD").addClass('font-border-train-buleSeatD');
                     var showSearD = 3;
                 }
                 if( $.inArray("2D", getSeatListData)!=-1){
                     $("#seat1D").removeClass('font-border-train-SeatD');
                     $("#seat1D").addClass('font-border-train-buleSeatD');
                     var showSear1D = 3;
                 }

                 if( $.inArray("1F", getSeatListData)!=-1){
                     $("#seatF").removeClass('font-border-train-SeatF');
                     $("#seatF").addClass('font-border-train-buleSeatF');
                     var showSearF = 3;
                 }
                 if( $.inArray("2F", getSeatListData)!=-1){
                     $("#seat1F").removeClass('font-border-train-SeatF');
                     $("#seat1F").addClass('font-border-train-buleSeatF');
                     var showSear1F = 3;
                 }
             }
         }



        $( "#seatA").unbind('click').bind('click', function () {
            console.log('seatA');

            showSearA++;
            if( (showSearA&1)===0){

                var removeItem = '1A';
                if(showNub ==1) {
                    var showRemoveItem = 'A';
                } else {
                    var showRemoveItem = self.lang.book_frontRow +'A' ;
                }

                showSeatList = $.grep(showSeatList, function(value) {
                    return value != showRemoveItem;
                });
                seatList = $.grep(seatList, function(value) {
                    return value != removeItem;
                });
                $("#seatA").removeClass('font-border-train-buleSeatA');
                $("#seatA").addClass('font-border-train-SeatA');
            } else {

                if(seatList !=null && seatList.length<showNub){
                    seatList.push('1A');
                    if(showNub ==1) {
                        showSeatList.push('A');
                    } else {
                        showSeatList.push(self.lang.book_frontRow +'A');
                    }

                    $("#seatA").removeClass('font-border-train-SeatA');
                    $("#seatA").addClass('font-border-train-buleSeatA');
                } else {
                    showSearA--;

                }


            }
        });
        $( "#seat1A").unbind('click').bind('click', function () {
            console.log('seat1A');

            showSear1A++;
            if( (showSear1A&1)===0){

                var removeItem = '2A';
                if(showNub ==1) {
                    var showRemoveItem = 'A';
                } else {
                    var showRemoveItem = self.lang.book_backRow +'A' ;
                }

                showSeatList = $.grep(showSeatList, function(value) {
                    return value != showRemoveItem;
                });
                seatList = $.grep(seatList, function(value) {
                    return value != removeItem;
                });

                $("#seat1A").removeClass('font-border-train-buleSeatA');
                $("#seat1A").addClass('font-border-train-SeatA');
            } else {
                if(seatList !=null && seatList.length<showNub){
                    seatList.push('2A');
                    if(showNub ==1) {
                        showSeatList.push('A');
                    } else {
                        showSeatList.push(self.lang.book_backRow +'A');
                    }
                $("#seat1A").removeClass('font-border-train-SeatA');
                $("#seat1A").addClass('font-border-train-buleSeatA');
                } else {
                    showSear1A--;

                }
            }
        });
        $( "#seatB").unbind('click').bind('click', function () {
            console.log('seatB');

            showSearB++;
            if( (showSearB&1)===0){

                var removeItem = '1B';
                if(showNub ==1) {
                    var showRemoveItem = 'B';
                } else {
                    var showRemoveItem = self.lang.book_frontRow +'B' ;
                }

                showSeatList = $.grep(showSeatList, function(value) {
                    return value != showRemoveItem;
                });
                seatList = $.grep(seatList, function(value) {
                    return value != removeItem;
                });
                $("#seatB").removeClass('font-border-train-buleSeatB');
                $("#seatB").addClass('font-border-train-SeatB');
            } else {
                if(seatList !=null && seatList.length<showNub){
                    seatList.push('1B');
                    if(showNub ==1) {
                        showSeatList.push('B');
                    } else {
                        showSeatList.push(self.lang.book_frontRow +'B');
                    }
                $("#seatB").removeClass('font-border-train-SeatB');
                $("#seatB").addClass('font-border-train-buleSeatB');
                } else {
                    showSearB--;

                }
            }
        });
        $( "#seat1B").unbind('click').bind('click', function () {
            console.log('seat1B');

            showSear1B++;
            if( (showSear1B&1)===0){
                var removeItem = '2B';

                if(showNub ==1) {
                    var showRemoveItem = 'B';
                } else {
                    var showRemoveItem = self.lang.book_backRow +'B' ;
                }

                showSeatList = $.grep(showSeatList, function(value) {
                    return value != showRemoveItem;
                });
                seatList = $.grep(seatList, function(value) {
                    return value != removeItem;
                });
                $("#seat1B").removeClass('font-border-train-buleSeatB');
                $("#seat1B").addClass('font-border-train-SeatB');
            } else {
                if(seatList !=null && seatList.length<showNub){
                    seatList.push('2B');
                    if(showNub ==1) {
                        showSeatList.push('B');
                    } else {
                        showSeatList.push(self.lang.book_backRow +'B');
                    }
                $("#seat1B").removeClass('font-border-train-SeatB');
                $("#seat1B").addClass('font-border-train-buleSeatB');
                } else {
                    showSear1B--;

                }
            }
        });
        $( "#seatC").unbind('click').bind('click', function () {
            console.log('seatC');

            showSearC++;
            if( (showSearC&1)===0){
                var removeItem = '1C';
                if(showNub ==1) {
                    var showRemoveItem = 'C';
                } else {
                    var showRemoveItem = self.lang.book_frontRow +'C' ;
                }

                showSeatList = $.grep(showSeatList, function(value) {
                    return value != showRemoveItem;
                });
                seatList = $.grep(seatList, function(value) {
                    return value != removeItem;
                });

                $("#seatC").removeClass('font-border-train-buleSeatC');
                $("#seatC").addClass('font-border-train-SeatC');
            } else {
                if(seatList !=null && seatList.length<showNub){
                    seatList.push('1C');
                    if(showNub ==1) {
                        showSeatList.push('C');
                    } else {
                        showSeatList.push(self.lang.book_frontRow +'C');
                    }
                $("#seatC").removeClass('font-border-train-SeatC');
                $("#seatC").addClass('font-border-train-buleSeatC');
                } else {
                    showSearC--;

                }
            }
        });
        $( "#seat1C").unbind('click').bind('click', function () {
            console.log('seat1C');

            showSear1C++;
            if( (showSear1C&1)===0){
                var removeItem = '2C';
                if(showNub ==1) {
                    var showRemoveItem = 'C';
                } else {
                    var showRemoveItem = self.lang.book_backRow +'C' ;
                }

                showSeatList = $.grep(showSeatList, function(value) {
                    return value != showRemoveItem;
                });
                seatList = $.grep(seatList, function(value) {
                    return value != removeItem;
                });
                $("#seat1C").removeClass('font-border-train-buleSeatC');
                $("#seat1C").addClass('font-border-train-SeatC');
            } else {

                if(seatList !=null && seatList.length<showNub){
                    seatList.push('2C');
                    if(showNub ==1) {
                        showSeatList.push('C');
                    } else {
                        showSeatList.push(self.lang.book_backRow +'C');
                    }
                $("#seat1C").removeClass('font-border-train-SeatC');
                $("#seat1C").addClass('font-border-train-buleSeatC');
                } else {
                    showSear1C--;

                }
            }
        });
        $( "#seatD").unbind('click').bind('click', function () {
            console.log('seatD');

            showSearD++;
            if( (showSearD&1)===0){
                var removeItem = '1D';
                if(showNub ==1) {
                    var showRemoveItem = 'D';
                } else {
                    var showRemoveItem = self.lang.book_frontRow +'D' ;
                }

                showSeatList = $.grep(showSeatList, function(value) {
                    return value != showRemoveItem;
                });
                seatList = $.grep(seatList, function(value) {
                    return value != removeItem;
                });
                $("#seatD").removeClass('font-border-train-buleSeatD');
                $("#seatD").addClass('font-border-train-SeatD');
            } else {
                if(seatList !=null && seatList.length<showNub){
                    seatList.push('1D');
                    if(showNub ==1) {
                        showSeatList.push('D');
                    } else {
                        showSeatList.push(self.lang.book_frontRow +'D');
                    }
                $("#seatD").removeClass('font-border-train-SeatD');
                $("#seatD").addClass('font-border-train-buleSeatD');
                } else {
                    showSearD--;
                }
            }
        });
        $( "#seat1D").unbind('click').bind('click', function () {
            console.log('seat1D');

            showSear1D++;
            if( (showSear1D&1)===0){
                var removeItem = '2D';
                if(showNub ==1) {
                    var showRemoveItem = 'D';
                } else {
                    var showRemoveItem = self.lang.book_backRow +'D' ;
                }

                showSeatList = $.grep(showSeatList, function(value) {
                    return value != showRemoveItem;
                });
                seatList = $.grep(seatList, function(value) {
                    return value != removeItem;
                });
                $("#seat1D").removeClass('font-border-train-buleSeatD');
                $("#seat1D").addClass('font-border-train-SeatD');
            } else {
                if(seatList !=null && seatList.length<showNub){
                    seatList.push('2D');
                    if(showNub ==1) {
                        showSeatList.push('D');
                    } else {
                        showSeatList.push(self.lang.book_backRow +'D');
                    }
                $("#seat1D").removeClass('font-border-train-SeatD');
                $("#seat1D").addClass('font-border-train-buleSeatD');
                } else {
                    showSear1D--;
                }
            }
        });
        $( "#seatF").unbind('click').bind('click', function () {
            console.log('seatF');

            showSearF++;
            if( (showSearF&1)===0){
                var removeItem = '1F';
                if(showNub ==1) {
                    var showRemoveItem = 'F';
                } else {
                    var showRemoveItem = self.lang.book_frontRow +'F' ;
                }

                showSeatList = $.grep(showSeatList, function(value) {
                    return value != showRemoveItem;
                });
                seatList = $.grep(seatList, function(value) {
                    return value != removeItem;
                });
                $("#seatF").removeClass('font-border-train-buleSeatF');
                $("#seatF").addClass('font-border-train-SeatF');
            } else {
                if(seatList !=null && seatList.length<showNub){
                    seatList.push('1F');
                    if(showNub ==1) {
                        showSeatList.push('F');
                    } else {
                        showSeatList.push(self.lang.book_frontRow +'F');
                    }
                $("#seatF").removeClass('font-border-train-SeatF');
                $("#seatF").addClass('font-border-train-buleSeatF');
                } else {
                    showSearF--;

                }
            }
        });
        $( "#seat1F").unbind('click').bind('click', function () {
            console.log('seat1F');
            showSear1F++;
            if( (showSear1F&1)===0){
                var removeItem = '2F';
                if(showNub ==1) {
                    var showRemoveItem = 'F';
                } else {
                    var showRemoveItem = self.lang.book_backRow +'F' ;
                }

                showSeatList = $.grep(showSeatList, function(value) {
                    return value != showRemoveItem;
                });
                seatList = $.grep(seatList, function(value) {
                    return value != removeItem;
                });
                $("#seat1F").removeClass('font-border-train-buleSeatF');
                $("#seat1F").addClass('font-border-train-SeatF');
            } else {
                if(seatList !=null && seatList.length<showNub){
                    seatList.push('2F');
                    if(showNub ==1) {
                        showSeatList.push('F');
                    } else {
                        showSeatList.push(self.lang.book_backRow +'F');
                    }
                $("#seat1F").removeClass('font-border-train-SeatF');
                $("#seat1F").addClass('font-border-train-buleSeatF');
                } else {
                    showSear1F--;
                }
            }
        });
        // 确定
        $("#goListOK").unbind('click').bind('click', function () {
            console.log('选择好了');

             if(seatList.length ==0){

                // self.showAlertIonic($ionicPopup,{text: self.lang.book_prompt_alert});
                panel.css('display', 'none');
                panel.remove();
                $.each(page.children(), function () {
                    $(this).removeClass('frosted-glass');
                });
                 

                 self.removeCache( myCache, 'getSeatListData');
                 self.removeCache( myCache,'getShowSeatListData');
                if (callback) {
                    code(callback,null,null);
                }



            } else if(seatList.length<showNub &&showNub<=5){

                self.showAlertIonic($ionicPopup,{text: self.lang.book_prompt_alert});

            } else if(seatList.length>showNub&&showNub<=5){


            } else if(seatList.length==showNub&&showNub<=5){


                // self.showAlertIonic($ionicPopup,{text: self.lang.book_showAlert});

                panel.css('display', 'none');
                panel.remove();
                $.each(page.children(), function () {
                    $(this).removeClass('frosted-glass');
                });

                var newSeatList = seatList.join(",");
                var newShowSeatList = showSeatList.join(",");

                self.addCache( myCache, 'getSeatListData',seatList);
                self.addCache(myCache, 'getShowSeatListData',showSeatList);


                if (callback) {
                    code(callback,newSeatList,newShowSeatList);
                }
            }
        });

        //取消
        $("#goList").unbind('click').bind('click', function () {
            console.log('取消');

            self.removeCache( myCache, 'getSeatListData');
            self.removeCache( myCache,'getShowSeatListData');
            panel.css('display', 'none');
            panel.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
        });
    },


    //直机首次提示框
    showcheckInEventalert: function (store, clickmethod) {
        var self = this;

        var html = '';
        var contentClass = 'alert-content-wrapper';
        var alertContentHtml = '';
        html += '<div class="alert-box" style="display:none">';
        /******** 先拼接提示的内容 *************/
        alertContentHtml += '<div class="alert-content-check">';
        alertContentHtml += '<div style="padding:0px 0px 0px 0px;text-align: center;">';
        alertContentHtml += '<span>' + self.lang.checkInRemind + '</span>';
        alertContentHtml += '</div>';
        alertContentHtml += '<div class="" style="height: 44px;margin-left: 0px;padding-left: 0px;">';
//					alertContentHtml += '<input id="insurance_checkbox" type="checkbox" data-role="none" style="width:22px;height:22px;border: solid 1px #ddd;"/>';
//                    alertContentHtml += '<p id="checkselecte" class="zjf-icon-44 ys-check-unselect" ></p>';
//					alertContentHtml += '<span style="color: #696969">'+self.lang.ImportDoremind+'</span>';
        // alertContentHtml += '</input>';
        alertContentHtml += '</div>';
        alertContentHtml += '</div>';

        contentClass += ' alert-wrapper';//提示框内容容器只包含提示内容
        html += '<div class="' + contentClass + '" style="min-height:75px;">';
        html += alertContentHtml;
        html += '</div>';


        html += '<div class="ui-grid-solo">';
        html += '<button class="alert-btn-sure ui-btn ui-shadow ui-corner-all">' + self.lang['ok'] + '</button';
        html += '</div>';

        html += '</div>';

        var maskHtml = '<div class="select-mask"></div>';
        $('body').append(maskHtml);
        $('body').append(html);

        var page = $('div[data-role="page"]');
        $.each(page.children(), function () {
            $(this).addClass('frosted-glass');
        });

        var bodyClientHeight = document.body.clientHeight;
        var box = $('.alert-box');
        var boxHeight = box.height();
        box.css('top', bodyClientHeight / 2 - boxHeight / 2 + 'px');
        box.show();

        var mask = $('.select-mask');
        $('#checkselecte').unbind('click').bind('click', function () {
            if (store.getData('$showcheckInEventalert') != 'showcheckInEventalert') {
                $('#checkselecte').removeClass('ys-check-unselect');
                $('#checkselecte').addClass('ys-check-selected');
                store.setData('$showcheckInEventalert', 'showcheckInEventalert');
                // 值机提示 版本升级后重置用 存储相对应的版本
                store.setData('$showcheckInEventalertVersion', utils.config.get('version'));
            }
            else {
                $('#checkselecte').removeClass('ys-check-selected');
                $('#checkselecte').addClass('ys-check-unselect');
                store.setData('$showcheckInEventalert', 'showcheckInEventalerton');
                // 值机提示 版本升级后重置用 存储相对应的版本
                store.removeData('$showcheckInEventalertVersion');
            }

        });
        $('.alert-btn-sure').unbind('click').bind('click', function () {
            clickmethod();
            box.css('display', 'none');
            box.remove();
            mask.remove();

            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
        });
    },


    showCheckAlert: function (store, sgClient, SGPlugin) {
        var self = this;
        var appConfig = store.getAppConfig();
        if (appConfig && appConfig.journeyImpCalendar != 'Y') {
            store.setData('$showtravelToImportalert', 'showtravelToImportalert');
            return;
        }
        //console.log('option.text: '+ option.text);
        var html = '';
        var contentClass = 'alert-content-wrapper';
        var alertContentHtml = '';
        html += '<div class="alert-box" style="display:none">';
        /******** 先拼接提示的内容 *************/
        alertContentHtml += '<div class="alert-content-check">';
        alertContentHtml += '<div style="padding:0px 12px 0px 12px;">';
        alertContentHtml += '<span>' + self.lang.Importaddmanually + '</span>';
        alertContentHtml += '</div>';
        alertContentHtml += '<div class="" style="height: 44px;margin-left: 0px;padding-left: 0px;">';
//					alertContentHtml += '<input id="insurance_checkbox" type="checkbox" data-role="none" style="width:22px;height:22px;border: solid 1px #ddd;"/>';
        alertContentHtml += '<p id="checkselecte" class="zjf-icon-44 ys-check-selected" ></p>';
        alertContentHtml += '<span style="color: #696969">' + self.lang.ImportDoremind + '</span>';
        // alertContentHtml += '</input>';
        alertContentHtml += '</div>';
        alertContentHtml += '</div>';

        contentClass += ' alert-wrapper';//提示框内容容器只包含提示内容
        html += '<div class="' + contentClass + '">';
        html += alertContentHtml;
        html += '</div>';

        var showCancel = self.lang.ImportTurnon;
        var showOk = self.lang.ImportLatertosay;


        html += '<div class="ui-grid-a">';
        html += '<div class="ui-block-a"><button class="alert-btn-cancel ui-btn ui-shadow ui-corner-all">' + showCancel + '</button></div>';
        html += '<div class="ui-block-b"><button class="alert-btn-sure ui-btn ui-shadow ui-corner-all">' + showOk + '</button></div>';
        html += '</div>';

        html += '</div>';

        var maskHtml = '<div class="select-mask"></div>';
        $('body').append(maskHtml);
        $('body').append(html);

        var page = $('div[data-role="page"]');
        $.each(page.children(), function () {
            $(this).addClass('frosted-glass');
        });

        var bodyClientHeight = document.body.clientHeight;
        var box = $('.alert-box');
        var boxHeight = box.height();
        box.css('top', bodyClientHeight / 2 - boxHeight / 2 + 'px');
        box.show();

        var mask = $('.select-mask');
        $('#checkselecte').unbind('click').bind('click', function () {
            if (store.getData('$showtravelToImportalert') != 'showtravelToImportalert') {
                $('#checkselecte').removeClass('ys-check-selected');
                $('#checkselecte').addClass('ys-check-unselect');
                store.setData('$showtravelToImportalert', 'showtravelToImportalert');
            }
            else {
                $('#checkselecte').removeClass('ys-check-unselect');
                $('#checkselecte').addClass('ys-check-selected');
                store.setData('$showtravelToImportalert', 'showtravelToImportalerton');
            }

        });
        $('.alert-btn-cancel').unbind('click').bind('click', function () {
            box.css('display', 'none');
            box.remove();
            mask.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            store.setData('$travelToImport', "on");
            self.firstImport(store, sgClient, SGPlugin);

        });
        $('.alert-btn-sure').unbind('click').bind('click', function () {

            box.css('display', 'none');
            box.remove();
            mask.remove();

            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
        });
    },


    firstImport: function (store, sgClient, SGPlugin) {
        var self = this;
        if (store.getData('$travelToImport') == 'on') {
            var _Data = {
                'token': store.getToken()
            };
            sgClient.travelToImport(_Data, function (data) {

                if (data && data.state == 1) {//success,判断接口返回正确行程类别 （1：机票 2：酒店 3：火车票）
                    var _ary = data.data;
                    for (var i = 0, len = _ary.length; i < len; i++) {
                        if (_ary[i].importFlag == 0) {
                            if (_ary[i].journeyType == 1) {

                                var depDatef = new Date(_ary[i].depDate);
                                var retDatef = new Date(_ary[i].retDate);
                                var depDate = self.formatDate(depDatef, 'yyyy-mm-dd');
                                var retDate = self.formatDate(retDatef, 'yyyy-mm-dd');
                                var depTimeStr = self.formatDate(depDatef, 'hh:ii');
                                var retTimeStr = self.formatDate(retDatef, 'hh:ii');
                                var depApt = store.getAirportWithCode(_ary[i].depApt).name;
                                var arrApt = store.getAirportWithCode(_ary[i].arrApt).name;
                                var flightNo = _ary[i].carriageAirline + _ary[i].carriageFlightNo;
                                var data = {
                                    'depDate': depDate,
                                    'retDate': retDate,
                                    'depTimeStr': depTimeStr,
                                    'retTimeStr': retTimeStr,
                                    'depApt': depApt,
                                    'arrApt': arrApt,
                                    'flightNo': flightNo,
                                    'journeyType': "1",
                                    'isAuto': "on"
                                };

                                SGPlugin.travelToImport(data);


                            }
                            else if (_ary[i].journeyType == 3) {
                                var depDatef = new Date(_ary[i].departureTime);
                                var retDatef = new Date(_ary[i].arriveTime);
                                var depDate = self.formatDate(depDatef, 'yyyy-mm-dd');
                                var retDate = utils.formatDate(retDatef, 'yyyy-mm-dd');
                                var depTimeStr = self.formatDate(depDatef, 'hh:ii');
                                var retTimeStr = utils.formatDate(retDatef, 'hh:ii');
                                var depApt = _ary[i].departureStation;
                                var arrApt = _ary[i].arriveStation;
                                var flightNo = _ary[i].trainNo;
                                var data = {
                                    'depDate': depDate,
                                    'retDate': retDate,
                                    'depTimeStr': depTimeStr,
                                    'retTimeStr': retTimeStr,
                                    'depApt': depApt,
                                    'arrApt': arrApt,
                                    'flightNo': flightNo,
                                    'journeyType': "3",
                                    'isAuto': "on"
                                };

                                SGPlugin.travelToImport(data);
                            }
                            else if (_ary[i].journeyType == 2) {
                                var depDatef = new Date(_ary[i].hotelCheckInDate);
                                var retDatef = new Date(_ary[i].hotelCheckOutDate);
                                var depDate = self.formatDate(depDatef, 'yyyy-mm-dd');
                                var retDate = self.formatDate(retDatef, 'yyyy-mm-dd');
                                var depTimeStr = self.formatDate(depDatef, 'hh:ii');
                                var retTimeStr = self.formatDate(retDatef, 'hh:ii');
                                var depApt = _ary[i].hotelName;
                                var arrApt = _ary[i].hotelAddress;
                                var data = {
                                    'depDate': depDate,
                                    // 'retDate':retDate,
                                    'depTimeStr': depTimeStr,
                                    // 'retTimeStr':retTimeStr,
                                    'depApt': depApt,
                                    'arrApt': arrApt,
                                    'journeyType': "2",
                                    'hotelType': "checkin",
                                    'isAuto': "on"
                                };

                                SGPlugin.travelToImport(data);
                                var data = {
                                    'depDate': retDate,
                                    // 'retDate':retDate,
                                    'depTimeStr': retTimeStr,
                                    // 'retTimeStr':retTimeStr,
                                    'depApt': depApt,
                                    'arrApt': arrApt,
                                    'journeyType': "2",
                                    'hotelType': "checkout",
                                    'isAuto': "on"
                                };

                                SGPlugin.travelToImport(data);
                            }
                        }
                    }
                }
            });
        }

    },
    showAlert: function (option) {
        var self = this;
        if (self.alertIsShow == true) {
            return;
        }

        if (!option) {
            return;
        }

        //console.log('option.text: '+ option.text);
        if (option.text == null || option.text == undefined || option.text == '' || typeof option.text != 'string') {
            return;
        }
        self.alertIsShow = true;
        //ID 4467:【酒店预定】【差旅随行2.1.6】【魅族MX3 安卓4.4.4】在核对订单页面返回后再次进入核对订单页面点击预定按钮无反应
        params.alertShow = self.alertIsShow;
        var html = '';
        var contentClass = 'alert-content-wrapper';
        var alertContentHtml = '';
        html += '<div class="alert-box" style="display:none">';
        /******** 先拼接提示的内容 *************/
        alertContentHtml += '<div class="alert-content" style="' + ((option && option.once) ? "display: block;border-bottom: 0;padding: 15px 12px 5px 12px;" : "") + '">';
        alertContentHtml += option.text;
        alertContentHtml += '</div>';
        if (option.title) {//有标题
            html += '<div class="alert-wrapper">';//提示框内容容器包含标题和提示内容
            html += '<div class="alert-title">';
            html += option.title;
            html += '</div>';
            html += '<div class="' + contentClass + '">';
            html += alertContentHtml;
            html += '</div>';
            html += '</div>';
        } else {
            contentClass += ' alert-wrapper';//提示框内容容器只包含提示内容
            html += '<div class="' + contentClass + '" style="' + ((option && option.once) ? "display: block;" : "") + '">';
            html += alertContentHtml;
            //COZYGO-3353 选座功能增加弹窗 ,用户可以勾选不再提示
            if (option && option.once) {
                html += '<div class="alert-opt-once" style="height: 32px;width: 100%;border-bottom: 1px solid #dcdcdc;padding: 0 0 5px;">';
                html += '<div class="zjf-icon-44 icon-pri-unselected" style="width: 39px;float: left;"></div>';
                html += '<div class="zjf-font5" style="height: 40px;line-height: 37px;">' + self.lang.ImportDoremind + '</div>';
                html += '</div>';
            }
            html += '</div>';
        }
        if (option.onOK && !option.onCancel) {//确定按钮
            html += '<div class="ui-grid-solo">';
            html += '<button class="alert-btn-sure ui-btn ui-shadow ui-corner-all">' + (option.change ? self.lang.yes_no[1] : self.lang['ok']) + '</button';
            html += '</div>';
        } else if (!option.onOK && option.onCancel) {//取消按钮
            html += '<div class="ui-grid-solo">';
            html += '<button class="alert-btn-cancel ui-btn ui-shadow ui-corner-all">' + (option.change ? self.lang.yes_no[0] : self.lang['cancel']) + '</button';
            html += '</div>';
        } else if (option.onOK && option.onCancel) {//取消跟确定同时存在
            var showCancel = option.change ? self.lang.yes_no[0] : self.lang['cancel'];
            var showOk = option.change ? self.lang.yes_no[1] : self.lang['ok'];
            if (option.onOKtxt) {
                showOk = option.onOKtxt;
            }
            if (option.onCanceltxt) {
                showCancel = option.onCanceltxt;
            }
            if (option.label) {
                var strArray = option.label.split(",");
                showCancel = strArray[1];
                showOk = strArray[0];
            }
            html += '<div class="ui-grid-a">';
            html += '<div class="ui-block-a"><button class="alert-btn-cancel ui-btn ui-shadow ui-corner-all">' + showCancel + '</button></div>';
            html += '<div class="ui-block-b"><button class="alert-btn-sure ui-btn ui-shadow ui-corner-all">' + showOk + '</button></div>';
            html += '</div>';
        } else {
            html += '<div class="ui-grid-solo">';
            html += '<button class="alert-btn-sure ui-btn ui-shadow ui-corner-all">' + self.lang['ok'] + '</button';
            html += '</div>';
        }
        html += '</div>';

        var maskHtml = '<div class="select-mask"></div>';
        $('body').append(maskHtml);
        $('body').append(html);

        var page = $('div[data-role="page"]');
        $.each(page.children(), function () {
            $(this).addClass('frosted-glass');
        });

        var bodyClientHeight = document.body.clientHeight;
        var box = $('.alert-box');
        var boxHeight = box.height();
        box.css('top', bodyClientHeight / 2 - boxHeight / 2 + 'px');
        box.show();

        var mask = $('.select-mask');
        //COZYGO-3353 选座功能增加弹窗 ,用户可以勾选不再提示
        $('.alert-opt-once').unbind('click').bind('click', function () {
            if (option.once) {
                var _opt = $(this).children();
                var isOpt = false; //是否勾选，默认未勾选
                if (_opt && _opt[0]) {
                    var _opt0 = $(_opt[0]);
                    if (_opt0.is('.icon-pri-unselected')) {
                        _opt0.removeClass('icon-pri-unselected').addClass('icon-pri-selected');
                        isOpt = true;
                    } else {
                        _opt0.removeClass('icon-pri-selected').addClass('icon-pri-unselected');
                        isOpt = false;
                    }
                    option.once(isOpt);
                    delete _opt0;
                }
            }
        });
        $('.alert-btn-cancel').unbind('click').bind('click', function () {
            box.css('display', 'none');
            box.remove();
            mask.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            self.alertIsShow = false;
            //ID 4467:【酒店预定】【差旅随行2.1.6】【魅族MX3 安卓4.4.4】在核对订单页面返回后再次进入核对订单页面点击预定按钮无反应
            params.alertShow = self.alertIsShow;
            if (option.onCancel) {
                /*
                 *强制升级
                 */
                if (option.isObliged) {
                    self.clearMyOrderAndApverCache();
                    window.navigator.app.exitApp();
                }
                option.onCancel();
            }

        });
        $('.alert-btn-sure').unbind('click').bind('click', function () {

            box.css('display', 'none');
            box.remove();
            mask.remove();
            self.alertIsShow = false;
            //ID 4467:【酒店预定】【差旅随行2.1.6】【魅族MX3 安卓4.4.4】在核对订单页面返回后再次进入核对订单页面点击预定按钮无反应
            params.alertShow = self.alertIsShow;
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            if (option.onOK) {
                option.onOK();
            }
        });
    },
    alert: function (option) {
        var self = this;
        if (self.alertIsShow == true) {
            return;
        }

        if (option.text == null || option.text == undefined || option.text == '' || typeof option.text != 'string') {
            return;
        }

        var navigator = window.navigator;
        self.alertIsShow = true;
        option = option || {};
        option.title = option.title || self.lang['alert'] || "alert";
        option.label = option.label || (self.lang['ok'] || 'ok') + "," + (self.lang['cancel'] || 'cancel');
        //
        if (self.isCordova()) {
            if (option.onOk && option.onCancel) {
                window.navigator.notification.confirm(option.text, function (rs) {
                    self.alertIsShow = false;
                    if (rs == 1) {
                        option.onOk();
                    } else if (rs == 2) {
                        /*
                         *强制升级
                         */
                        if (option.isObliged) {
                            self.clearMyOrderAndApverCache();
                            window.navigator.app.exitApp();
                        }
                        option.onCancel();
                    } else {
                        /*
                         *强制升级
                         */
                        if (option.isObliged != undefined) {
                            self.alert(option);
                            return;
                        }
                    }
                }, option.title, option.label);
            } else {
                window.navigator.notification.alert(option.text, function (rs) {
                    self.alertIsShow = false;
                    if (option.onOk) {
                        option.onOk();
                    }
                    /*else {
                     app.utils.alert(option);
                     return;
                     }*/
                }, option.title, option.label.split(',')[0]);
            }
        } else {
            self._alert(option);
            self.alertIsShow = false;
        }
    },
    //检查乘机人证件号码,电话号码,是否为空
    checkUserList: function (userList, lang, appConfig) {
        var self = this;
        var buffer = [];
        $.each(userList, function () {
            //非易行用户判断证件号，手机号，邮箱 add 2015-1-8
            //COZYGO-437 前端根据后台配置决定预订时邮箱是否为必输项
            if ((appConfig && appConfig.bookCheckEmail == "Y") && (self.ifEmpty(this.certNo) || self.ifEmpty(this.email) || self.ifEmpty(this.mobile))) {
                buffer.push(self.lang.userInfoAlert.replace('{name}', this.psgName));
            } else if (self.ifEmpty(this.certNo) || self.ifEmpty(this.mobile)) {//其他用户邮箱非必添项
                buffer.push(self.lang.userInfoAlert.replace('{name}', this.psgName));
            }
        });
        return buffer;
    },
    /**
     * 根据format获取时间格式
     */
    getNowTime: function (format) {
        var d = new Date();
        var o = {
            "M+": d.getMonth() + 1, //month
            "d+": d.getDate(),    //day
            "h+": d.getHours(),   //hour
            "m+": d.getMinutes(), //minute
            "s+": d.getSeconds(), //second
            "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
            "S": d.getMilliseconds() //millisecond
        }
        if (/(y+)/.test(format)) {
            format = format.replace(RegExp.$1, (d.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(format)) {
                format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
            }
        }
        return format;
    },
    /**
     * 判断该航班是否符合政策
     * flightInfo:要判断航班
     * flightInfoList:航班列表
     * policyInfo:差旅政策
     */
    getIntlTopContrary: function (flightInfo, flightInfoList, policyInfo) {
        var _self = this;
        var _flag = false;
        if (!policyInfo || !flightInfo || !flightInfoList || _self.ifEmpty(flightInfo.totalAmount)) {//推荐航班价格为空不判断
            return _flag;
        }
        if (policyInfo.lowestprice) {//差旅政策类型
            //lowestprice 0： 全天最低价,1：时间基准的最低价,2:无最低价,3：航班为基准的最低价
            /*
             * 对前端而言，全天最低价和区域时间最低价，判断都找出对低价那个做参考，因为区域最低价后台返回数据为区域时间段内的数据
             */
            if (policyInfo.lowestprice == 0 || policyInfo.lowestprice == 1) {//全天最低价和区域最低价
                _flag = _self.ifFlightInfoLowestPrice(flightInfo, flightInfoList);
            }
            else if (policyInfo.lowestprice == 3 && policyInfo.timeparthour) {//航班为基准最低价
                var _sortList = _.clone(flightInfoList);
                var _method = "OrderBy";//升序
                var _fn = function (x) {//比较值
                    return x.depINOD.depDate + "" + x.depINOD.depTime;
                }; //起飞时间排序
                _sortList = Enumerable.From(_sortList)[_method](_fn).ToArray();
                var areaList = [];//符合该时间段的列表
                var depTimeMinutes = parseInt(flightInfo.depINOD.depTime.substring(0, 2)) * 60 + parseInt(flightInfo.depINOD.depTime.substring(3, 5));//获取总分钟
                for (var i in _sortList) {//遍历找出符合区域时间段内列表
                    var item = _sortList[i];
                    var _itemTimeMinutes = parseInt(item.depINOD.depTime.substring(0, 2)) * 60 + parseInt(item.depINOD.depTime.substring(3, 5));//获取总分钟
                    if (Math.abs(depTimeMinutes - _itemTimeMinutes) <= (parseInt(policyInfo.timeparthour) * 60 )) {//在区域时间范围内
                        areaList.push(item);
                    }
                }
                _flag = _self.ifFlightInfoLowestPrice(flightInfo, areaList);
            }
        }
        return _flag;
    },
    /**
     * 判断该航班是否为列表中最低价航班
     */
    ifFlightInfoLowestPrice: function (flightInfo, flightInfoList) {
        var _sortList = _.clone(flightInfoList);
        var _method = "OrderBy";//升序
        var _fn = function (x) {
            return x.totalAmount;
        };//比较值
        _sortList = Enumerable.From(_sortList)[_method](_fn).ToArray();
        if (flightInfo.totalAmount <= _sortList[0].totalAmount) {//符合政策
            return true;
        }
        else {
            return false;
        }
    },
    /**
     * 组装航段信息
     * @param data
     * @returns {___anonymous4315_5077}
     */
    convertSegment: function (data, i, flag) {
        var segment = {
            segmentId: "", //主键
            airportTax: data.cabinInfo.aptTax, //机场建设税
            arriveStn: data.arrApt, //到达机场三字码
            arriveTerminal: data.arrTer, //到达机场航站楼
            arriveTime: data.arrDate + " " + data.arrTime, //到达时间
            baseCabin: data.cabinInfo.basicCabin, //基础舱位（舱位类型）F:头等，C：商务，Y:经济
            cabinCode: data.cabinInfo.code, //舱位代码
            cabinCount: data.cabinInfo.cabinCount,//count
            cabinType: data.cabinInfo.type, //舱位类型 F:头等，C：商务，Y:经济，其它超级经济舱
            accountCode: !_.isEmpty(data.cabinInfo.accountCode) ? data.cabinInfo.accountCode : '',//大客户编码 TODO
            //
            carriageAirline: data.carriageAirline, //承运方航空公司代码
            carriageFlightNo: data.carriageFlightNo, //承运方航班号
            //
            marketAirline: data.marketAirline, //市场方航空公司代码
            marketFlightNo: data.marketFlightNo, //市场方航班号
            //
            craftTypeCode: data.crafttypeCode, //机型代码
            ei: data.cabinInfo.ei || data.cabinInfo.fareConditions || '', //中文航段退改签的文字描述
            eiEn: data.cabinInfo.eiEn || data.cabinInfo.fareConditions || "", //中文航段退改签的文字描述
            flyTime: null, //飞行时间
            fuelTax: data.cabinInfo.fuelTax, //燃油税
            journeyCreateTime: null, //行程创建时间

            oi: i == 1 ? "O" : "I", //往返程标识
            price: data.cabinInfo.price, //航位价格
            sequenceNo: i, //航段序号
            takeoffStn: data.depApt, //出发机场三字码
            takeoffTerminal: data.depTer, //出发机场航站楼
            takeoffTime: data.depDate + " " + data.depTime, //出发时间
            fareId: data.cabinInfo.coreFareId, //协议价Id
            priceType: data.cabinInfo.priceType, //价格类型
            codeShare: data.codeShare, //是否航班共享
            stopOver: data.stopOver, //是否经停
            officeNo: data.cabinInfo.officeNo,//office号
            agentId: data.cabinInfo.agentId ? data.cabinInfo.agentId : '',
            fbc: data.cabinInfo.fbc, //自动出票需要的运价基础字段
            cabinDiscount: data.cabinInfo.discount, //add 2014-10-21  by zg (ssy)
            fullPrice: data.cabinInfo.allPrice,		//add 2014-10-23  by zg (ssy)
            contrary: data.cabinInfo.contrary, //add 2014-12-4  核对订单 时需要判断该航段是否违背政策
            seat: !_.isEmpty(data.asr) ? data.asr : '', //add 2015-2-13 选座，推消息使用COZYGO-254  行前选座 - 预订时，是否选座字段保存到订单
            bookingwindow: data.bookingwindow ? data.bookingwindow : null,		//add 2015-5-14
            mealCode: data.mealCode ? data.mealCode : '',//参数代码  add 2015-8-6 by zg, lwj		//add 2015-5-14

            flyTime: data.flightTime, //飞行时间  add 2015-9-21 by zg
            stopOver: data.stopOver, //经停标志 add 2015-9-21 by zg
            stopOverApts: data.stopOverApts,//经停地 add 2015-9-21 by zg
            tmp: !this.ifEmpty(data.tpm) ? data.tpm : 0, //COZYGO-2726航班查询结果和保存订单增加一个tpm字段（里程数）2016-1-7 by zg
            		
            // CabinVO的字段：
    		// 乘客类型(ADT:大人/CHD:小孩/INF:婴儿)
            paxTp: data.cabinInfo.paxTp,
            // 作为出票时的TC项
            tourCode: data.cabinInfo.tourCode,
            // 备注信息 退票规定等 
    		comment: data.cabinInfo.comment,
    		// 运价规则
    		ruleId: data.cabinInfo.ruleId,
    		// 该舱的明折明扣价格
    		fdPrice: data.cabinInfo.fdPrice,
    		// 权重
    		weight: data.cabinInfo.weight,
    		// 政策价标记位（1表示政策价）
    		policy: data.cabinInfo.policy,
    		// 退票是否减FdPrice标记位0：表示否 1：表示是
    		reduceFdPriceFlag: data.cabinInfo.reduceFdPriceFlag,
    		// 退票金额
    		refundedAm: data.cabinInfo.refundedAm,
    		// 退票金额表示是否是用百分比 0：表示否 1：表示是
    		refundedAmPer: data.cabinInfo.refundedAmPer,
    		// 是否可退票 0：表示否 1：表示是
    		refundedFlag: data.cabinInfo.refundedFlag,
    		// 改期金额
    		rescheduledAm: data.cabinInfo.rescheduledAm,
    		// 改期金额表示是否是用百分比 0：表示否 1：表示是
    		rescheduledAmPer: data.cabinInfo.rescheduledAmPer,
    		// 是否可改期 0：表示否 1：表示是
    		rescheduledFlag: data.cabinInfo.rescheduledFlag,
    		// 改签金额
    		changeAirLineAm: data.cabinInfo.changeAirLineAm,
    		// 改签金额表示是否是用百分比 0：表示否 1：表示是
    		changeAirLineAmPer: data.cabinInfo.changeAirLineAmPer,
    		// 是否可改签 0：表示否 1：表示是
    		changeAirLineFlag: data.cabinInfo.changeAirLineFlag,
    		// 客票有效期
    		validityPeriod: data.cabinInfo.validityPeriod,
    		// 行李重量
    		baggageWeight: data.cabinInfo.baggageWeight,
    		// fareInfo类型 1原价标识 4最终的折扣价格标识
    		fareInfoTp: data.cabinInfo.fareInfoTp,
    			    
    		// FlightVO的新增字段：
    		// 航段序号
    		sEG_SQ: data.sEG_SQ,
    		// 航段类别G-去程，R-回程
    		sEG_TP: data.sEG_TP,
    		b2GResultFlag: data.b2GResultFlag, //航班查询结果标识位  1:b2g  0:IBE+
    		farebasis: data.farebasis //运价基础
        };
        /*政策信息*/
        if (flag) {
            segment.contrContent = [];//违返政策的内容
            segment.contrContentEn = [];//违返政策的内容(英文)
            segment.contrPolicy = 0;//是否违返政策	1:违背，0:不违背
            segment.contrReason = "";//违背政策原因，提交时在订单详情页追加
            segment.contrReasonEn = "";
        }
        return segment;
    },
    /**
     * 获取三位随机数
     */
    getRandomNum: function () {
        var Num = "";
        for (var i = 0; i < 3; i++) {
            Num += Math.floor(Math.random() * 10);
        }
        return Num;
    },
    /**
     * 组装航段信息
     * i,航段序号
     * j,区分往返程标志
     */
    convertINSegment: function (data, i, j) {
        var segment = {
            segmentId: "", //主键
            agentId: 0, //代理商Id
            airportTax: '', //机场建设税,国际无
            arriveStn: data.arrApt, //到达机场三字码
            arriveTerminal: data.arrTerm, //到达机场航站楼
            arriveTime: data.arrDate + " " + data.arrTime, //到达时间
            baseCabin: data.baseCabin, //基础舱位（舱位类型）F:头等，C：商务，Y:经济
            cabinCode: data.cabinCode, //舱位代码
            cabinCount: data.seatCount,//count
            cabinType: data.cabinType ? data.cabinType : data.flightCabin, //舱位类型 F:头等，C：商务，Y:经济，其它超级经济舱
            accountCode: '',//大客户编码 TODO，国际暂无
            //
            carriageAirline: data.carriageAirline, //承运方航空公司代码
            carriageFlightNo: data.carriageFlightNo, //承运方航班号
            //
            marketAirline: data.marketingAirline, //市场方航空公司代码
            marketFlightNo: data.flightNumber, //市场方航班号
            //
            craftTypeCode: data.craftTypeCode, //机型代码
            ei: '', //中文航段退改签的文字描述，暂无
            eiEn: "", //中文航段退改签的文字描述，暂无
            flyTime: data.flightTime, //飞行时间
            fuelTax: '', //燃油税,国际无
            journeyCreateTime: null, //行程创建时间

            oi: i == 1 ? "O" : "I", //往返程标识
            price: '', //航位价格,国际无
            sequenceNo: i, //航段序号
            takeoffStn: data.depApt, //出发机场三字码
            takeoffTerminal: data.depTerm, //出发机场航站楼
            takeoffTime: data.depDate + " " + data.depTime, //出发时间
            fareId: '', //协议价Id,暂无
            priceType: '', //价格类型,无
            codeShare: data.codeShare, //是否航班共享,
            stopOver: "", //国内字段，国际不用
            tripCard: "",//航段下对应常旅客卡号，added by zjf 2015-8-6
            officeNo: '',//office号,暂无
            fbc: '', //自动出票需要的运价基础字段,暂无
            cabinDiscount: '', //add 2014-10-21  by zg (ssy) ,暂无
            fullPrice: '',		//add 2014-10-23  by zg (ssy)，暂无
            contrary: '', //add 2014-12-4  核对订单 时需要判断该航段是否违背政策，暂无
            asr: !_.isEmpty(data.asr) ? data.asr : '', //add 2015-2-13 选座，推消息使用COZYGO-254  行前选座 - 预订时，是否选座字段保存到订单
            baggageAllowancePieces: data.baggageAllowancePieces,//行李件数
            baggageAllowanceWeight: data.BaggageAllowanceWeight,//行李重量
            tmp: data.tpm,//里程
            stopOverVOList: data.stopOverList,//
            stopQuantity: data.stopQuantity,//经停数量
            tv: data.tv,//娱乐
//				meal:data.meal,//餐食  changed by zjf 2015-6-12   zwz说该字段已删除，不要
        };
        return segment;
    },
    /**
     * 组装乘机人信息
     * @param data
     * @returns {___anonymous5209_6554}
     */
    convertUser: function (data, i, store, appConfig) {
        data.agentId = data.agentId || store.getMyInfo().agentId;
        //成本中心信息
        var ccinfoName = (_.isEmpty(data.costcenterinfName)) ? (_.isEmpty(data.ccInfo) ? "" : data.ccInfo.costcenterinfName) : data.costcenterinfName;
        var ccinfoId = (data.costCenterId == (null || undefined) || data.costCenterId == "") ? (_.isEmpty(data.ccInfo) ? "" : data.ccInfo.costcenterinfId) : data.costCenterId;
        var _ccinfo = (_.isEmpty(data.costCenterInfo)) ? (_.isEmpty(data.ccInfo) ? "" : data.ccInfo.costcenterinf) : data.costCenterInfo;
        /*if(data.costcenterinfName == "" || data.costcenterinfName == null || data.costcenterinfId == ""
         || data.costcenterinfId == null || data.costcenterinf == null || data.costcenterinf == ""){
         if(data.ccInfo == null || data.ccInfo == ""){
         ccinfoName = "";
         ccinfoId = "";
         _ccinfo = "";
         }else {
         ccinfoName = data.ccInfo.costcenterinfName;
         ccinfoId = data.ccInfo.costcenterinfId;
         _ccinfo = data.ccInfo.costcenterinf;
         }
         }else {
         ccinfoName = data.costcenterinfName;
         ccinfoId = data.costcenterinfId;
         _ccinfo = data.costcenterinf;
         }*/
        var name, email, mobile, certObj;
        if (data.email && data.mobile) { //先检查个人资料，参数全就使用个人资料
            name = data.name || data.psgName || data.hostName;
            email = data.email;
            mobile = data.mobile;
        } else if (data.contactName && data.contactEmail && data.contactMobile) { //如资料不全再检查联系人资料，全就使用联系人资料
            name = data.contactName;
            email = data.contactEmail;
            mobile = data.contactMobile;
        }
        var nameEn;//常客英文名
        nameEn = (_.isEmpty(data.nameEn) && _.isEmpty(data.psgNameEn)) ? (data.name || data.psgName) : (data.nameEn || data.psgNameEn);
        //获取有效的证件对象
        certObj = this.checkCertInfo(data.credentialsInfoList);
        return {
            /*基础信息*/
            passengerId: "", //主键
            /*预订Pnr需要字段*/
            book1: "", //预订相关1
            book2: "", //预订相关2
            book3: "", //预订相关3
            book4: "", //预订相关4
            book5: "", //预订相关5
            book6: "", //预订相关6
            book7: "", //预订相关7
            book8: "", //预订相关8
            book9: "", //预订相关9
            book10: "", //预订相关10
            dBook1: "", //国内预订相关1
            dBook2: "", //国内预订相关2
            dBook3: "", //国内预订相关3
            dBook4: "", //国内预订相关4
            dBook5: "", //国内预订相关5
            dBook6: "", //国内预订相关6
            dBook7: "", //国内预订相关8
            dBook8: "", //国内预订相关8
            dBook9: "", //国内预订相关9
            dBook10: "", //国内预订相关10

            birthDay: data.birthDay ? data.birthDay : '', //国际乘客需要生日数据 add by zg 2015-5-5
            name_ch: data.name_ch ? data.name_ch : '',	 //国际乘客 名add by zg 2015-5-11
            name_en: data.name_en ? data.name_en : '',	 //国际乘客 名add by zg 2015-5-11
            surname_ch: data.surname_ch ? data.surname_ch : '',//国际乘客 姓add by zg 2015-5-11
            surname_en: data.surname_en ? data.surname_en : '',//国际乘客 姓add by zg 2015-5-11
            /*行程下,航空单元内的乘机人信息 */
            agentId: data.agentId, //代理商Id
            certNo: _.isEmpty(certObj) ? (data.idCard || data.passport || data.certNo) : certObj.code, //证件号码(前端传入)
            certType: _.isEmpty(certObj) ? "1" : certObj.type, //证件类型(前端传入) 1－身份证；
            certId: _.isEmpty(certObj) ? '' : certObj.id,//证件id add 2014-5-24
            expireDate: data.expireDate,//证件有效期(国际) add 2015-5-14
            issueCountry: data.issueCountry,//证件签发国 (国际)add 2015-5-14
            contactEmail: _.isEmpty(email) ? (_.isEmpty(data.contactEmail) ? data.email : data.contactEmail) : email, //联系人Email COZYGO-712联系人信息为空时自动带入乘机人信息
            contactName: _.isEmpty(name) ? (_.isEmpty(data.contactName) ? (data.name || data.psgName || data.hostName) : data.contactName) : name, //联系人姓名 COZYGO-712联系人信息为空时自动带入乘机人信息
            contactTel: this.ifEmpty(mobile) ? (this.ifEmpty(data.contactMobile) ? data.mobile : data.contactMobile) : mobile, //联系人电话	COZYGO-712联系人信息为空时自动带入乘机人信息
            corpCode: data.corpCode, //公司代码
            corpId: data.corpId, //公司Id
            email: data.email, //乘机人的常客中的email
            hostName: data.hostName, //主机姓名（在乘机人常客信息里能取到）
            ihostname: data.ihostname,//国际主机名 add 2015-5-18
            journeyCreateTime: null, //行程创建时间

            memCard: data.memCard, //所使用的常客卡
            mobile: data.mobile, //乘机人手机号码
            psgName: data.name || data.psgName, //乘机人的姓名
            psgNameEn: nameEn,
            psgSex: data.sex || data.psgSex,
            psgParId: data.parId || data.psgParId, //乘机人常客Id
            psgParCode: data.parCode || data.psgParCode,//乘机人usn bcd添加 add zcy 2015-06-12
            isTemp: data.isTemp || "",//Y为临客
            tempUserId: data.tempUserId || "",//运通临客ID
            sequenceNo: i || data.sequenceNo, //乘机的序号
            oftenTripCardInfoList: data.oftenTripCardInfoList, //常客卡列表
            credentialsInfoList: data.credentialsInfoList, //常客证件列表 add 2014-5-14
            /**
             * 成本中心id
             * 个人预订：默认为空
             * 多人预订：默认为选择人的id
             */
            costCenterId: ccinfoId,//成本中心id params.isGroupBook &&
//				costCenterId:'',//成本中心id默认为空
            costCenterInfo: _ccinfo,//成本中心信息
            ccRemark: '',//成本中心备注
//				costcenterinfName: data.costcenterinfName || data.ccInfo == null ? "":data.ccInfo.costcenterinfName,
            costcenterinfName: ccinfoName,
            employeeNo: data.employeeNo,

            mealPrefCode: (appConfig && appConfig.isShowMealCheck == "Y" && data.mealPrefCode) ? data.mealPrefCode : '',//餐食,配置显示餐食和座位信息，默认带入个人信息中默认值COZYGO-511,//餐食
            seatPrefCode: (appConfig && appConfig.isShowSeatCheck == "Y" && data.seatPrefCode) ? data.seatPrefCode : '',//座位
            nation: data.nation ? data.nation : '',//国籍，酒店新增
            approveRuleInfo: data.approveRuleInfo,//审批规则，针对秘书型用户更改成本中心 added by zjf 2015-1-15
            iApproveRuleInfo: data.iApproveRuleInfo,//国际审批规则
            travelPolicyInfo: data.travelPolicyInfo,//添加差旅政策用于酒店核对订单中选择入住人时校验差旅政策 add by zcy 2015-03-26
            ticketNumber: data.ticketNumber,//票号(国际) add 2015-5-14
            cardVOList: data.cardVOList,//信用卡VOList(国际) add 2015-5-14
            itravelPolicyInfo: data.itravelPolicyInfo,//国际差旅政策
            //明日航空需求
            /*applicationNo:'',//申请单号
             projectAndApplication:'',//项目及用途
             costOwnership:'',//费用归属
             eRPNo:'',//ERP号
             airlineSeats:'',//航班座位
             insurance:''//保险
             */
        };
    },
    /**
     * 国际乘客信息保存
     */
    convertIntUser: function (_curPsg) {
        return {
            parId: _curPsg.psgParId,
            name: _curPsg.psgName,			//名字                     中文姓+名
            nameEn: _curPsg.psgNameEn, 		//英文名                英文姓+名
            name_ch: _curPsg.name_ch,		//中文名 	              ""
            surname_ch: _curPsg.surname_ch,	//中文姓 	      "PENG二"
            name_en: _curPsg.name_en,		//英文名              "ER"
            surname_en: _curPsg.surname_en,	//英文姓	      "PENG"
            sex: _curPsg.psgSex,	 			//性别
            birthDay: _curPsg.birthDay, 		//生日1981/09/10
            email: _curPsg.email,			//	邮箱              "do*********@126.com"
            mobile: _curPsg.mobile,			//电话 	             "131*****556"
            nation: _curPsg.nation,			//  国际              "US"
            contactName: _curPsg.contactName,		//联系人名字      "PENG二"
            contactEmail: _curPsg.contactEmail,		//联系人邮箱 "do*********@126.com"
            contactMobile: _curPsg.contactTel,		//联系人手机     131*****556
            oftenTripCardInfoList: _curPsg.oftenTripCardInfoList, 	//常客卡列表
            credentialsInfoList: _curPsg.credentialsInfoList 		//证件列表
        };
    },
    /**
     * 运通乘机人属性补充
     * psgUser 组装后的乘机人对象
     * data 常客数据
     */
    _amexConvertUser: function (psgUser, data) {
        if (psgUser) {
            psgUser.amexPassengerId = data.obtUserId || (!data.amexPassengerId ? '' : data.amexPassengerId);
            //psgUser.psgNameEn=data.name_en||data.psgNameEn;
            psgUser.psgParCode = data.parCode || (!data.psgParCode ? '' : data.psgParCode);
            psgUser.obtUserId = data.obtUserId;
            //运通增加属性 add zcy
            psgUser.psgGivenName = data.name_ch || (!data.psgGivenName ? '' : data.psgGivenName);
            psgUser.psgSurName = data.surname_ch || (!data.psgSurName ? '' : data.psgSurName);
            psgUser.psgGivenNameEn = data.name_en || (!data.psgGivenNameEn ? '' : data.psgGivenNameEn);
            psgUser.psgSurNameEn = data.surname_en || (!data.psgSurNameEn ? '' : data.psgSurNameEn);
        }
        return psgUser;
    },
    /**
     * add 2014-12-15
     * 校验乘机人证件信息
     * 证件号和证件类型要保持一致
     */
    checkCertInfo: function (certList) {
        var self = this;
        if (certList) {
            //获取身份证对象
            var cardList = Enumerable.From(certList).Where(function (x) {
                return x.type == "1";
            }).ToArray();
            //判断是否包含身份证
            if (cardList && _.size(cardList) > 0) {
                return cardList[0];
            } else {//否则返回其他类型
                return certList[0];
            }
        }
    },
    /**
     * 合并数组
     */
    mergeArray: function (arr1, arr2) {
        return arr1.concat(arr2);
    },
    /**
     * 清空我的订单缓存数据
     */
    clearMyOrderAndApverCache: function () {
        //myOrder
        params.myOrderTempData.allTempData = [];
        params.myOrderTempData.planTempData = [];
        params.myOrderTempData.apverTempData = [];
        params.myOrderTempData.submitTempData = [];
        params.myOrderTempData.finishTempData = [];
        //apver
        params.apverListTempData.waitApverTempData = [];
        params.apverListTempData.passApverTempData = [];
        params.apverListTempData.refuseApverTempData = [];
    },
    parseDate: function (dt) {
        var date = Date.parse(dt);

        if (isNaN(date) && /\/|\-/.test(dt)) {
            var arys = new Array();
            arys = dt.split('-');
            date = new Date(arys[0], arys[1] - 1, arys[2]);
        }

        return date;
    },
    /**
     日期时间格式化
     **/
    formatDate: function (dateObj, fmtStr, cap) {
        var self = this;
        if (/^\d+$/.test(dateObj)) {
            dateObj = new Date(dateObj);
        } else if (/\/|\-/.test(dateObj) && !/GMT/.test(dateObj)) {//更改时区都有“GMT”标志，美国纽约“GMT-”,中国“GMT+”，所以过滤带有GMT的date changed by zjf 2016-5-31
            dateObj = new Date(dateObj.replace(/\-/g, "/"));
        }
        var y = dateObj.getFullYear().toString();
        var m = dateObj.getMonth() + 1;
        var d = dateObj.getDate();
        var h = dateObj.getHours();
        var i = dateObj.getMinutes();
        var s = dateObj.getSeconds();
        var w = dateObj.getDay();
        var f = function (n) {
            return function (s) {
                return s.length > 1 && n < 10 ? "0" + n : n;
            };
        };
        var attr = cap ? "" : "i";
        return fmtStr.replace(new RegExp("Y+", attr), function (s) {
            return y.slice(-s.length);
        })
            .replace(new RegExp("M+", attr), f(m))
            .replace(new RegExp("D+", attr), f(d))
            .replace(new RegExp("H+", attr), f(h))
            .replace(new RegExp("I+", attr), f(i))
            .replace(new RegExp("S+", attr), f(s))
            .replace(/w/i, function (s) {
                return s == "w" ? w : self.lang.short_week[w];
            });
    },
    /**
     日期时间格式化为xx月xx日
     fmtStr ==mm-dd
     **/
    formatShortDate: function (dateObj, fmtStr, store) {
        var self = this;
        var dateObj = self.formatDate(dateObj, fmtStr);
        var arr = dateObj.split('-');
        var date = "";
        if (store.getLang() != 'en-us') {//针对英文修改日期显示
            date = (arr[0].charAt(0) == '0' ? arr[0].charAt(1) : arr[0]) + self.lang.month + (arr[1].charAt(0) == '0' ? arr[1].charAt(1) : arr[1]) + self.lang.day;
        } else {
            date = arr[1] + self.lang.enMonths[arr[0]];
        }
        return date;
    },
    /**
     日期时间格式化为xx月xx日
     fmtStr ==mm-dd
     **/
    formatEnChShortDate: function (dateObj, fmtStr, store) {
        var self = this;
        var dateObj = self.formatDate(dateObj, fmtStr);
        var arr = dateObj.split('-');
        var date = "";
        if (store.getLang() != 'en-us') {
            date = (arr[0].charAt(0) == '0' ? arr[0].charAt(1) : arr[0]) + self.lang.month + (arr[1].charAt(0) == '0' ? arr[1].charAt(1) : arr[1]) + self.lang.day;
        } else {//针对英文修改日期显示 格式改为10Jul
            date = arr[1] + self.lang.enMonths[arr[0]].substring(0, self.lang.enMonths[arr[0]].length - 1);
        }
        return date;
    },
    /**
     日期时间格式化为xx月xx日，xx.xx
     fmtStr ==mm-dd
     **/
    formatHotelDate: function (dateObj, fmtStr, store) {
        var self = this;
        var dateObj = self.formatDate(dateObj, fmtStr);
        var arr = dateObj.split('-');
        var date = "";
        if (store.getLang() != 'en-us') {
            date = (arr[0].charAt(0) == '0' ? arr[0].charAt(1) : arr[0]) + self.lang.month + (arr[1].charAt(0) == '0' ? arr[1].charAt(1) : arr[1]) + self.lang.day;
        } else {//针对英文修改日期显示 格式改为
            date = (arr[0].charAt(0) == '0' ? arr[0].charAt(1) : arr[0]) + '.' + (arr[1].charAt(0) == '0' ? arr[1].charAt(1) : arr[1]);
        }
        return date;
    },
    /**
     * 英文日期格式
     */
    enFormatDate: function (curData, tripType) {
        var dt = curData;
        var m = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        var w = new Array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat");
        //var d=new Array("st","nd","rd","th");
        mn = dt.getMonth();
        wn = dt.getDay();
        dn = dt.getDate();
        /*//var dns;
         if(((dn%10)<1) ||((dn%10)>3)){
         //dns=d[3];
         }else{
         //dns=d[(dn%10)-1];
         if((dn==11)||(dn==12)){
         //dns=d[3];
         }
         }*/
        if (tripType) {//行程日历英文格式Sun,15 Jun，不显示年份
            return w[wn] + "," + dn + " " + m[mn];
        }
        else {
            return w[wn] + "," + dn + " " + m[mn] + "," + dt.getFullYear();
        }
    },
    /**
     * 字符串转化日期类型，判断当前是星期几
     */
    stringToWeek: function (dateStr) {
        var self = this;
        //var _weekDay = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];

        var _dateValue = new Date(Date.parse(dateStr.replace(/-/g, "/")));
        return self.lang.short_week[_dateValue.getDay()];

        /*if(lang){
         return self.lang.short_week[_dateValue.getDay()];
         }
         else {
         return _weekDay[_dateValue.getDay()];
         }*/
    },
    /**
     * 替换数组中的元素
     * orderArr 订单数组
     * key      比较参数，通过它找到被替换item的位置
     * item     将要替换成的数据
     */
    replaceOrderItem: function (orderArr, key, item) {
        var bln = false;
        try {
            for (i = 0; i < orderArr.length; i++) {
                if (orderArr[i].journeyno == key) {
                    orderArr.splice(i, 1, item);
                    return true;
                }
            }
        } catch (e) {
            bln = false;
        }
        return bln;
    },
    /**
     * 判断缓存数组中是否包含该订单
     * @param key
     * @returns {Boolean}
     */
    containsOrder: function (orderArr, key) {
        var bln = false;
        try {
            for (i = 0; i < orderArr.length; i++) {
                if (orderArr[i].journeyno == key) {
                    bln = true;
                }
            }
        } catch (e) {
            bln = false;
        }
        return bln;
    },
    /**
     * 往返特价计算折扣价
     * @param discount
     * @returns
     */
    convertDiscount: function (discount, store) {
        var self = this;
        if (discount == 10)
            return self.lang.full_price;
        else if (discount == 0)
            return '';
        else if (discount == -1)
            return '';
        else
            return this.getDiscount(discount, store);
    },
    //获取中英文的折扣UI
    getDiscount: function (n, store) {
        var self = this;
        //英文版的折扣计算，保留一位小数 Math.round((10-n) * 10) / 10
        n = store.getLang() != 'en-us' ? n : Math.round((10 - n) * 10) / 10;
        return self.lang.discount.replace("{n}", store.getLang() != 'en-us' ? n : n * 10);
    },
    /**
     * 舱位数
     */
    converCabinCount: function (count) {
        var self = this;
        if (count == 'A') {
            return '';//'＞'+self.lang.cabinCount.replace("{n}",9); //新国内流程，大于9张就不显示票数 2015/7/20 by zg
        } else if (count != 'A' && !_.isEmpty(count)) {
            return self.lang.cabinCount.replace("{n}", count);
        } else {
            return self.lang.cabinCountOther;
        }
    },
    /**
     * 我的订单数据刷新
     * @param data
     */
    updateAllOrderList: function (data) {
        var self = this;
        var len = data.length;
        if (null == params.myOrderTempData.allTempData || params.myOrderTempData.allTempData.length < 1) {
            params.myOrderTempData.allTempData = data;
        }
        else {
            //获取allTempData中最新数据的创建时间
            var allTempDataLastestTime = params.myOrderTempData.allTempData[0].createDate;
            //循环更新替换列表中的旧数据
            for (var i = 0; i < len; i++) {
                var curNewOrder = data[i];
                var curOrderCreateDate = curNewOrder.createDate;
                if (self.containsOrder(params.myOrderTempData.allTempData, curNewOrder.journeyno)) {
                    self.replaceOrderItem(params.myOrderTempData.allTempData, curNewOrder.journeyno, curNewOrder);
                } else if (curOrderCreateDate - allTempDataLastestTime > 0) {
                    //判断当前数据是否比allTempData的第一条数据新
                    params.myOrderTempData.allTempData.unshift(curNewOrder);
                }
            }
        }
    },
    /**
     * 判断是否是中航工业
     */
    ifAvic: function (_myInfo) {
    	if(_myInfo.serviceCode.toLocaleLowerCase().indexOf("avic") == 0 && _myInfo.agentId == 212){
            return true;
        }
        else {
            return false;
        }
    },
    /**
     * 根据航班号和起飞日期判断是否在关注列表中
     */
    getFollowList: function (array, flight_num, flight_date) {
        var _array = [];
        for (var i in array) {
            var item = array[i];
            var _date = new Date(item.takeoffTime);
            var _month = _date.getMonth() + 1;//月份
            if (_month < 10) {
                _month = "0" + _month;
            }
            var _day = _date.getDate();//天
            if (_day < 10) {
                _day = "0" + _day;
            }
            _date = _date.getFullYear() + "" + _month + "" + _day;
            var flightNo = item.airline + item.flightNo;
            if (flightNo == flight_num && _date == flight_date) {
                _array.push(item);
                break;
            }
        }
        return _array;
    },
    /**
     * 判断缓存数组中是否包含该订单,并返回结果
     * @param key
     * @returns {Boolean}
     */
    containsOrderItem: function (orderArr, key) {
        var bln = null;
        try {
            for (i = 0; i < orderArr.length; i++) {
                if (orderArr[i].journeyno == key) {
                    bln = orderArr[i];
                }
            }
        } catch (e) {
            bln = null;
        }
        return bln;
    },
    /**
     * 移除缓存订单数组中的某个元素
     * orderArr 目标数组
     * key 数组中某个元素的属性
     */
    removeOrderItem: function (orderArr, key) {
        var bln = false;
        try {
            for (i = 0; i < orderArr.length; i++) {
                if (orderArr[i].journeyno == key) {
                    orderArr.splice(i, 1);
                    return true;
                }
            }
        } catch (e) {
            bln = false;
        }
        return bln;
    },
    /**
     * 获取当前级别审批人信息
     * @param curLevel 当前级别
     */
    getFirstApprovPersonInfo: function (curLevel, params) {
        //var data = app.store.getMyInfo().approveRuleInfo.approverUserInfoList;
        var data = [];
        if (params.order.defaultApperList) {
            data = params.order.defaultApperList;
        }
        return Enumerable.From(data).Where(function (x) {
            return x.apverlevel == curLevel;
        }).ToArray()[0];
    },
    /**
     *
     * @param allTempData
     * @param targetTempData 更新到目标临时数组
     * @param journeyNo  航班号
     * @param orderState 将要被更新的状态
     */
    updateCacheDataList: function (allTempData, targetTempData, journeyNo, orderState) {
        var me = this;
        //获取item
        var oldAirItem = me.containsOrderItem(allTempData, journeyNo);
        //处理allTempData数据集
        if (oldAirItem != null) {
            oldAirItem.orderState = orderState;//oldAirItem由'计划'变 '取消'
            me.replaceOrderItem(allTempData, journeyNo, oldAirItem);
        }
        //处理finishTempData数据集
        if (oldAirItem != null && me.containsOrder(targetTempData, journeyNo)) {
            //targetTempData.unshift(oldAirItem);
            me.replaceOrderItem(targetTempData, journeyNo, oldAirItem);
        } else if (oldAirItem != null) {
            if (targetTempData) {
                targetTempData.unshift(oldAirItem);
            }
            //des 排序
            //targetTempData = Enumerable.From(targetTempData)["OrderByDescending"](function(x){ return x.createDate}).ToArray();
        }
        oldAirItem = null;
    },
    /**
     * 字符串转化日期类型，判断当前是星期几
     */
    stingToWeek: function (dateStr) {
        var _weekDay = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
        var _dateValue = new Date(Date.parse(dateStr.replace(/-/g, "/")));
        return _weekDay[_dateValue.getDay()];
    },
    /**
     * 昨天.今天.明天
     * @param dateObj 日期对象
     * @returns
     */
    formatTripListDate: function (dateObj, lang) {
        var self = this;
        var _today = new Date();
        var y = _today.getFullYear();
        var m = _today.getMonth();
        var d = _today.getDate();
        var time = new Date(y, m, d).getTime();

        var t = dateObj.getTime();
        var o = {des: "", ret: 1};
        if (t < time && t >= time - 86400000) {
            o.des = lang.yesterday;
        } else if (t >= time && t < time + 86400000) {
            o.des = lang.today;
            o.ret = 0;
        } else if (t >= time + 86400000 && t < time + 86400000 * 2) {
            o.des = lang.tomorrow;
        } else {
//				o.des=dateObj.getMonth()+1 + "-" + dateObj.getDate();
        }
        //历史行程
        if (t < time) {
            o.ret = -1;
        }
        return o;
    },
    //开启消息推送服务
    generatePushClientAccount: function (data) {
        if (window.plugins && window.plugins.asmackPush) {
            window.plugins.asmackPush.generatePushClientAccount(data);
        }
    },
    //通过广播开启消息推送服务
    startPushService: function () {
        if (window.plugins && window.plugins.asmackPush) {
            window.plugins.asmackPush.startPushService();
        }
    },
    //关闭消息推送服务
    stopPushService: function () {
        if (window.plugins && window.plugins.asmackPush) {
            window.plugins.asmackPush.stopPushService();
        }
    },
    //去掉字符串空格
    removeStrBlank: function (_str) {
        if (_str == null || _str == undefined) {
            return;
        }

        var tmpStr = _str;
        tmpStr = tmpStr.replace(/\s/g, "");

        return tmpStr;
    },
    getBundleVersion: function (_callback) {
        var self = this;
        if (self.browerVersion('iOS') && Cordova) {
            Cordova.exec(function (_versionArray) {
                if (_versionArray.length == 0) {
                    return;
                }
                var versionStr = _versionArray[0];
                _callback(versionStr);
            }, function () {
            }, "GetSystemVersion", "getBundleVersion", ["getBundleVersion"]);

        }
    },
    /**
     获取第三方app传值
     **/
    gettransfervalue: function (_callback) {
        var self = this;
        if (self.browerVersion('iOS') && Cordova) {
            Cordova.exec(_callback, function () {
            }, "Utils", "gettransfervalue", ["gettransfervalue"]);
        }
    },
    /**
     更新iOS插件
     **/
    updateIOSPlugin: function (rs) {
        var self = this;
        if (rs && rs.state == 1 && rs.data != null) {//成功
            var pluginVersion = rs.data.pluginVersion/*test*/;

            if (pluginVersion > self.config.get('version')) {
                //调用native插件更新
                if (self.browerVersion('iOS') && Cordova) {
                    Cordova.exec(function () {
                    }, function () {
                    }, "UpdatePlugin", "updatePlugin", [rs.data.addr, self.lang]);
                }
            }
        }
        //失败不处理
    },
    /**
     针对ios7日期控件显示中文的问题进行修改
     _view为日期控件所在的view
     _className为input父节点的class
     **/
    modifyDatePicker: function (_view, _className) {

        if (_view == null || _view == undefined || _className == null || _className == undefined || _className == '') {
            return;
        }

        var self = this;

        if (self.browerVersion('iOS') && Cordova) {
            Cordova.exec(function (_version) {
                if (_version.length == 0) {
                    return;
                }

                var tmpVersion = _version[0];

                if (tmpVersion < '7.0') {
                    return;
                }

                var boxes = _view.$el.find('.' + _className);
                //清除掉多余的input
                $.each(boxes, function () {
                    if ($(this).find('input').length == 2) {
                        $(this).find('input:first').remove();
                    }
                });

                var inputList = _view.$el.find('.' + _className + ' input');

                $.each(inputList, function () {
                    $(this).parent().css('position', 'relative');
                    $(this).css('opacity', '0');
                    $(this).attr('style', 'position:absolute;top:0;z-index:1;opacity:0;');

                    var dateValue = $(this).val();

                    $(this).before('<input data-role="none" class="gx-date-input" type="text" readonly="readonly" style="position:absolute;top:0;z-index:2;background:none;"  value="' + dateValue + '" />');

                    $(this).prev().click(function () {
                        $(this).next().trigger('focus');
                    });
                    $(this).change(function () {
                        var dateVal = $(this).val();
                        $(this).prev().val(dateVal);
                    });
                });
            }, function () {
            }, "GetSystemVersion", "getSystemVersion", ["getVersion"]);
        }


    },
    /**
     * 获取当前应用的语言（中/英）
     */
    getAppLang: function (store) {
        var self = this;
        if (store.getLang() == 'zh-cn') {
            self.lang = Chinese;
        }
        else if (store.getLang() == 'zh-tw') {
            self.lang = ChineseTw;
        }
        else {
            self.lang = English;
        }
    },
    getEnLang: function () {
        return English;
    },
    getZhLang: function () {
        var self = this;
        if (self.lang) {
            return self.lang;
        }
        else {
            return Chinese;
        }
        //return Chinese;
    },
    /**
     * 设置主题样式
     */
    setTheme: function (store) {
        var theme = store.getTheme();
        //判断主题
        if (theme == 'blue') {
            store.setLinkTheme('blue');
        }

        if (theme == 'green') {
            store.setLinkTheme('green');
        }
    },

    /**
     * 对象克隆
     * obj 被克隆对象
     */
    objClone: function (obj) {
        var o;
        switch (typeof obj) {
            case 'undefined':
                break;
            case 'string'   :
                o = obj + '';
                break;
            case 'number'   :
                o = obj - 0;
                break;
            case 'boolean'  :
                o = obj;
                break;
            case 'object'   :
                if (obj === null) {
                    o = null;
                } else {
                    if (obj instanceof Array) {
                        o = [];
                        for (var i = 0, len = obj.length; i < len; i++) {
                            o.push(this.objClone(obj[i]));
                        }
                    } else {
                        o = {};
                        for (var k in obj) {
                            o[k] = this.objClone(obj[k]);
                        }
                    }
                }
                break;
            default:
                o = obj;
                break;
        }
        return o;
    },
    /**
     * 将null与undefined字段转为''
     * 确保返回数据格式为字符串
     */
    killNull: function (str) {
        return str === null || str === undefined || str === 'null' ? '' : str + '';
    },
    /**
     * 判断对象是否为null，undefined，''
     */
    ifEmpty: function (str) {
        return str === null || str === undefined || str == '' || str === 'null';
    },
    /**
     * 判断数组对象是否为null，undefined，长度为0
     */
    ifArrEmpty: function (arr) {
        return arr === null || arr === undefined || arr.length == 0 || arr == '' || arr === 'null';
    },
    /**
     * 判断字符串中是否包含中文
     */
    ifHasChinese: function (str) {
        if (escape(str).indexOf("%u") < 0) {
            return false;
        } else {
            return true;
        }
    },
    /**
     * 初始化添加新(机票/酒店)单元的参数
     * type 0:机票，1:酒店 2:火车
     */
    initItemParams: function (store, type) {
        var self = this;
        params.isNew = false;//非新行程
        params.order.serviceCodeId = store.getMyInfo().serviceCodeId;
        params.order.serviceCode = store.getMyInfo().serviceCode;
        //新增航空单元，旅客联系人信息不可变
        if (params.order.jourState != -1) {
            var airItemList = params.order.airItemInfoList;
            var hotelItemList = params.order.hotelItemInfoList;
            var trainItemList = params.order.trainItemInfoList;
            if (!_.isEmpty(airItemList)) {
                var airItemListT = _.clone(airItemList).reverse();
                var passenger = airItemListT[0].passengerInfoList[0];
                self._initContact(passenger);
                //保存最新订单的酒店入住城市、入住日期、离店日期
                //取最近(时间)的航段
                var segment = "";
                if (airItemListT[0].interFlag == 1) {//国际订单
                    segment = airItemListT[0].oneWayList[0] ? airItemListT[0].oneWayList[0].segmentInfoList[0] : null;
                }
                else {
                    segment = airItemListT[0].segmentInfoList[0];
                }
                var takeoffDate = segment.takeoffTime.substring(0, 10);
                var date = new Date(takeoffDate);
                date.setDate(date.getDate() + 1);
                if (!_.isEmpty(segment)) {
                    if (_.isEqual(type, 0)) {
                        params.query.depApt = segment.arriveStn;
                        params.query.arrApt = segment.takeoffStn;
                        params.query.depDate = self.formatDate(date, "yyyy-mm-dd");
                        params.query.retDate = self.formatDate(date.setDate(date.getDate() + 1), "yyyy-mm-dd");
                    } else {
                        params.order_hotel.arrDate = segment.arriveTime.substring(0, 10);
                        //如果入店日期和离店日期相同 ,则离店日期+1
                        if (_.isEqual(params.order_hotel.arrDate, takeoffDate)) {
                            params.order_hotel.depDate = self.formatDate(date, "yyyy-mm-dd");
                        } else {
                            params.order_hotel.depDate = takeoffDate;
                        }
                        //在机票订单里添加酒店，应该默认抵达地城市为入住城市 add 2014-7-10
                        params.order_hotel.arriveStn = segment.arriveStn;
                    }
                }
                airItemListT = null;
                date = null;
            } else if (!_.isEmpty(hotelItemList)) {
                var passenger = hotelItemList[0].passengerVOList[0];
                self._initContact(passenger);
                //日期
                if (!_.isEmpty(hotelItemList)) {
                    params.query.depDate = hotelItemList[0].checkInDate.substring(0, 10);
                    params.query.retDate = hotelItemList[0].checkOutDate.substring(0, 10);
                    //在酒店订单里添加机票，应该默认入住城市为目的地城市 add 2014-7-10
                    params.query.arrApt = hotelItemList[0].hotelCity;
                }
            } else if (!_.isEmpty(trainItemList)) {

                var passenger = trainItemList[0].passengerInfoList[0];
                self._initContact(passenger);
                var isChinese = (store.getLang() != 'en-us') ? true : false;


                params.bookDepSta = isChinese ? trainItemList[0].arrivalStationNameCN : trainItemList[0].arrivalStationNameEN;
                params.bookArrSta = isChinese ? trainItemList[0].departureStationNameCN : trainItemList[0].departureStationNameEN;


            }
        }
    },
    /**
     * 获取订单中机票和酒店单元中的所有乘客列表为默认的已选乘客 add zcy
     */
    initOrderPassenger: function () {
        var self = this;
        var hotelItemInfoList = params.order.hotelItemInfoList;
        var airItemInfoList = params.order.airItemInfoList;
        var trainItemInfoList = params.order.trainItemInfoList;

        var checkInPeopleList = [];
        if (airItemInfoList && airItemInfoList.length != 0) {
            for (var i in airItemInfoList) {
                var passengerInfoList = airItemInfoList[i].passengerInfoList;
                for (var j in passengerInfoList) {
                    if (!self._arrPassengerIndex(checkInPeopleList, passengerInfoList[j])) {
                        checkInPeopleList.push(passengerInfoList[j]);
                    }
                }
            }
        }
        if (hotelItemInfoList && hotelItemInfoList.length != 0) {
            for (var i in hotelItemInfoList) {
                var passengerVOList = hotelItemInfoList[i].passengerVOList;
                for (var j in passengerVOList) {
                    if (!self._arrPassengerIndex(checkInPeopleList, passengerVOList[j])) {
                        checkInPeopleList.push(passengerVOList[j]);
                    }
                }
            }
        }

        if (trainItemInfoList && trainItemInfoList.length != 0) {
            for (var i in trainItemInfoList) {
                var passengerVOList = trainItemInfoList[i].passengerInfoList;
                for (var j in passengerVOList) {
                    if (!self._arrPassengerIndex(checkInPeopleList, passengerVOList[j])) {
                        checkInPeopleList.push(passengerVOList[j]);
                    }
                }
            }
        }
        params.selectedUserList = checkInPeopleList;
    },
    /**
     * 判断数组中是否含相同的入住人 add zcy
     */
    _arrPassengerIndex: function (arr, obj) {
        if (arr && arr.length != 0) {
            for (var i in arr) {
                if (arr[i].psgParId == obj.psgParId) {
                    return true;
                }
            }
        }
        return false;
    },
    /**
     * 同步联系人信息
     */
    _initContact: function (passenger) {
        var self = this;
        for (var i in params.selectedUserList) {
            var user = params.selectedUserList[i];
            user.contactEmail = passenger.contactEmail;
            user.contactName = passenger.contactName;
            user.contactTel = passenger.contactTel;
        }
    },
    /**
     * 退出清除数据
     */
    logoutClearData: function (sgClient, store) {
        var self = this;
        store.setToken(null);
        sgClient.clearAirportCache();
        store.setData("$myinfo", null);
        /*
         * COZYGO-111  解决新版本用户登录进入到老版本的隐患
         * 需求：
         * 1、app退出登录时应保存配置项。
         * 2、当下次登录时如果读取后台配置发生错误，应首先读取用户本地历史配置项，按历史配置项走相应流程。如果未读取到或读取错误，则阻止用户本次登录操作，返回登录失败。
         */
//			store.setData("$myservicecode", null);//老配置
        store.setData("$DeliveryAddress", null);
        store.setData('$agentConfig', null);//清空多供应商选择
        store.setData('$agentFlag', null);//清空多供应商标志
        store.setData('$userHistory', null);//清空乘机人历史
        store.setData('$tempUserHistory', null);//清空临客历史
        store.setData('$reasonArray', null);//清空拒绝历史原因
        store.setData('$noticeData', null);//清空国际航班查询起降时间提醒标志
        store.removeData("$localCityData");//清除专车定位地址，登录后重新获取
        store.removeData("locationCity");//清除本地缓存最近BCD酒店城市数据
        store.removeData("locationCity1");//清除本地缓存最近国内酒店城市数据
        store.removeData("locationCity2");//清除本地缓存最近国际酒店城市数据
        store.setData("isItinerary", null);//清空FCM抄送标识
        store.setData("broadArray", null);//清空广播缓存
        store.setApprModel(null);//运通清空当前缓存的审批模式
        store.setTimePoint(null);//清除判断更新数据的时间点
        store.setAppConfig(null);//清空配置项，新配置
        //store.setData('$showYearShare',null);//清空年终行程标记
        store.setOrderListIndex(0);
        store.setReviewListIndex(0);
        store.setData('$showGuide', "showGuide");//退出防止有些机型再次进入引导页，重新加个标志
        self.clearMyOrderAndApverCache();
        var amexTxt = window.localStorage;//遍历清空amex下的文本历史记录
        for(var i = 0;i < amexTxt.length;i ++){
            if(amexTxt.key(i).indexOf("amex-txt-option") >= 0){
                store.removeData(amexTxt.key(i));
            }
        }
        params.selectedUserList = [];
        params.query.depTime = '';//初始化(中英文切换,初始化数据)
        params.query.retTime = '';//初始化(中英文切换,初始化数据)
        if (store.getTempOftenTripCardInfoList() != null)
            store.setTempOftenTripCardInfoList(null);
        // 当当前用户注销登录之后关闭推送服务
        //self.stopPushService();
    },
    /**
     * 默认证件 1:身份证，2.护照，3.其他
     * @param psg
     * @returns
     */
    getPsgCreNumber: function (psg) {
        var creList = psg.credentialsInfoList;
        if (!_.isEmpty(creList)) {
            if (_.size(creList) == 1) {
                return creList[0];
            } else {
                for (var i = 0, len = creList.length; i < len; i++) {
                    var item = creList[i];
                    if (item.type && _.isEqual(item.type, "1")) {
                        return item;
                    } else if (item.type && _.isEqual(item.type, "2")) {
                        return item;
                    } else if (item.type && _.isEqual(item.type, "3")) {
                        return item;
                    }
                }
            }
        } else {
            return null;
        }
    },
    showPayAlert: function (_price, _sureCallBack, _cancelCallBack) {
        var self = this;
        var html = [];

        html.push('<div class="pay-box">');
        html.push('<div class="pay-box-title">' + self.lang.yee_pay_pwd + '</div>');
        html.push('<div class="pay-price">' + self.lang.yee_pay_price + _price + '</div>');
        html.push('<div class="pwd-box">');
        html.push('<div></div><div></div><div></div><div></div><div></div><div></div>');
        html.push('</div>');
        html.push('<input id="PayPwdInput" type="tel" maxlength="6" data-role="none"/>');
        html.push('<div class="ui-grid-a">');
        html.push('<div class="ui-block-a"><button id="CancelBtn" class="alert-btn-cancel ui-btn ui-shadow ui-corner-all">');
        html.push(self.lang['cancel'] + '</button></div>');
        html.push('<div class="ui-block-b"><button id="SureBtn" class="alert-btn-sure-disable ui-btn ui-shadow ui-corner-all">');
        html.push(self.lang['ok'] + '</button></div>');
        html.push('</div>');
        html.push('</div>');
        html.push('<div class="select-mask"></div>');
        $('body').append(html.join(''));

        var page = $('div[data-role="page"]');
        $.each(page.children(), function () {
            $(this).addClass('frosted-glass');
        });

        //计算位置
        var bodyClientHeight = document.body.clientHeight;
        var box = $('.pay-box');
        var boxHeight = box.height();
        box.css('top', bodyClientHeight / 2 - boxHeight + 'px');

        //隐藏的数字输入框
        var ipt = $('#PayPwdInput');
        ipt[0].focus();

        //密码输入外框
        var pwdBox = $('.pwd-box').unbind('click').bind('click', function () {
            ipt[0].focus();
        });

        //显示的6个密码输入框
        var pwdIpt = $('.pwd-box div');

        //取消按钮
        var cancelBtn = $('#CancelBtn');
        //确定按钮
        var sureBtn = $('#SureBtn');

        ipt.on('input', function () {
            var txt = ipt.val();
            for (var i = 0; i < pwdIpt.length; i++) {
                var tmpPwdIpt = pwdIpt.eq(i);
                var dot = tmpPwdIpt.find('.dot');

                if (i < txt.length) {
                    if (dot.length == 0) {
                        tmpPwdIpt.append('<span class="dot"></span>');
                    }
                } else {
                    if (dot.length > 0) {
                        dot.remove();
                    }
                }

            }

            if (txt.length == 6) {
                sureBtn.removeClass('alert-btn-sure-disable');
                sureBtn.addClass('alert-btn-sure');
            } else {
                sureBtn.removeClass('alert-btn-sure');
                sureBtn.addClass('alert-btn-sure-disable');
            }
        });


        cancelBtn.unbind('click').bind('click', function () {
            $('.select-mask').remove();
            box.remove();
            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });
            if (_cancelCallBack) {
                _cancelCallBack();
            }
        });


        sureBtn.unbind('click').bind('click', function () {
            var tmpPwd = ipt.val();

            if (tmpPwd.length < 6) {
                return;
            }

            $('.select-mask').remove();
            box.remove();

            $.each(page.children(), function () {
                $(this).removeClass('frosted-glass');
            });

            if (_sureCallBack) {
                _sureCallBack(tmpPwd)
            }

        });


    },

    //易行 将时间转为分秒格式(物理格式，如：3′44″)
    convertTimeFormat: function (times) {
        var min = null, sec = null, ret = '--';
        if (!_.isEmpty(times) && times != 0) {
            min = parseInt(parseInt(times) / 60);
            sec = parseInt(parseInt(times) % 60);
            ret = min.toString().concat('′').concat(sec.toString()).concat('″');
        }
        min = null;
        sec = null;
        return ret;
    },
    /**
     * 运通提示
     * @param list 数据列表
     * @returns
     */
    amexRuleAlert: function (list, store) {
        var self = this;
        var text = "";
        var reg = /<(?:\/??)font(?:.*?)>/ig;//去掉文本中的font标签
        var len = list.length;
        var isChinese = (store.getLang() != 'en-us') ? true : false;
        if (len == 1) {
            text = (isChinese ? list[0].infoCN : list[0].infoEN) + "\n";
        } else {
            for (var i = 0; i < len; i++) {
                var index = parseInt(i) + 1;
                text += index + ". " + (isChinese ? list[i].infoCN : list[i].infoEN) + "\n";
            }
        }
        if (_.isEmpty(text)) {
            utils.showAlert({text: utils.lang.policy_empty_tip});
            return '';
        }
        len = null, isChinese = null;
        return utils.killNull(text).replace(reg, '');
    },

    /**
     从控件数组中找到匹配的id的控件，以数组的形式返回
     **/
    getControlsByIdList: function (_idList, _controls) {
        var tmpArray = [];
        if (!_idList || (_idList && _idList.length <= 0)) {
            return tmpArray;
        }

        if (!_controls || (_controls && _controls.length <= 0)) {
            return tmpArray;
        }

        for (var i = 0; i < _idList.length; i++) {
            var tmpId = _idList[i];
            for (var j = 0; j < _controls.length; j++) {
                var tmpItem = _controls[j];
                var tmpId2 = tmpItem.id;
                if (tmpId2 == tmpId) {
                    tmpArray.push(tmpItem);
                    continue;
                }
            }
        }
        return tmpArray;
    },
    /**
     * 判断是否是IBM
     */
    ifIBM: function (_serviceCode) {
        if (_serviceCode.toLocaleLowerCase() == "ibm") {
            return true;
        }
        else {
            return false;
        }
    },
    /**
     * 判断是否是ssvb
     */
    ifssvb: function (_serviceCode) {
        if (_serviceCode.toLocaleLowerCase() == "ssvb") {
            return true;
        }
        else {
            return false;
        }
    },
    /**
     * 判断是否是mccain
     */
    ifmccain: function (_serviceCode) {
        if (_serviceCode.toLocaleLowerCase() == "mccain") {
            return true;
        }
        else {
            return false;
        }
    },
    /**
     * 计算错失节约成本
     * policyInfo 差旅政策
     * queryFlightList   查询出的航班列表
     * selectFlightList  选择的航班
     * areaPriceFlightList  区域最低价集合
     * allDayPriceFlightList 全天最低价集合
     * depUser 是否是部门用户
     */
    _computeLostvolume: function (policyInfo
        , queryFlightList
        , selectFlightList
        , areaPriceFlightList
        , allDayPriceFlightList
        , depUser) {
        var self = this;

        //没有差旅政策
        if (_.isEmpty(policyInfo)) {
            return 0;
        }
        //没有配置最高舱位限制和最低价政策
        if (_.isEmpty(policyInfo.highestcabin) && (_.isEmpty(policyInfo.lowestprice) || policyInfo.lowestprice == '2' )) {
            return 0;
        }
        //判断选择航班是否违反差旅政策
        var _cpiList = depUser ? (!_.isEmpty(selectFlightList.cabinInfo.yeeXingFareInfoList[0]) ? selectFlightList.cabinInfo.yeeXingFareInfoList[0].contraryPolicyInfoList : null) : selectFlightList.cabinInfo.contraryPolicyInfoList;
        if (_.isEmpty(_cpiList)) {
            return 0;
        }
        // 只配置最高舱位限制政策
        if (!_.isEmpty(policyInfo.highestcabin) && (_.isEmpty(policyInfo.lowestprice) || policyInfo.lowestprice == '2' )) {
            var index = self._getindexByReasonCode(_cpiList, "C005");
            //没有违反最高舱位限制政策
            if (index == -1) {
                return 0;
            }
            //取到最高舱位的全价(测试环境全价可能为0,则错失节约成本返回0)
            var price = 0;
            if (policyInfo.highestcabin == "F") {
                price = selectFlightList.fPrice;
            } else if (policyInfo.highestcabin == "C") {
                price = selectFlightList.cPrice;
            } else if (policyInfo.highestcabin == "Y") {
                price = selectFlightList.yPrice;
            }
            return price == 0 ? 0 : selectFlightList.cabinInfo.price - price;
        }
        // 只配置最低价政策
        if (_.isEmpty(policyInfo.highestcabin) && (!_.isEmpty(policyInfo.lowestprice) && policyInfo.lowestprice != '2' )) {
            //违背全天最低价政策
            var allDay = self._getindexByReasonCode(_cpiList, "C001");
            //违背区域最低价政策
            var area = self._getindexByReasonCode(_cpiList, "C002");
            //违背基准最低价政策
            var standard = self._getindexByReasonCode(_cpiList, "C008");
            //判断是否违反差旅政策
            if (allDay == -1 && area == -1 && standard == -1) {
                return 0;
            }
            //判断区域最低价是否存在数据
            if (!_.isEmpty(areaPriceFlightList) && areaPriceFlightList.length > 0) {
                if (_.isEmpty(areaPriceFlightList[0].cabinList) || areaPriceFlightList[0].cabinList.length == 0) {
                    return 0;
                }
                var price = areaPriceFlightList[0].cabinList[0].price;
                return selectFlightList.cabinInfo.price - price;

            }
            //判断全天最低价是否存在数据
            if (!_.isEmpty(allDayPriceFlightList) && allDayPriceFlightList.length > 0) {
                if (_.isEmpty(allDayPriceFlightList[0].cabinList) || allDayPriceFlightList[0].cabinList.length == 0) {
                    return 0;
                }
                var price = allDayPriceFlightList[0].cabinList[0].price;
                return selectFlightList.cabinInfo.price - price;

            }
            return 0;
        }
        if (!_.isEmpty(policyInfo.highestcabin) && (!_.isEmpty(policyInfo.lowestprice) && policyInfo.lowestprice != '2' )) {
            //违背最高舱位政策
            var cabin = self._getindexByReasonCode(_cpiList, "C005");
            //违背全天最低价政策
            var allDay = self._getindexByReasonCode(_cpiList, "C001");
            //违背区域最低价政策
            var area = self._getindexByReasonCode(_cpiList, "C002");
            //违背基准最低价政策
            var standard = self._getindexByReasonCode(_cpiList, "C008");
            //没有违反政策
            if (cabin == -1 && allDay == -1 && area == -1 && standard == -1) {
                return 0;
            }
            //只违反最高舱位限制(比较特殊)
            if (cabin != -1 && allDay == -1 && area == -1 && standard == -1) {
                //判断是否该舱位，如果没该舱位说明要升舱
                var isHaveCabinType = false;
                var cabinType = policyInfo.highestcabin;
                for (var i = 0, len = queryFlightList.length; i < len; i++) {
                    var flight = queryFlightList[i];
                    for (var j = 0; j < flight.cabinList.length; j++) {
                        if (flight.cabinList[j].type == cabinType) {
                            isHaveCabinType = true;
                            break;
                        }
                    }
                    if (isHaveCabinType) {
                        break;
                    }
                }
                var price = 0;
                if (policyInfo.highestcabin == "F") {
                    price = selectFlightList.fPrice;
                } else if (policyInfo.highestcabin == "C") {
                    price = selectFlightList.cPrice;
                } else if (policyInfo.highestcabin == "Y") {
                    price = selectFlightList.yPrice;
                }
                if (isHaveCabinType) {
                    return price == 0 ? 0 : selectFlightList.cabinInfo.price - price;
                } else {
                    //取到当前舱位的最低价
                    var lowerPrice = 0;
                    for (var i = 0, len = queryFlightList.length; i < len; i++) {
                        var flight = queryFlightList[i];
                        for (var j = 0; j < flight.cabinList.length; j++) {
                            if (flight.cabinList[j].type == selectFlightList.cabinInfo.type) {
                                lowerPrice = flight.cabinList[j].price < price || lowerPrice == 0 ? flight.cabinList[j].price : lowerPrice;
                            }
                        }
                    }
                    //跟最高舱位做比较
                    price = price == 0 || lowerPrice < price ? lowerPrice : price;
                    return selectFlightList.cabinInfo.price - price;
                }
            }
            //违反最低价
            if (allDay != -1 || area != -1 || standard != -1) {
                //判断区域最低价是否存在数据
                if (areaPriceFlightList != null && areaPriceFlightList.length > 0) {
                    if (areaPriceFlightList[0].cabinList == null || areaPriceFlightList[0].cabinList.length == 0) {
                        return 0;
                    }
                    var price = areaPriceFlightList[0].cabinList[0].price;
                    return selectFlightList.cabinInfo.price - price;

                }
                //判断全天最低价是否存在数据
                if (allDayPriceFlightList != null && allDayPriceFlightList.length > 0) {
                    if (allDayPriceFlightList[0].cabinList == null || allDayPriceFlightList[0].cabinList.length == 0) {
                        return 0;
                    }
                    var price = allDayPriceFlightList[0].cabinList[0].price;
                    return selectFlightList.cabinInfo.price - price;

                }
            }
            return 0;
        }
        _cpiList = null;
    },

    /**
     * @param array
     * @param value
     * @returns {Number}
     */
    _getindexByReasonCode: function (array, value) {
        for (var i in array) {
            if (array[i].reasonCode == value) {
                return i;
            }
        }
        return -1;
    },
    /**
     * 航段和航空单元拼接违返政策的内容
     */
    _getContraryPolicyInfo: function (cpiList, airItem, _segment) {
        if (cpiList) {
            $.each(cpiList, function () {
                var zhc = utils.getZhLang().reasonList[this.reasonCode];
                if (zhc && zhc != "") {
                    airItem.contrContent.push(zhc);//拼接违返政策的内容
                    if (_segment && _segment.contrContent != undefined) {//判断是否往返，往返则往里面加入相应值
                        _segment.contrContent.push(zhc);//拼接违返政策的内容
                    }
                }
                //
                var enc = utils.getEnLang().reasonList[this.reasonCode];
                if (enc && enc != "") {
					if(enc.indexOf("{flighttime}") >= 0){
						enc = enc.replace("{flighttime}",params.query.policyInfo.flighttime);
					}
					else if(enc.indexOf("{timeparthour}") >= 0){
						enc = enc.replace("{timeparthour}",params.query.policyInfo.timeparthour);
					}
                    airItem.contrContentEn.push(enc);//拼接违返策的内容英文；
                    if (_segment && _segment.contrContentEn != undefined) {//判断是否往返，往返则往里面加入相应值
                        _segment.contrContentEn.push(enc);//拼接违返策的内容英文；
                    }
                }
            });
        }
    },

    /**
     * 替换字符串
     * str 要被替换的内容
     * str1 替换的后的内容
     * str2 完整字符串
     */
    replaceStr: function (str, str1, str2) {
        return str2.replace(str, str1);
    },

    /**
     * COZYGO-88 往返程预订可以选择不同的常旅客卡 by zg  2015-1-19 v2.1.4
     * 判断往返程是否是相同的航空公司
     */
    isSameAirCompany: function () {
        var self = this;
        airItemList = params.order.airItemInfoList;
        isSame = false;
        for (var i = 0, len = airItemList.length; i < len; i++) {
            airItem = airItemList[i];
            if (!_.isEmpty(airItem) && (!_.isEmpty(airItem.lowestType) || (airItem.airItemState == 1))) {
                continue;
            }
            if (!_.isEqual(airItem.jourType, "OW")) {
                var goCarriageAirline = null, goMarketAirline = null,
                    backCarriageAirline = null, backMarketAirline = null;
                //默认往返在前端只有两个航段
                for (var j = 0; j < airItem.segmentInfoList.length; j++) {
                    var segment = airItem.segmentInfoList[j];
                    if (_.isEqual("O", segment.oi)) {//去程
                        goCarriageAirline = segment.carriageAirline;
                        goMarketAirline = segment.marketAirline;
                    } else if (_.isEqual("I", segment.oi)) {
                        backCarriageAirline = segment.carriageAirline;
                        backMarketAirline = segment.marketAirline;
                    }
                }
                isSame = _.isEqual(goCarriageAirline, backCarriageAirline);
            }
        }
        return isSame;
    },
    /**
     * COZYGO-88 往返程预订可以选择不同的常旅客卡 by zg  2015-1-19 v2.1.4
     * 循环清除乘机人的常客卡，目前每个订单的常客卡都需要每次重新选择
     */
    clearPsgMemCard: function () {
        var self = this;
        for (var i in params.selectedUserList) {
            var psg = params.selectedUserList[i];
            //循环清空
            psg.memCard = '';
        }
        return params.selectedUserList;
    },
    /**
     *    检查起飞时间
     *  COZYGO-23 用户预订的航班临近起飞时间点时，系统提醒预订风险
     *  COZYGO-452 预订航班临近起飞时间配置前端修改
     */
    checkDeptTime: function (depTimeStr) {
        var self = this;
        hour = null, depTime = null;
        //ios 需要将'2015-03-26'替换为'2015/03/26'格式，否则不能获取毫秒
        if (depTimeStr && utils.getBrowser().iOS) {
            depTimeStr = depTimeStr.replace(/\-/g, "/");
        }
        var depTimeObj = new Date(depTimeStr);
        if (depTimeObj) {
            depTime = depTimeObj.getTime();
        }
        //起飞时间 - 当前时间
        hour = (depTime - _.now()) / (1000 * 60 * 60);
        depTimeObj = null;
        return parseInt(hour);
    },


    //检测火车票预订当天的日期是否大于配置的4小时
    checkTrainDeptTime: function (depTimeStr) {
        var self = this;
        hour = null, depTime = null;
        //ios 需要将'2015-03-26'替换为'2015/03/26'格式，否则不能获取毫秒
        if (depTimeStr && utils.getBrowser().iOS) {
            depTimeStr = depTimeStr.replace(/\-/g, "/");
        }
        var depTimeObj = new Date(depTimeStr);
        if (depTimeObj) {
            depTime = depTimeObj.getTime();
        }
        //起飞时间 - 当前时间
        hour = (depTime - _.now()) / (1000 * 60 * 60);
        depTimeObj = null;
        return parseFloat(hour);
    },


    /**
     * 验证酒店和机票
     * COZYGO-491 送审时验证订单必须有航空单元和酒店单元
     */
    checkAirAndHotel: function (config, _order) {
        var rs = false;
        //1.判断是否有验证配置
        if (config && _.isEqual(config.checkAirAndHotel, "Y")) {
            //2.1 判断机票单元是否有数据
            if (_order && _.size(_order.airItemInfoList) == 0) {
                utils.showAlert({text: utils.lang.is_not_air});
                rs = true;
            }
            //2.2 判断酒店单元是否有数据
            if (_order && _.size(_order.hotelItemInfoList) == 0) {
                utils.showAlert({text: utils.lang.is_not_hotel});
                rs = true;
            }
        }
        return rs;
    },
    /**
     * 获取url页面，区分不同的路由add zcy 2015-05-13
     * @returns
     */
    getUrlpath: function () {
        var curUrl = _.clone(window.location.href);
        //判断是否包含带#的路径
        if (curUrl.indexOf("#") != -1) {
            var urlAry = curUrl.split('#');
            curUrl = urlAry[1];
        }
        return curUrl;
    },
    /**
     * 验证签证有效期 ，默认180天
     * creExpireDateStr  证件到期时间
     */
    checkExpireDate: function (creExpireDateStr) {
        if (creExpireDateStr) {
            //到期时间
            var creExpireDate = new Date(creExpireDateStr);
            creExpireYear = creExpireDate.getFullYear();
            creExpireMonth = creExpireDate.getMonth() + 1;
            creExpireDay = creExpireDate.getDate();
            //当前时间
            curDate = new Date();
            curDateYear = curDate.getFullYear();
            curDateMonth = curDate.getMonth() + 1;
            curDateDay = curDate.getDate();
            //年份差
            if (creExpireYear - curDateYear > 0) {
                return false;
            } else if (creExpireYear - curDateYear == 0) {//比较月份
                if (creExpireMonth - curDateMonth > 6) {
                    return false;
                } else if (creExpireMonth - curDateMonth == 6) {//比较日期
                    if (creExpireDay - curDateDay < 0) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
            }
        }
    },
    convertCityAir: function (store, _air) {
        var isCn = store.getLang() != 'en-us' ? true : false;
        var airCity = {
            "city": isCn ? _air.city : _air.cityEn,
            "city_code": _air.city_code,
            "code": _air.code,
            "filter_char": _air.filter_char,
            "isAp": _air.isAp,
            "kw": _air.kw,
            "name": isCn ? _air.name : _air.nameEn,
            "nameEn": !_.isEmpty(_air.nameEn) ? _air.nameEn : '',
            "nation_code": _air.nation_code,
            "nation_name": isCn ? _air.nation_name : _air.nation_nameEn,
            "isCtlShow": true,
            "isOrderShow": true
        };
        isCn = null;
        return airCity;
    },
    /**
     * 获取html中内容的宽度
     */
    getStrWidth: function (str, fontSize) {
        var offsetW = 0;
        span = document.createElement("span");
        span.id = "__getwidth";
        span.className = "get-font-width";
        document.body.appendChild(span);
        span.style.visibility = "hidden";
        span.style.whiteSpace = "nowrap";
        span.innerText = str;
        span.style.fontSize = fontSize + "px";
        offsetW = _.clone(span.offsetWidth);
        //循环移除脏数据
        if ($('.get-font-width')) {
            $('.get-font-width').remove();
        }
        return offsetW;
    },
    /**
     * 获取国内机场数据
     */
    getCityList: function (sgClient, store) {
        var airCache = [], historyAir = [];
        airCache = _.clone(store.getData('$airports'));
        historyAir = store.getLastCity();
        if (!_.isEmpty(params.hotCity)) {
            var hot = params.hotCity.slice(0, params.hotCity.length).reverse();
            $.each(hot, function () {
                var _hObj = sgClient.getAirport(this);
                _hObj.kw = "*";
                airCache.unshift(_hObj);
                _hObj = null;
            });
        }

        if (historyAir && historyAir.length > 0) {
            historyAir = historyAir.slice(0, historyAir.length).reverse();
            $.each(historyAir, function () {
                var _obj = sgClient.getAirport(this);
                _obj.kw = "#";
                airCache.unshift(_obj);
                _obj = null;
            });
        }
        return airCache;
    },
    /**
     * 获取国际机场数据
     * 1.数据有问题
     * 2.切换城市后都变成首都机场了
     * '/a/b/ds'.replace(/\//g,''); json中多了‘/’,报json异常
     */
    getIntelCityList: function (store) {
        var self = this;
        var _intlCache = [], ihotCity = [], ihisCity = [];
        //热门
        ihotCity = store.getData("$top-city-airport");
        ihisCity = store.getLastIntlCity();

        if (!_.isEmpty(ihisCity)) {
            for (var i = 0, len = ihisCity.length; i < len; i++) {
                var obj = ihisCity[i];
                _intlCache.push(obj);
                obj = null;
            }
        }
        if (!_.isEmpty(ihotCity)) {
            for (var j = 0, len = ihotCity.length; j < len; j++) {
                var obj = ihotCity[j];
                _intlCache.push(obj);
                obj = null;
            }
        }
        return _intlCache;
    },

    showMessageIonic: function ($ionicLoading, text, scope) {
        $ionicLoading.show({
            template: "<div class='myloading' ng-click='tabHideMsg()'><div class='loading-gif'></div><div class='loading-title'>" + text + "</div></div>",
            noBackdrop: false,
            scope: scope
        });
    },
    hideMessageIonic: function ($ionicLoading) {
        $ionicLoading.hide();
    },
    showAlertIonic: function ($ionicPopup, option,$scope) {
        var self = this;
        if (!option) {
            return;
        }
        if (option.text == null || option.text == undefined || option.text == '' || typeof option.text != 'string') {
            return;
        }

        var okTextTmp = self.lang['ok'];
        var cancelTextTmp = self.lang['cancel'];
        if (option.okText) {
            okTextTmp = option.okText;
        }
        if (option.cancelText) {
            cancelTextTmp = option.cancelText;
        }

        var alertPopup;
        if (option.onOK && !option.onCancel) {//确定按钮
            alertPopup = $ionicPopup.alert({
                title: option.title,
                template: option.text,
                okText: okTextTmp,// String (默认: 'OK')。OK按钮的文字。
                okType: 'btn-positive',// String (默认: 'button-positive')。OK按钮的类型。
                scope: $scope
            });
            alertPopup.then(function (res) {
                option.onOK();
            });
        } else if (!option.onOK && option.onCancel) {//取消按钮
            alertPopup = $ionicPopup.alert({
                title: option.title,
                template: option.text,
                okText: okTextTmp,// String (默认: 'OK')。OK按钮的文字。
                okType: 'btn-positive',// String (默认: 'button-positive')。OK按钮的类型。
                scope: $scope
            });
            alertPopup.then(function (res) {
                option.onCancel();
            });
        } else if (option.onOK && option.onCancel) {//取消跟确定同时存在
            var confirmPopup = $ionicPopup.confirm({
                title: option.title,
                template: option.text,
                okText: okTextTmp,// String (默认: 'OK')。OK按钮的文字。
                okType: 'btn-positive',// String (默认: 'button-positive')。OK按钮的类型。
                cancelText: cancelTextTmp,// String (默认: 'OK')。OK按钮的文字。
                cancelType: '',// String (默认: 'button-positive')。OK按钮的类型。
                scope: $scope
            });
            confirmPopup.then(function (res) {
                if (res) {
                    option.onOK();
                } else {
                    option.onCancel();
                }
            });
        } else {
            alertPopup = $ionicPopup.alert({
                title: option.title,
                template: option.text,
                okText: okTextTmp,// String (默认: 'OK')。OK按钮的文字。
                okType: 'btn-positive',// String (默认: 'button-positive')。OK按钮的类型。
                scope: $scope
            });
            alertPopup.then(function (res) {
                //option.onOK();
            });
        }
    },


    /**
     * 消息提醒进入模块
     * COZYGO-255 行前选座 - 推消息，点击消息，进入“助手”页面(android)
     * 审批申请进入审批列表
     * 订单审批结果进入订单详情
     * 机票出票时限通知、机票出票成功进入消息列表（以个人-消息中心为入口）
     * 返回都是到home页面
     */
    showNotificationDetail: function (type, $state, $ionicLoading, $cacheFactory, $rootScope, $ionicPopup) {
        var self = this;
        var myCache = $cacheFactory.get('myAppCache') || $cacheFactory('myAppCache');//缓存对象

        var journeyNo = store.getNoteJourneyNo();
        var messageContent = store.getNoteMessageContent();

        // 将消息状态置为已读
        sgClient.setMessageStatus({"content": messageContent}, function (rs) {
            if (rs && rs.state == 1) {//查询成功
            } else {
            }
        });

        // 根据消息类型跳转到不同页面
        if (_.isEqual(type, "review")) {
            self.addCache(myCache, 'reviewListBack', {backPath: 'back/home'});
            $state.go('tabs.review_list');
        } else if (_.isEqual(type, "assist") || _.isEqual(type, "assistant")) {
            $state.go('tabs.assistant');
        } else if (_.isEqual(type, "order")) {
            self.showMessageIonicNotice($rootScope, $ionicLoading, self.lang.loading, true);
            sgClient.getOrderDetail(journeyNo, 1, function (rs) {
                self.hideMessageIonic($ionicLoading);
                if (rs && rs.state == 1) {
                    var data = rs.data;
                    self.jumpToOrderDetail(data, $state, myCache);
                } else {
                    self.showAlertIonic($ionicPopup, {text: rs.data});
                }
            });
        } else if (type.length > 10) {
        } else if (_.isEqual(type, "msgcenter")) {
            self.removeCache(myCache, "MessageListback");
            self.addCache(myCache, "MessageListback", "back");
            $state.go('tabs.message_center');
            // 行李清单
        } else if (_.isEqual(type, "luggageMsg")) {
            $state.go('tabs.packing_list');
        }
        /**
         * 运行完清空消息提醒
         */
        store.setData("$Note_Type", null);
        store.setData("$Note_JourneyNo", null);
        store.setData("$Note_MessageContent", null);
    },

    //跳转到订单详情需要用到的方法
    jumpToOrderDetail: function (data, $state, myCache) {
        var self = this;
        //调用成功
        params.orderInfoUserMode = 'order';
        params.order = data;
        params.query.policyInfo = params.order.travelPolicyInfo;
        params.isPersional = false;
        params.review.ruleData = params.order.approveRuleInfo;

        //获取最新的配置
        params.dynamicAppConfig = !_.isEmpty(data.unifiedConfigInfo) ? data.unifiedConfigInfo : null;

        if (params.order.airItemInfoList && params.order.airItemInfoList[0]) {

            var userList = params.order.airItemInfoList[0].passengerInfoList;
            params.selectedUserList = userList;
            params.query.userNum = userList.length;
            self.fillParamsOrderHotelData();
        }

        if (params.order.hotelItemInfoList && params.order.hotelItemInfoList.length != 0) {
            //取出所有酒店单元的乘客
            var userList = params.order.hotelItemInfoList[0].passengerVOList;
            params.selectedHotelUserList = userList;
        }

        params.toOrderInfo = 3;

        //添加订单状态缓存
        self.addCache(myCache, 'OrderDetail', {orderStatus: data.jourState});
        self.addCache(myCache, 'order_data_from', data.datafrom);//添加数据来源，线下订单详情中不可做其他操作
        self.removeCache(myCache, "orderDetailBack");
        self.addCache(myCache, 'orderDetailBack', {backPath: 'back/home'});

        $state.go('tabs.order_detail');


    },

    //保存酒店默认入住城市、入住日期、离店日期值 跳转到订单明细用
    fillParamsOrderHotelData: function () {
        var self = this;
        var length = params.order.airItemInfoList.length;
        var airItemInfo = params.order.airItemInfoList[length - 1];

        var segmentInfoList0 = airItemInfo.segmentInfoList[0];

        if (!segmentInfoList0) {
            return;
        }

        if (airItemInfo.jourType == 'OW') {//最后一个为单程
            params.order_hotel.arriveStn = segmentInfoList0.arriveStn;//入住城市
            params.order_hotel.arrDate = segmentInfoList0.arriveTime.substring(0, 10);//入住日期
            var date = new Date(params.order_hotel.arrDate);
            date.setDate(date.getDate() + 1);
            params.order_hotel.depDate = utils.formatDate(date, "yyyy-mm-dd");//离店日期

        } else {

            if (airItemInfo.segmentInfoList.length > 1) {//往返未分开

                params.order_hotel.arriveStn = segmentInfoList0.arriveStn;//入住城市
                params.order_hotel.arrDate = segmentInfoList0.arriveTime.substring(0, 10);//入住日期
                params.order_hotel.depDate = airItemInfo.segmentInfoList[1].takeoffTime.substring(0, 10);//离店日期

            } else {//往返已分开

                if (length > 1) {

                    var depAirItemInfo = params.order.airItemInfoList[length - 2];//去程
                    var dsegmentInfoList0 = depAirItemInfo.segmentInfoList[0];
                    params.order_hotel.arriveStn = dsegmentInfoList0.arriveStn;//入住城市
                    params.order_hotel.arrDate = dsegmentInfoList0.arriveTime.substring(0, 10);//入住日期
                    params.order_hotel.depDate = segmentInfoList0.takeoffTime.substring(0, 10);//离店日期
                }
            }
        }
    },

    // 由通知进页面用
    showMessageIonicNotice: function ($rootScope, $ionicLoading, text, ajaxFlag) {
        var loadingContainer = $(".loading-container");
        if (loadingContainer.length > 0 && loadingContainer[0].children.length < 1) {
            loadingContainer.append("<div class='loading'></div>");
        }
        $ionicLoading.show({
            template: "<div class='myloading' ng-click='tabHideMsgRootScope()'><div class='loading-gif'></div><div class='loading-title'>" + text + "</div></div>",
            noBackdrop: false,
            scope: $rootScope
        });
    },

    /**
     * 添加缓存
     */
    addCache: function (myCache, _pageId, _cacheObj) {
        if (_pageId == null || _pageId == undefined || _pageId == '' || _cacheObj == null || _cacheObj == undefined) {
            return;
        }
        myCache.remove(_pageId);//先移除之前缓存
        myCache.put(_pageId, _cacheObj);
    },

    /**
     * 移除指定缓存数据
     * @param _pageId
     */
    removeCache: function (myCache, _pageId) {
        if (_pageId == null || _pageId == undefined || _pageId == '') {
            return;
        }
        myCache.remove(_pageId);
    },

    // AES加密
    encryptAES: function (word, key, iv) {
        var key = CryptoJS.enc.Utf8.parse(key);// 加密密钥
        var iv = CryptoJS.enc.Utf8.parse(iv);// 初始向量
        var srcs = CryptoJS.enc.Utf8.parse(word);
        var encrypted = CryptoJS.AES.encrypt(srcs, key, {iv: iv, mode: CryptoJS.mode.CBC});
        // 转换为字符串
        return encrypted.toString();
    },

    // AES解密
    decryptAES: function (encryptedWord, key, iv) {
        var key = CryptoJS.enc.Utf8.parse(key);// 加密密钥
        var iv = CryptoJS.enc.Utf8.parse(iv);// 初始向量
        var decrypted = CryptoJS.AES.decrypt(encryptedWord, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });

        // 转换为 utf8 字符串
        decrypted = CryptoJS.enc.Utf8.stringify(decrypted);
        return decrypted;
    }

}
