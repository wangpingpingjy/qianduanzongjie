var Config = {
//		baseUrl:'http://172.22.12.119:8180/MobileOBT.WebService',
//		baseUrl:'http://122.119.144.26/MobileOBT.WebService',
		baseUrl:'https://bluesky.travelsky.com/BlueSkyMobile',//生产
//
// 		baseUrl:'http://bluesky.travelsky.com/develop/BlueSkyMobile',//yuntong
//		baseUrl:'http://172.22.12.21:8080/MobileOBT.WebService',//weizhuo
//		baseUrl:'http://172.22.12.32:8010/MobileOBT.WebService',//haiwei
//		baseUrl:'http://172.22.15.63:8090/MobileOBT.WebService',//wangxiao
//		baseUrl:'http://172.22.12.197:8080/MobileOBT.WebService',//zhaogang
//		baseUrl:'http://172.22.12.79:8090/MobileOBT.WebService',//chenying
		//baseUrl:'http://172.22.12.162:8080/MobileOBT.WebService',//wangxu
//        baseUrl:'http://10.5.78.33:8180/BlueSkyMobile',//
		//baseUrl:'http://bluesky.travelsky.com/develop/BlueSkyMobile',
		feedbackMail:'BlueskyMobile@Travelsky.com',
		isDebug: true,
		version:'3.3.0'

	}