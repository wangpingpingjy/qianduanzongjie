var sgClient = {
    baseUrl: null,
    currentRequest: null,//当前请求
    isAbort: false,
    ionicPopup: null,//弹框
    ionicLoading: null,//Loading
    /**
     设置token
     **/
    setToken: function (_token) {
        $.ajaxSetup(_token);
    },
    /**
     初始化方法
     **/
    initialize: function (SGPlugin) {
        var self = this;
        self.baseUrl = Config.baseUrl;
        //android 序列号
        if (utils.browerVersion('android')) {
//				store.getDeviceCode2(function(array){
            SGPlugin.getDeviceCode(function (array) {
                store.setNumber(array[3]);
            });
        }

        $.ajaxSetup({
            timeout: 120 * 1000,//连接120秒为超时
            beforeSend: function (xhr) {
                /*
                 * 因强制修改密码接口需要传入token，强制修改密码token并未保存，将token值作为变量传入
                 * 如保存了，而未修改，下次登录则视为已登录过，所以用另一种存储方式实现 COZYGO-2822 zjf 2016-1-27
                 */
                var _token = store.getToken();
                if (utils.ifEmpty(_token)) {
                    _token = store.getData("$changePwd_token");
                }
                xhr.setRequestHeader('mobile-obt-token', _token);
                xhr.setRequestHeader('appversion', Config.version);
                if (utils.browerVersion('android') && !_.isEmpty(store.getNumber())) {
                    xhr.setRequestHeader('number', store.getNumber());
                }
            },
            //网络错误时
            error: function (xhr, status, e) {
                var msg = status;
                //utils.hideMessage();
                if (self.ionicLoading) {
                    self.ionicLoading.hide();
                }
                if (msg == "error") {//网络连接错误
                    //后台运行的请求，在网络有问题是不做提示。
                    var ignoreAlert = ["getKey", "getAppVersion", "reloadUserInfo", "getOrderCountByApverParId", "getLatestJourney", "loadConfig", "getUnifiedConfig", "getAppConfig", "getFavoriteList", "updateEmailAndTel",
                        "logPay", "pushMessage", "getRecINFlightPrice", "getTopCityAirport", "countMoreDetailTimes",
                        "getUnusedJourney", "getHomeSwiperData", "getUnread", "CheckIn", "logIntUndefined", "logForGetCheckInList",
                        "loadBookedJourneytoCache", "loadBookedJourneyByParidstoCache", "bluesky.travelsky.com", "queryGranteeList", "checkOrderStatus", "getParCertInfo"];
                    if (!_.contains(ignoreAlert, xhr.flag)) {
                        //console.log("SGClient error xhr flag : "+xhr.flag);
                        //事件冒泡
                        setTimeout(function () {
                            utils.showAlertIonic(self.ionicPopup, {text: utils.lang.connection_failed});
                        }, 500);
                    }
                    ignoreAlert = null;
                } else if (msg == "abort") {//主动终止Ajax请求

                } else if (msg == "timeout") {//网络连接超时
                    if (xhr.flag && !("getLatestJourney,getRecINFlightPrice,CheckIn,logForGetCheckInList,logIntUndefined,countMoreDetailTimes".indexOf(xhr.flag) > -1)) {
                        utils.showAlertIonic(self.ionicPopup, {text: utils.lang.connection_timeout});
                    }
                }
            },
            dataFilter: function (data, type) {
                //json obj
                var dataTemp = utils.stringToJson(data);

                if (dataTemp && dataTemp.data == 'token error') {
                    //	utils.hideMessage();
                    self.ionicLoading.hide();
                    utils.showAlertIonic(self.ionicPopup, {
                        text: utils.lang.login_status_disconnected, onOK: function () {
                            utils.logoutClearData(self, store);
                            //剔除老版本后，登出时有缓存问题，需要刷新一下
                            if (utils.browerVersion('iOS')) {
                                window.location.href = "../../www/index7.html";
                            } else {
                                window.location.href = "../www/index_android.html";
                            }
                            //utils.getRouter().navigate("back/login",{trigger: true, replace: false});
                        }
                    });
                } else {
                    return data;
                }

            }

        });
    },
    /**
     * 终止异步请求
     */
    abortAjax: function () {
        var self = this;
        if (self.currentRequest) {
            self.currentRequest.abort();
            self.isAbort = true;
        }
    },
    /**
     * 处理URL
     * @param  {String} _url 原始URL
     * @return {String}      处理过的URL
     */
    wrapUrl: function (_url) {
        if (_url.indexOf('?') > -1) {
            _url += "&_t=" + utils.genGuid();
        } else {
            _url += "?_t=" + utils.genGuid();
        }
        return _url;
    },
    post: function (data, path, callback, type, errCall, abortCall) {
        var self = this;
        var tmpUrl = self.wrapUrl(self.baseUrl + path);
        alert(self.baseUrl);
        var flagStr = path.split('/')[2];
        self.isAbort = false;
        if (type == null) {
            self.currentRequest = $.post(tmpUrl, data, function (rs) {
                if (!self.isAbort) {
                    callback(rs);
                }
            });
        } else if (type == 'json') {
            if (!errCall) {
                errCall = function () {
                };    //10-18 ajax请求失败的操作函数
            }
            if (!abortCall) {
                abortCall = function () {
                };   //10-18 终止ajax后操作函数
            }
            self.currentRequest = $.ajax({
                type: "POST",
                url: tmpUrl,
                contentType: 'application/json',
                data: JSON.stringify(data),
                success: function (_data) {
                    abortCall();   //10-18添加终止ajax后方法
                    if (!self.isAbort) {
                        callback(_data);
                    }
                },
                error: errCall     //10-18添加请求失败方法
            });
        }
        self.currentRequest.flag = flagStr;
        flagStr = null;

    },
    /**
     * 专车获取两点距离是和时间
     */
    getCarDistance: function (_carItem, callback) {
        var tmpUrl = "http://restapi.amap.com/v3/distance";
        var data = {
            origins: _carItem.driverlng + "," + _carItem.driverlat,//司机地点，_carItem.driverlng + "," + _carItem.driverlat
            destination: _carItem.slng + "," + _carItem.slat,//出发地
            output: 'JSON',//返回json格式
            key: "ef93137f35d3c0cff6759c8d500fb834",//web服务key，与js api的key不一样
        }
        self.isAbort = false;
        var flagStr = "distance";
        self.currentRequest = $.get(tmpUrl, data, function (rs) {
            if (!self.isAbort) {
                callback(rs);
            }
        });
        self.currentRequest.flag = flagStr;
        flagStr = null;
    },
    /**
     * 专车获取附近地址信息
     */
    getCarNearByAddress: function (data, callback) {
        var tmpUrl = " http://restapi.amap.com/v3/place/around";
        self.isAbort = false;
        var flagStr = "around";
        data.key = "ef93137f35d3c0cff6759c8d500fb834";
        self.currentRequest = $.get(tmpUrl, data, function (rs) {
            if (!self.isAbort) {
                callback(rs);
            }
        });
        self.currentRequest.flag = flagStr;
        flagStr = null;
    },
    /**
     * 专车地址输入联想
     */
    getCarInputTips: function (data, callback) {
        var tmpUrl = "http://restapi.amap.com/v3/assistant/inputtips";
        self.isAbort = false;
        var flagStr = "inputtips";
        data.key = "ef93137f35d3c0cff6759c8d500fb834";
        self.currentRequest = $.get(tmpUrl, data, function (rs) {
            if (!self.isAbort) {
                callback(rs);
            }
        });
        self.currentRequest.flag = flagStr;
        flagStr = null;
    },
    /**
     * 专车ip定位
     */
    getCarIp: function (data, callback) {
        var tmpUrl = "http://restapi.amap.com/v3/ip";
        self.isAbort = false;
        var flagStr = "ip";
        data.key = "ef93137f35d3c0cff6759c8d500fb834";
        self.currentRequest = $.get(tmpUrl, data, function (rs) {
            if (!self.isAbort) {
                callback(rs);
            }
        });
        self.currentRequest.flag = flagStr;
        flagStr = null;
    },
    get: function (data, path, callback, type) {
        var self = this;
        var tmpUrl = self.wrapUrl(self.baseUrl + path);
        var flagStr = path.split('/')[2];
        self.isAbort = false;
        if (type == null) {
            self.currentRequest = $.get(tmpUrl, data, function (rs) {
                if (!self.isAbort) {
                    callback(rs);
                }
            });
        } else if (type == 'json') {
            self.currentRequest = $.ajax({
                type: "GET",
                url: tmpUrl,
                contentType: 'application/json',
                data: JSON.stringify(data),
                success: function (_data) {
                    if (!self.isAbort) {
                        callback(_data);
                    }
                }
            });
        }
        self.currentRequest.flag = flagStr;
        flagStr = null;
    },
    getKey: function (callback) {
        var self = this;
        self.get(null, "/order/getKey", callback);
    },
    /**
     * 金蝶云之家运通google与百度地图经纬度调换
     */
    getGeoconv: function (_data, callback) {
        var tmpUrl = "http://api.map.baidu.com/geoconv/v1/";
        self.isAbort = false;
        var flagStr = "geoconv";
        self.currentRequest = $.ajax({
            url: tmpUrl,
            dataType: 'jsonp',
            type: 'get',
            data: _data,
            jsonpCallback: 'callback',
            success: function (res) {
                callback(res);
            }
        });
        self.currentRequest.flag = flagStr;
        flagStr = null;
    },
    /**
     登陆
     **/
    login: function (data, callback) {
        var self = this;
        self.post(data, '/user/signIn', function (rs) {
            if (rs && rs.state == 1 && store && store.setToken) {
                store.setToken(rs.data.token);
            }
            callback(rs);
        });
    },

    /**
     判断登陆密码
     **/
    loginpw: function (data, callback) {

        var self = this;
        self.get(data, '/user/modifyGesturePassword', function (rs) {
            callback(rs);
        });
    },
    /**
     获取未使用行程信息
     **/
    travelToImport: function (data, callback) {

        var self = this;
        self.post(data, '/order/getUnusedJourney', function (rs) {
            callback(rs);
        });
    },

    /**
     获取用户消息列表
     **/
    getMessageList: function (data, callback) {

        var self = this;
        self.get(data, '/message/getMessageList', function (rs) {
            callback(rs);
        });
    },
    /**
     更改用户消息状态
     **/
    setMessageStatus: function (data, callback) {

        var self = this;
        self.get(data, '/message/setMessageStatus', function (rs) {
            callback(rs);
        });
    },

    /**
     ** 改期后取消关注原航班
     **/
    deleteFavoriteFlight: function (data, callback) {
        var self = this;
        self.get(data, '/flight/deleteFavoriteFlight', function (rs) {
            callback(rs);
        });
    },


    /**
     *  火车票改签接口
     **/
    getChangeRange: function (data, callback) {
        var self = this;
        this.get(data, '/train/getChangeRange', function (rs) {
            callback(rs);
        });
    },

    /**
     *  火车票申请取消改签接口
     **/
    cancelChangeTrain: function (data, callback) {
        var self = this;
        this.get(data, '/train/cancelChangeTrain', function (rs) {
            callback(rs);
        });

    },

    /**
     *  火车票申请改签接口
     **/
    getChangeRangeOK: function (data, callback) {
        var self = this;
        self.post(data, '/train/changeTrainTicket', function (rs) {
            callback(rs);
        }, 'json');
    },


    /**
     获取未读消息条数
     **/
    getUnread: function (callback) {

        var self = this;
        self.get(null, '/message/getUnread', function (rs) {
            callback(rs);
        });
    },

    /**
     生成预支付订单
     **/
    paymentOrders: function (data, callback) {

        var self = this;
        self.get(data, '/wxpay/prePayOrder', function (rs) {
            callback(rs);
        });
    },

    /**
     支付状态后台通知接口
     **/
    paymentState: function (data, callback) {

        var self = this;
        self.get(data, '/wxpay/getPayResult', function (rs) {
            callback(rs);
        });
    },

	
    /**
     获取首页滑动使用数据
     **/
    getHomeSwiperData: function (passengerId, certList, callback) {
        var self = this;
        self.currentRequest = $.ajax({
            type: "POST",
            url: this.wrapUrl(self.baseUrl + "/order/listItinerary"),
            beforeSend: function (request) {
                request.setRequestHeader('mobile-obt-token', store.getToken());
                request.setRequestHeader('appversion', Config.version);
                request.setRequestHeader("passengerId", passengerId);
            },
            contentType: 'application/json',
            data: JSON.stringify(certList),
            success: function (rs) {
                callback(rs);
            }
        });
        self.currentRequest.flag = "getHomeSwiperData";
    },

    /**
     获得机场列表
     */
    getAirports: function (callback) {
        var _cache = store.getData('$airports');
        if (_cache) {
            callback(_cache);
            return;
        }
        var self = this;
        self.get(null, '/flight/getAirportList', function (rs) {
            var data = rs.data;

            if (rs && rs.state == 1) {
                /*for (var i = 65; i <= 90; i++) {
                 var _char=String.fromCharCode(i).toLocaleUpperCase();
                 if(_char!='I' && _char!="U" && _char!="V"){
                 data.push({city:_char,name:_char,kw:_char,code:_char});
                 }
                 }
                 data = Enumerable.From(data).OrderBy(function(x){
                 x.kw=x.kw||x.keyword;
                 if(x.kw && x.kw!='')
                 return x.kw;
                 else if(x.city && x.city!='')
                 return x.city;
                 else
                 return x.code;
                 }).ToArray();*/
                data = self._combineCityData(rs.data);
                store.setData('$airports', data);
            }
            callback(data);
        });

    },
    _combineCityData: function (_data) {
        var self = this;
        var tmpArray = [];
        if (_data.length == 0) {
            return tmpArray;
        }

        tmpArray = _data;

        for (var i = 65; i <= 90; i++) {
            var _char = String.fromCharCode(i).toLocaleUpperCase();
            if (_char != 'I' && _char != "U" && _char != "V") {
                tmpArray.push({city: _char, name: _char, kw: _char, code: _char});
            }
        }

        tmpArray = Enumerable.From(tmpArray).OrderBy(function (x) {
            x.kw = x.kw || x.keyword;
            if (x.kw && x.kw != '')
                return x.kw;
            else if (x.city && x.city != '')
                return x.city;
            else
                return x.code;
        }).ToArray();
        return tmpArray;
    },
    /**
     * 获取serviceCode
     */
    getServiceCode: function (callback) {
        var self = this;
        self.get(null, "/user/getAppConfig", function (rs) {
            callback(rs);
        });

    },
    /**
     * 获取行程信息
     */
    getTripList: function (data, callback) {
        this.get(data, "/order/getJourney", function (rs) {
            callback(rs);
        });
    },
    /**
     * 分页获取行程
     */
    getJourneyByPage: function (data, callback) {
        this.get(data, "/order/getJourneyByPage", function (rs) {
            callback(rs);
        });
    },
    /**
     * 获取最新行程
     * @param data
     * @param callback
     */
    getLatestJourney: function (passengerId, certList, callback) {
        var self = this;
        self.currentRequest = $.ajax({
            type: "POST",
            url: this.wrapUrl(self.baseUrl + "/order/getLatestJourney"),
            beforeSend: function (request) {
                request.setRequestHeader('mobile-obt-token', store.getToken());
                request.setRequestHeader('appversion', Config.version);
                request.setRequestHeader("passengerId", passengerId);
            },
            contentType: 'application/json',
            data: JSON.stringify(certList),
            success: function (rs) {
                callback(rs);
            }
        });
        self.currentRequest.flag = "getLatestJourney";
    },

    /**
     * 获取首页滑动的数据
     * @param data
     * @param callback
     */
    getHomeSwiperData: function (passengerId, certList, callback) {
        var self = this;
        self.currentRequest = $.ajax({
            type: "POST",
            url: this.wrapUrl(self.baseUrl + "/order/listItinerary"),
            beforeSend: function (request) {
                request.setRequestHeader('mobile-obt-token', store.getToken());
                request.setRequestHeader('appversion', Config.version);
                request.setRequestHeader("passengerId", passengerId);
            },
            contentType: 'application/json',
            data: JSON.stringify(certList),
            success: function (rs) {
                callback(rs);
            }
        });
        self.currentRequest.flag = "getHomeSwiperData";
    },

    /**
     * 主页获取未审批消息数
     */
    getOrderCountByApverParId: function (apverParId, callback) {
        var self = this;
        this.get({"apverParId": apverParId}, "/order/getOrderCountByApverParId", function (rs) {
            callback(rs);
        });
    },
    /**
     * 修改用户密码信息
     * @param data
     * @param callback
     */
    updateUserPassword: function (data, callback) {
        this.post(data, "/user/updateUserPassword", function (rs) {
            callback(rs);
        });
    },
    /**
     * 由机场代码读取一个机场信息
     * @param code
     * isAmex是否运通，运通的国际都先匹配城市三字码，在匹配机场三字码（订单列表）
     * @returns
     */
    getAirport: function (code, isAmex) {
        var self = this,
            _cache = null;
        self.getAirports(function (rs) {
            _cache = rs;
        }, true);
        //国内机场三字码查询,按城市三字码查询
        var air = Enumerable.From(_cache).Where(function (x) {
            return x.code == code;
        }).ToArray()[0];

        if (air == undefined) {
            air = Enumerable.From(_cache).Where(function (x) {
                return x.city_code == code;
            }).ToArray()[0];
            if (air != undefined && isAmex) {
                air.showCity = true;
            }
        }
        //我的行程 国际机场数据undefined 情况
        if (air == undefined) {
            var _intlairport = intlairport;
            if (isAmex) {//订单列表运通先匹配城市三字码
                //城市三字码查询
                air = Enumerable.From(_intlairport).Where(function (x) {
                    return x.city_code == code;
                }).ToArray()[0];
                //按机场三字码查询
                if (air == undefined) {
                    air = Enumerable.From(_intlairport).Where(function (x) {
                        return x.code == code;
                    }).ToArray()[0];
                }

            }
            else {
                //机场三字码查询
                air = Enumerable.From(_intlairport).Where(function (x) {
                    return x.code == code;
                }).ToArray()[0];
                //按城市三字码查询
                if (air == undefined) {
                    air = Enumerable.From(_intlairport).Where(function (x) {
                        return x.city_code == code;
                    }).ToArray()[0];
                    //COZYGO-443 运通同步过来的国际请求订单以城市三字码匹配显示
                    /*if(!_.isEmpty(air)){
                     air.showCity = true;
                     }*/
                }
            }
            //TODO
            if (air) {
                air = utils.convertCityAir(store, air);
                air.showCity = true;
            }
            return air || {'code': code, 'name': '', 'city': ''};
        } else {
            return air || {'code': code, 'name': '', 'city': ''};
        }
    },
    /**
     * 清除机场缓存
     * */
    clearAirportCache: function () {
        store.setData('$airports', null);
    },

    //火车票预订查询接口
    searchTrainSchedule: function (data, callback) {
        var self = this;
        self.post(data, '/train/searchTrainSchedule', function (rs) {
            callback(rs);
        }, 'json');
    },

    //火车票预订预订座位接口
    bookTrainSeatPolicy: function (data, callback) {
        var self = this;
        self.post(data, '/train/bookTrainSeatPolicy', function (rs) {
            callback(rs);
        }, 'json');
    },
    //bcd 火车票预订预订座位接口
    bookTrainExistsCheck: function (data, callback) {
        var self = this;
        self.post(data, '/train/bookTrainExistsCheck', function (rs) {
            callback(rs);
        }, 'json');
    },


    //火车票预订保存订单接口
    saveTrainOrder: function (data, callback) {
        var self = this;
        self.post(data, '/train/bookTrain', function (rs) {
            callback(rs);
        }, 'json');
    },

    //火车票预订追加保存火车单元

    addTrainItem: function (data, callback) {
        var self = this;
        self.post(data, '/train/addTrainItem', function (rs) {
            callback(rs);
        }, 'json');
    },


    //BCD违背原因接口
    getDomesticReasonCode: function (data, callback) {
        var self = this;
        self.post(data, '/flight/getDomesticReasonCode', function (rs) {
            callback(rs);
        }, 'json');
    },


    //BCD 显示选项remark接口
    getBCDRemark: function (data, callback) {
        var self = this;
        self.post(data, '/flight/getBCDRemark', function (rs) {
            callback(rs);
        }, 'json');
    },

    //BCD 修改公司信息保存接口
    updateBCDRemark: function (data, callback) {
        var self = this;
        self.post(data, '/flight/updateBCDRemark', function (rs) {
            callback(rs);
        }, 'json');
    },


    //完成BCD的订单
    finishOrderForBcd: function (data, callback) {
        var self = this;
        self.post(data, '/order/finishOrderForBcd', function (rs) {
            callback(rs);
        }, 'json');
    },

    //完成BCD订单传parId和List
    finishOrderForBcdSec: function (data, callback) {
        var self = this;
        self.post(data, '/order/finishOrderForBcdSec', function (rs) {
            callback(rs);
        }, 'json');
    },

    //BCD获取审批人接口
    getApproverForBcd: function (data, callback) {
        var self = this;
        self.get(data, '/user/getApproverForBcd', function (rs) {
            callback(rs);
        });
    },

    //BCD送审接口
    approveOrderForBcd: function (data, callback) {
        var self = this;
        self.post(data, '/order/approveOrderForBcd', function (rs) {
            callback(rs);
        }, 'json');
    },

    /**
     ** 短信解析接口
     **/
    parseTrainTicket: function (data, callback) {
        var self = this;
        self.get(data, '/train/parseTrainTicket', function (rs) {
            callback(rs);
        });
    },

    //火车席别查询接口
    querySeatsByTrainNo: function (data, callback) {
        var self = this;
        self.get(data, '/train/querySeatsByTrainNo', function (rs) {
            callback(rs);
        });
    },

    //车次查询
    queryByTrainNo: function (data, callback) {
        var self = this;
        self.get(data, '/train/queryByTrainNo', function (rs) {
            callback(rs);
        });
    },

    //站站查询
    queryByDoubleStation: function (data, callback) {
        var self = this;
        self.get(data, '/train/queryByDoubleStation', function (rs) {
            callback(rs);
        });
    },

    //保存火车票订单
    saveTrainTicket: function (data, callback) {
        var self = this;
        self.post(data, '/train/saveTrainTicket', function (rs) {
            callback(rs);
        }, 'json');
    },

    //删除火车票行程接口
    deleteTrainTicket: function (data, callback) {
        var self = this;
        self.get(data, '/train/deleteTrainTicket', function (rs) {
            callback(rs);
        });
    },


    /**
     * 重复预定点击机票向后台发送调用信息
     */
    postSign: function (data) {

        var self = this;
        self.post(data, '/flight/loadBookedJourneytoCache', function (rs) {
        }, 'json');
    },
    /**
     * 跳转重复预定航班详情
     * @param data
     * @param callback
     */
    sameOrderDetail: function (_pnrParams, callback) {
        var self = this;
        self.get(_pnrParams, '/order/getOrderByPnr', function (rs) {
            callback(rs);
        });
    },

    /**
     * 查找重复预定航班
     * @param data
     * @param callback
     */
    sameorderFlighList: function (data, callback) {
        var self = this;
        self.post(data, '/flight/getSameFlightList', function (rs) {
            callback(rs);
        }, 'json');

    },

    /**
     * 查找航班列表
     * @param data
     * @param callback
     */
    searchFlightList: function (data, callback) {
        var self = this;
        self.post(data, '/flight/findFlight', function (rs) {
            callback(rs);
        }, 'json');
    },

    /**
     * 查找国际航班
     */
    findINFlight: function (data, callback) {
        var self = this;
        self.post(data, '/flight/findINFlight', function (rs) {
            callback(rs);
        }, 'json');
    },

    /**
     * 查找国际航班
     */
    findINFlightAllCabin: function (data, callback) {
        var self = this;
        self.post(data, '/flight/findINFlightAllCabin', function (rs) {
            callback(rs);
        }, 'json');
    },

    /**
     * 查常客列表
     */
    findUser: function (data, callback) {
        var self = this;
        self.get(data, '/user/findUser', function (rs) {
            callback(rs);
        });
    },
    /**
     * 根据id字符串组，查询常客信息
     */
    findUserByMultiParIds: function (data, callback) {
        var self = this;
        self.get(data, '/user/findUserByMultiParIds', function (rs) {
            callback(rs);
        });
    },
    /**
     * 查找临客列表
     */
    getTempTravlers: function (data, callback) {
        var self = this;
        self.get(data, '/user/getTempTravlers', function (rs) {
            callback(rs);
        });
    },
    /**
     * 查常客信息
     */
    getUserInfo: function (parId, callback) {
        var self = this;
        var data = {
            'parId': parId
        };
        self.get(data, '/user/getUserInfo', function (rs) {
            callback(rs);
        });
    },
    /**
     * 申请出票
     * @param dt
     * @param callback
     */
    ticketOrder: function (data, callback) {
        var self = this;
        self.post(data, '/order/ticketOrder', function (rs) {
            callback(rs);
        });
    },
    /**
     * 审批订单
     * @param data
     * @param callback
     */
    approveOrder: function (data, callback) {
        var self = this;
        self.post(data, '/order/approveOrder', function (rs) {
            callback(rs);
        });
    },
    /**
     * 送审一个订单
     */
    submitOrder: function (data, callback) {
        var self = this;
        self.post(data, '/order/submitOrder', function (rs) {
            callback(rs);
        });
    },
    /**
     * 撤回一个订单
     * @param dt
     * @param callback
     */
    withdrawOrder: function (data, callback) {
        var self = this;
        self.post(data, '/order/withdrawOrder', function (rs) {
            callback(rs);
        });
    },
    /**
     * 保存订单
     * @param data
     * @param callback
     */
    saveOrder: function (data, callback) {
        var self = this;
        self.post(data, '/order/saveOrder', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 保存一组航空单元
     */
    saveAirItem: function (airItemsList, callback) {
        var self = this;
        self.post(airItemsList, '/order/saveAirItem', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 保存一组航空单元
     * 追加国际航空单元
     */
    saveIntAirItem: function (airItemsList, callback) {
        var self = this;
        self.post(airItemsList, '/order/saveIntAirItem', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 删除一组航空单元
     */
    deleteAirItem: function (airItemsList, callback) {
        var self = this;
        self.post(airItemsList, '/order/deleteAirItem', function (rs) {
            callback(rs);
        }, 'json');
    },

    /**
     * 删除一组火车单元
     */
    deleteTrainItem: function (trainItemsList, callback) {
        var self = this;
        self.post(trainItemsList, '/train/removeTrainItem', function (rs) {
            callback(rs);
        }, 'json');
    },


    /**
     * 根据审批规则和姓名关键字查询人员
     * @param data
     * @param callback
     */
    getApproveUserList: function (data, callback) {
        var self = this;
        self.get(data, "/order/getApproveUserList", function (rs) {
            callback(rs);
        });
    },
    /**
     * 忘记密码
     */
    forgetPassword: function (data, callback) {
        var self = this;
        self.get(data, "/user/forgetPassword", function (rs) {
            callback(rs);
        });
    },
    /**
     * 忘记密码
     * 运通忘记密码接口
     */
    forgetPasswordEico: function (data, callback) {
        var self = this;
        self.get(data, "/user/forgetPwd", function (rs) {
            callback(rs);
        });
    },
    //运通需求
    checkDomAirBookPolicys: function (params, callback) {
        var self = this;
        self.post(params, '/order/checkDomAirBookPolicys', function (rs) {
            callback(rs);
        }, 'json');
    },
    //运通 获取 审批策略和审批参数内容
    amexGetSubmitPageContent: function (_params, callback) {
        var self = this;
        self.get(_params, '/order/getSubmitPageContent', function (rs) {
            callback(rs);
        });
    },
    //运通 获取参数列表数据
    amexSubmitTA: function (_params, callback) {
        var self = this;
        self.post(_params, '/order/submitTA', function (rs) {
            callback(rs);
        }, 'json');
    },
    amexGetSelectDatas: function (_params, callback) {
        var self = this;
        self.post(_params, '/order/getSelectDatas', function (rs) {
            callback(rs);
        });
    },
    /**
     * 修改用户信息
     */
    updateUserInfo: function (data, callback) {
        var self = this;
        self.post(data, '/user/updateUserInfo', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 登出
     */
    signOut: function (callback) {
        this.get(null, "/user/signOut", callback);
    },
    /**
     根据用户反馈信息，发送反馈邮件
     */
    getUserFeedback: function (_data, _callback) {
        this.post(_data, '/user/getUserFeedback', function (rs) {
            _callback(rs);
        });
    },
    /**
     * 获取退票详情
     */
    getTicketRefundDetail: function (_data, callback) {
        this.get(_data, "/flight/getTicketRefundDetail", function (rs) {
            callback(rs);
        });
    },
    /**
     * 获取退票价格
     */
    getRefund: function (_data, callback) {
        this.get(_data, "/flight/getRefund", function (rs) {
            callback(rs);
        });
    },
    /**
     * 执行退票操作
     */
    refundTicket: function (data, callback) {
        var self = this;
        self.post(data, '/flight/refundTicket', function (rs) {
            callback(rs);
        }, 'json');
    },

    /**
     *  火车票退票接口
     **/
    refundTrainTicket:function(data,callback){
        var self = this;
        this.get(data,'/train/refundTrainTicket',function(rs){
            callback(rs);
        });

    },

    /**
     获取订单列表
     **/
    getOrderList: function (data, callback) {
        this.get(data, '/order/getOrderByBookerIdAndRowNumber', function (rs) {
            callback(rs);
        });
    },
    /**
     获取订单详情
     queryFlag=1：订单详情
     queryFlag=2：审批详情
     **/
    getOrderDetail: function (journeyno, queryFlag, callback) {
        this.get({"orderId": journeyno, "queryFlag": queryFlag}, '/order/getOrder', function (rs) {
            callback(rs);
        });
    },
    /**
     * 获取订单列表(根据审批人)
     */
    getReviewList: function (data, callback) {
        this.get(data, '/order/getOrderByApverParIdAndRowNumber', function (rs) {
            callback(rs);
        });
    },
    /**
     删除一组航空单元
     **/
    deleteAirItems: function (airItemsList, callback) {
        if (airItemsList && airItemsList.length > 0) {
            this.post(airItemsList, '/order/deleteAirItem', function (rs) {
                callback(rs);
            }, 'json');
        }
    },
    /**
     删除一组酒店单元 add zcy
     **/
    deleteHotelItems: function (hotelItemsList, callback) {
        if (hotelItemsList && hotelItemsList.length > 0) {
            this.post(hotelItemsList, '/order/deleteHotelItem', function (rs) {
                callback(rs);
            }, 'json');
        }
    },
    /**
     * 发送酒店取消邮件
     */
    sendHotelCancelEmail: function (data, callback) {
        var self = this;
        this.get(data, '/order/sendApplyForHotelCancelEmail', function (rs) {
            callback(rs);
        });

    },
    /**
     删除订单
     **/
    deleteOrder: function (_journeyNo, callback) {
        this.post({journeyNo: _journeyNo}, '/order/deleteOrder', function (rs) {
            callback(rs);
        });
    },
    /**
     * 取消订单（传整个订单）
     * @param data
     * @param callback
     */
    cancelOrder: function (data, callback) {
        var self = this;
        self.post(data, '/order/cancelOrder', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     撤回订单
     **/
    withdrawOrder: function (_journeyNo, callback) {
        this.post({journeyNo: _journeyNo}, '/order/withdrawOrder', function (rs) {
            callback(rs);
        });
    },
    /**
     审批订单
     **/
    approveOrder: function (data, callback) {
        this.post(data, '/order/approveOrder', function (rs) {
            callback(rs);
        });
    },
    /**
     * 运通接口获取差旅政策
     */
    findAmexHotelCheckPolicy: function (data, callback) {
        this.post(data, '/hotel/findAmexHotelCheckPolicy', function (rs) {
            callback(rs);
        }, 'json');
    },
    saveHotelOrder: function (data, callback) {//酒店预订保存酒店订单
        this.post(data, '/order/saveOrder', callback, 'json');
    },
    saveHotelItem: function (data, callback) {//酒店预订保存酒店单元
        this.post(data, '/order/saveHotelItem', callback, 'json');
    },
    /**
     查询改期航班
     **/
    alterSearchFlightList: function (_data, callback) {
        this.post(_data, '/flight/findChangeFlight', function (rs) {
            callback(rs);
        }, 'json');
    },

    //保险
    getInsuranceProduct: function (data, callback) {
        var self = this;
        self.post(data, '/insurance/getInsuranceProduct', function (rs) {
            if (callback) {
                callback(rs);
            }
        }, 'json');
    },
     /**
     * 改期支付状态查询
     */
     getChangePayState: function (_data, callback) {
        this.get(_data, '/order/payStatePolling', function (rs) {
            callback(rs);
        });
    },
     /**
     *（机票）根据票号获取航空单元号
     * */
    getAirSinoNum: function (_data, callback) {
        this.get(_data, '/order/getAirSinoByTicketNumber', function (rs) {
            callback(rs);
        });
    },
    /**
    * 删除pnr
    */
    delPnrNum: function (data, callback) {
	    this.get(data, '/flight/deletePnr', function (rs) {
	        callback(rs);
	    });
    },
    /**
     改期查询价格接口
     **/
    doPrice: function (_data, callback) {
        this.post(_data, '/flight/doPrice', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     改期
     **/
     changeFlight: function (_data, callback) {
        this.post(_data, '/flight/changeFlight', function (rs) {
            callback(rs);
        }, 'json');
    },
      /**
     	保存改期信息的接口
     **/
    saveChangeTicket: function (_data, callback) {
        this.post(_data, '/flight/changeTicketApply', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     获取改期退票列表
     passengerId
     alterType 0：改期，1退票
     **/
    getJourneyForAlter: function (_data, callback) {
        this.get(_data, '/order/getJourneyForAlter', function (rs) {
            callback(rs);
        });
    },
    /**
     *获取客服电话
     * */
    getServiceCallNum: function (_data, callback) {
        this.get(_data, '/flight/getAirlineAndServiceNumber', function (rs) {
            callback(rs);
        });
    },
    /**
     获取关注列表
     **/
    getFollowList: function (callback, data) {
        this.get(data ? data : null, '/flight/getFavoriteList', function (rs) {
            callback(rs);
        })
    },
    /**
     * 酒店获取条件担保结果
     */
    findAmexGuaranteeHotel: function (data, callback) {
        this.post(data, '/hotel/findAmexGuaranteeHotel', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     查用户证件号，手机号，值机时调用
     **/
    getParCertInfo: function (callback) {
        this.get(null, '/user/getParCertInfo', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 获取国籍
     */
    getNations: function (callback) {
        this.get(null, '/flight/queryAllNations', function (rs) {
            callback(rs);
        }, 'json');
    },

    /**
     * update user info 废弃
     */
    reloadUserInfo: function (data, callback) {
        this.get(data, '/user/reloadUserInfo', function (rs) {
            callback(rs);
        });
    },
    /**
     * load config index
     */
    loadConfig: function (data, callback) {
        this.post(data, '/user/loadConfig', function (rs) {
            callback(rs);
        });
    },


    /**
     * 删除临客
     */
    removeTempTraveler: function (data, callback) {
        this.post(data, '/user/delPsg', function (rs) {
            callback(rs);
        });
    },
    /**
     * 增加临客
     */
    addTempTraveler: function (data, callback) {
        this.post(data, '/user/addUserInfo', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 添加证件
     */
    addIdCard: function (data, callback) {
        this.post(data, '/user/addIdCard', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * update app
     */
    getAppVersion: function (data, callback) {
        this.get(data, '/flight/getAppVersion', function (rs) {
            callback(rs);
        });
    },
    /**
     检查iOS版本
     **/
    checkIOSPluginVersion: function (_appVersion, _callback) {
        var _agentId = store.getMyInfo().agentId;
        /**
         _agentId为空，说明还没登陆
         **/
        if (_agentId == null || _agentId == undefined) {
            return;
        }
        var tmpURL = this.wrapUrl(this.baseUrl + "/user/getPlugin");
        var requestData = {
            'agentId': _agentId,
            'appVersion': _appVersion
        };

        this.get(requestData, tmpURL, function (rs) {
            _callback(rs);
        });
    },
    /**
     获取公司个性化配置
     **/
    getConfig: function (callback, data) {
        var _data = _.isEmpty(data) ? null : data;
        this.get(_data, '/user/getUnifiedConfig', function (rs) {
            callback(rs);
        });
    },
    /**
     * 配送城市,地址
     */
    deliveryCity: function (data, callback) {
        var self = this;
        var cityArray = store.getDeliveryCity();
        if (!_.isEmpty(cityArray)) {
            callback(cityArray);
        } else {
            self.get(data, '/user/getDelivery', function (rs) {
                if (rs && rs.state == 1 && rs.data) {
                    var tmpCityArray = self._combineCityData(rs.data);
                    store.setDeliveryCity(tmpCityArray);
                    callback(rs.data);
                } else {
                    callback(null);
                }

            });
        }

    },
    deliveryAddress: function (data, callback) {
        var self = this;
        self.get(data, '/user/getDelivery', function (rs) {
            callback(rs);
        });
    },
    /**
     * 获取成本中心及差旅政策等
     * @param keyword
     * @param callback
     */
    getCost: function (data, callback) {
        this.get(data, '/user/getCcInfo', function (rs) {
            callback(rs);
        });
    },
    /**
     * 国际undefined接口日志
     */
    logIntUndefined: function (data, callback) {
        this.get(data, '/flight/logIntUndefined', function (rs) {
//				callback(rs);
        });
    },
    /**
     更新订单接口
     **/
    updateOrder: function (data, callback) {
        var self = this;
        this.post(data, '/order/updateOrder', function (rs) {
            callback(rs);
        }, 'json');
    },
    modifyOrder: function (data, callback) {
        var self = this;
        this.post(data, '/order/modifyOrder', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     根据dataType来获取选择数组
     **/
    getSelectList: function (_dataKey, callback, searchKey) {
        var self = this;
        var _data = {
            search: searchKey,
            dataType: _dataKey
        };
        self.get(_data, '/user/getDataByDataType', function (rs) {
            callback(rs);
        });
    },
    getLinkSelectList: function (_data, callback) {
        var self = this;
        self.get(_data, '/user/getDataByDataType', function (rs) {
            callback(rs);
        });
    },
    /**
     易行验舱接口
     **/
    validateCabin: function (_journeyNo, callback) {
        var self = this;
        self.get({journeyNo: _journeyNo}, '/order/validateCabin', function (rs) {
            callback(rs);
        })
    },
    /**
     支付接口
     **/
    pay: function (_journeyNo, _pwd, callback) {
        var self = this;
        self.post({orderid: _journeyNo, payPwd: _pwd}, '/order/payOut', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     补发行程单
     **/
    sendBookedJourneyEmail: function (journeyNo, callback) {
        var self = this;
        self.get({journeyNo: journeyNo}, '/order/sendBookedJourneyEmail', function (rs) {
            callback(rs);
        });
    },
    /**
     * 易行 政策列表
     */
    getYeePolicy: function (data, callback) {
        var self = this;
        this.post(data, '/flight/queryRebatePolicy', function (rs) {
            callback(rs);
        }, 'json');

    },
    /**
     * @title 根据差旅ID获取差旅政策
     * @param travelId 差旅ID
     * @param callback 回调函数
     * @return 差旅政策对象
     */
    getPolicyInfoByTravelId: function (travelId, callback) {
        var self = this;
        self.get({tpId: travelId}, '/user/getTravelPolicyById', function (rs) {
            callback(rs);
        });
    },
    /**
     * 读取一个审批规则
     * @param ruleId
     * @param callback
     */
    getApproveRule: function (ruleId, callback) {
        var data = {
            "approveRuleId": ruleId
        };
        this.get(data, '/order/getApproveRule', function (rs) {
            callback(rs);
        });
    },
    /**
     * fcm ikea根据公司更换成本中心
     **/
    getCorpBySc: function (callback) {
        this.get(null, "/user/findCorpBySc", function (rs) {
            callback(rs);
        });
    },
//		/**
//		 * 单酒店查询接口
//		 */
//		sendSingleRequest:function(data,callback){
//			var self = this;
//			self.post(data,'/hotel/findSingleHotel',function(rs){
//				callback(rs);
//			},'json');
//		},
    /**
     * 多酒店查询前读取默认协议类型配置
     */
    findHotelConfig: function (data, callback) {
        var self = this;
        self.get(data, '/hotel/findHotelConfig', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 致电客服获取电话号码
     * @param airline 航空公司二字码
     * @param serviceCode 服务代码
     */
    getAirlineAndServiceNumber: function (data, callback) {
        var self = this;
        self.get(data, '/flight/getAirlineAndServiceNumber', function (rs) {
            callback(rs);
        });
    },
    /**
     * 行程详情改期
     */
    getFlightChangeDetail: function (data, callback) {
        var self = this;
        self.get(data, '/flight/getFlightChangeDetail', function (rs) {
            callback(rs);
        });
    },
    /**
     * 行程详情退票
     */
    getTicketRefundDetail: function (data, callback) {
        var self = this;
        self.get(data, '/flight/getTicketRefundDetail', function (rs) {
            callback(rs);
        });
    },



    /**
     * 微信绑定
     */
    weiChatBundling: function (data, callback) {
        var self = this;
        this.post(data, '/user/weixinBundling', function (rs) {
            callback(rs);
        });
    },
    /**
     * 运通国际选择该行程判断
     */
    checkIntlAirBookPolicys: function (data, callback) {
        var self = this;
        this.post(data, '/order/checkIntlAirBookPolicys', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 年终行程
     */
    getSummary: function (data, callback) {
        var self = this;
        self.get(data, '/user/getSummary', function (rs) {
            callback(rs);
        });
    },
    /**
     * 获取最新的舱位退改签规则
     */
    getFareInfo: function (data, callback) {
        var self = this;
        self.post(data, '/flight/getFareInfo', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 更新常客的电话和Email
     */
    updateEmailAndTel: function (data, callback) {
        var self = this;
        self.post(data, '/user/updateEmailAndTel', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 航班选座列表
     * COZYGO-3118 选座功能——调用选座接口时，前端加上一个参数flag作为是否为秘书型用户的标识
     */
    getTravelFlightList: function (data, callback) {
        var self = this;
        self.get(data, '/order/getTravelFlightList', function (rs) {
            callback(rs);
        });
    },
    /**
     * 座位图
     */
    getSeatMap: function (data, callback) {
        var self = this;
        self.post(data, '/order/getSeatMap', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 提交选择座位后的结果
     */
    seatRes: function (data, callback) {
        var self = this;
        self.post(data, '/order/seatRes', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 消息推送
     * nodeType  第一次登录 firstlogin 登录后login  覆盖更新coverupdate  定时timing  预订成功bookingsuccess
     */
    pushMessage: function (data, callback) {
        var self = this;
        self.get(data, '/user/pushMessage', function (rs) {
            callback(rs);
        });
    },
    /**
     * 通用post json格式请求
     * str为'/order/getINFlightAirFareRules'这种形式
     */
    postJsonRequest: function (data, str, callback) {
        var self = this;
        self.post(data, str, function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 国际机场热门
     * 返回json格式：
     List:
     nation;//        国家
     cityname;//        城市
     citycode;//        城市三字码
     airportname;//    机场名称
     airportcode;//    机场三字码
     */
    getTopCityAirport: function (data, callback) {
        var self = this;
        self.get(data, '/flight/getTopCityAirport', function (rs) {
            callback(rs);
        });
    },
    /**
     *根据城市名查询酒名称(关键字模糊查询)
     */
    findHotelNameList: function (data, callback) {
        var self = this;
        self.get(data, '/hotel/findHotelNameList', function (rs) {
            callback(rs);
        });
    },
    /**
     * 国际预订接口
     */
    saveIntOrder: function (data, callback) {
        var self = this;
        self.post(data, '/order/saveINOrder', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 国际保存常客接口
     */
    saveIntPsgInfo: function (data, callback) {
        var self = this;
        self.post(data, '/user/updateUserInfos', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * BCD单酒店预定前重单校验
     */
    verifyBcdHotel: function (data, callback) {
        var self = this;
        self.get(data, '/hotel/verifyBcdHotel', function (rs) {
            callback(rs);
        });
    },
    /**
     * BCD单酒店跳转核对页面前获取酒店信息
     */
    prepareBookBcdHotel: function (data, callback) {
        var self = this;
        self.get(data, '/hotel/prepareBookBcdHotel', function (rs) {
            callback(rs);
        });
    },
    /**
     * 获取值机列表
     */
    checkInList: function (callback) {
        var self = this;
        self.post('', '/order/getCheckInList', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 记录值机日志，是打开浏览器值机，还是调用航旅纵横sdk值机
     * 0-浏览器，1-sdk
     */
    checkIn: function (data, callback) {
        var self = this;
        self.get(data, '/order/CheckIn', function (rs) {
//				callback(rs);
        });
    },
    /**
     * 航空公司列表(值机)
     */
    getCmpList: function (data, callback) {
        this.get(data, '/flight/getCheckInAirLineInfo', function (rs) {
            callback(rs);
        });
    },
    /**
     * 后台更新乘机人数据
     */
    loadBookedJourneyByParidstoCache: function (data, callback) {
        this.post(data, '/flight/loadBookedJourneyByParidstoCache', function (rs) {
            callback(rs);
        }, 'json');
    },
    /**
     * 国际记录时差点击次数
     */
    countMoreDetailTimes: function (callback) {
        this.get("", '/flight/countMoreDetailTimes', function (rs) {
//				callback(rs);
			});
		},
		/**
		 *  海航预付费选座
		 *  /order/getHuPaidSeatPsgInfo
		 */
		getHuPaidSeatPsgInfo:function(callback){
			var self = this;
			self.get("",'/order/getHuPaidSeatPsgInfo',function(rs){
				callback(rs);
			});
		},
		/**
		 * bcd 检查订单重复航班
		 */
		checkSameFlightForBCD:function(data, callback){
			this.get(data,'/flight/checkSameFlightForBCD',function(rs){
				callback(rs);
			});
		},

		/**
		获取审批授权状态列表
		**/
		queryApvGrant:function(data, callback){
			this.get(data,'/user/queryApvGrant',function(rs){
				callback(rs);
			});
		},

		/**
		取消授权
		**/
		revokeAuthority:function(data, callback){
			this.get(data,'/user/removeApvGrant',function(rs){
				callback(rs);
			});
		},

		/**
		授权
		**/
		saveApvGrant: function(data, callback){
			this.post(data,'/user/saveApvGrant', function(rs){
				callback(rs);
			});
		},
		/**
		 * 租车获取产品总类
		 */
		getProductInfo:function(data,callback){
			this.post(data,'/taxi/getProductInfo', function(rs){
				callback(rs);
			},'json');
		},
		/**
		 * 租车获取产品信息
		 */
		getCityServiceDetail:function(data,callback){
			this.post(data,'/taxi/getCityInfo', function(rs){
				callback(rs);
			},'json');
		},
		/**
		 * 专车-费用预估
		 */
		getEstimatePrice:function(data,callback){
			this.post(data,'/taxi/getEstimatePri', function(rs){
				callback(rs);
			},'json');
		},
		/**
		 * 获取token
		 */
		getSZTokenInfoByToken:function(data,callback){
			this.post(data,'/taxi/getSZTokenInfoByToken', function(rs){
				callback(rs);
			},'json');
		},
		/**
		 * 获取code
		 */
		getSZTokenInfoByCode:function(data,callback){
			this.post(data,'/taxi/getSZTokenInfoByCode', function(rs){
				callback(rs);
			},'json');
		},
		/**
		 * 更新订单状态
		 */
		checkOrderStatus:function(data,callback){
			this.get(data,'/taxi/checkOrderStatus', function(rs){
				callback(rs);
			});
		},
		/**
		 *
		 */
		getCarStatus:function(data,callback){
			this.post(data,'/order/getCarStatus', function(rs){
				callback(rs);
			});
		},
		/**
		 * 取消原因
		 */
		getCancelResson:function(data,callback){
			this.post(data,'/taxi/getCancelReason', function(rs){
				callback(rs);
			},'json');
		},
		/**
		 * 取消租车订单原因
		 */
		cancelOrderInfo:function(data,callback){
			this.post(data,'/taxi/getCancelReason', function(rs){
				callback(rs);
			},'json');
		},
		/**
		 * 取消订单
		 */
		deleteCarItemOrder:function(data,callback){
			this.post(data,'/order/deleteCarItemOrder', function(rs){
				callback(rs);
			},'json');
		},
		/**
		 * 获取租车城市列表
		 */
		getTaxiCityList:function(data,callback){
			this.post(data,'/taxi/getCityList', function(rs){
				callback(rs);
			},'json');
		},
		/**
		 * 获取租车机场列表
		 */
		getTaxiCityAirport:function(data,callback){
			this.post(data,'/taxi/getCityAirport', function(rs){
				callback(rs);
			});
		},
		/**
		 * 根据航班号查机场对象
		 */
		getTaxiFlightNoInfo:function(data,callback){
			this.post(data,'/taxi/getFlightNoInfo', function(rs){
				callback(rs);
			});
		},
		/**
		根据用户名获取用户姓名
		**/
		queryObtUserByName: function(data, callback){
			this.get(data,'/user/queryObtUserByName', function(rs){
				callback(rs);
			});
		},

		/**
		获取被授权列表
		**/
		queryGranteeList: function(data, callback){
			this.get(data,'/user/queryGranteeList', function(rs){
				callback(rs);
			});
		},

		/**
		获取行程列表
		**/
		getJourneyLuggageList: function(data, callback){
			this.get(data,'/flight/getJourneyLuggageList', function(rs){
				callback(rs);
			});
		},

		/**
		保存行程及行李清单
		**/
		saveJourneyLuggageList: function(data, callback, callbackErr){
			var self = this;
			var path = '/flight/saveJourneyLuggageList';
			var tmpUrl = self.wrapUrl(self.baseUrl+path);
			var flagStr = path.split('/')[2];
			self.isAbort = false;
			self.currentRequest =  $.ajax({
				type:"POST",
				url:tmpUrl,
				contentType:'application/json',
				data:JSON.stringify(data),
				success: function(_data){
					if(!self.isAbort){
						callback(_data);
					}
				},
				error: function(xhr,status,e) {
					var msg = status;
					//utils.hideMessage();
          self.ionicLoading.hide();
					if(msg == "error"){//网络连接错误
						setTimeout(function(){
							utils.showAlertIonic(self.ionicPopup,{text:utils.lang.connection_failed,
								onOK: function(){
									if(callbackErr){
										callbackErr();
									}
								}});
						},500);
					}else if(msg == "abort"){//主动终止Ajax请求

					}else if(msg == "timeout"){//网络连接超时
						utils.showAlertIonic(self.ionicPopup,{text:utils.lang.connection_timeout,
							onOK: function(){
								if(callbackErr){
									callbackErr();
								}
							}});
					}
				}
			});
			self.currentRequest.flag =  flagStr;
			flagStr = null;
		},

		/**
		获取行程的行李物品
		**/
		queryJourneyLuggageList: function(data, callback){
			this.get(data,'/flight/queryJourneyLuggageList', function(rs){
				callback(rs);
			});
		},

		/**
		删除行程及其行李物品
		**/
		deleteJourneyLuggageList: function(data, callback){
			this.get(data,'/flight/deleteJourneyLuggageList', function(rs){
				callback(rs);
			});
		},

		/**
		 * 记录值机日志，是打开浏览器值机，还是调用航旅纵横sdk值机
		 * 0-浏览器，1-sdk
		 */
		logForGetCheckInList: function(data, callback){
			var self = this;
			self.get(data, '/order/logForGetCheckInList', function(rs){
				if(callback){
					callback(rs);
				}
			});
		},

		/**
		 * COZYGO-3541 秘书型账号后选人（前端）秘书后选人 判断是否需要选择公司/部门和差旅政策，如需要获取可选公司/部门列表
		 */
		getCompanyByParId: function(data, callback){
			var self = this;
			self.get(data, '/user/getCompanyByParId', function(rs){
				if(callback){
					callback(rs);
				}
			});
		},

		/**
		 * COZYGO-3541 秘书型账号后选人（前端）秘书后选人 根据公司id获取差旅政策列表
		 */
		getTravelPolicyByCorpId: function(data, callback){
			var self = this;
			self.get(data, '/user/getTravelPolicyByCorpId', function(rs){
				if(callback){
					callback(rs);
				}
			});
		},
		/**
		 * COZYGO-3541 秘书型账号后选人（前端） 根据公司id和公司code获取审批规则
		 */
		getApproveruleByCorpId: function(data, callback){
			var self = this;
			self.get(data, '/user/getApproveruleByCorpId', function(rs){
				if(callback){
					callback(rs);
				}
			});
		},

		/**
		 * 切换语言 获取新的配置
		 */
		switchLanguage: function(args, callback){
			var self = this;
			self.get(args, '/user/switchLanguage', function(rs){
				if(callback){
					callback(rs);
				}
			});
		},
		/**
		 * 获取行程天气预报
		 */
		getJourneyWeather:function(data,callback){
			var self = this;
			self.post(data,"/weather/searchWeather",function(rs){
				callback(rs);
			},'json');
		},
        /**
         * 获取外部订单列表
         */
        getExternalOrderList: function (data, callback) {
            var self = this;
            self.post(data, '/flight/getExternalOrders', function (rs) {
                if (callback) {
                     callback(rs);
                }
            });
        },

        /**
         * 获取外部订单详情
         */
        getExternalOrderDetails: function (data, callback) {
            var self = this;
            self.post(data, '/flight/getExternalOrderDetails', function (rs) {
                callback(rs);
            });
        },

    /**
     * 租车获取产品总类
     */
    getProductInfo:function(data,callback){
        var self=this;
        self.post(data,'/taxi/getProductInfo', function(rs){
            callback(rs);
        },'json');
    }

	}

