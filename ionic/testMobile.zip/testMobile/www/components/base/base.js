/**
 * 基类，所有页面构建在此页面上
 * app启动入口
 */
angular.module("app").controller('baseCtrl',
		["$scope","$state","$controller",
		function($scope,$state,$controller){
		  $scope.$watch('$ionicView.loaded', function () {
			//$controller('parentCtrl', {$scope: $scope});//继承base控制器
			$state.go('tabs.login');//跳转至登录页
		  })	 
}])
