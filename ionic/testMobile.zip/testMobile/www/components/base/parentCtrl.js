 angular.module('app').controller('parentCtrl', ["$scope","$state",
    function($scope,$state) {
      $scope.initialize=function(){
     // utils.getAppLang(store);
      $scope.utils = utils;
      $scope.store = store;
      $scope.sgClient = sgClient;
      $scope.sgClient.initialize();
     // $scope.lang = Chinese;//默认用中文
      }

    
 }])