angular.module("app")
    .controller('loginCtrl', 
    		["$scope","$controller","$state",
			function ($scope, $controller, $state) {
				$scope.$on('$ionicView.loaded', function (event, data) {
						$controller('parentCtrl', {$scope: $scope});//继承父控制器
						$scope.user = {serviceCode: '', username: '', password: ''};
						$scope.initialize();
						$scope.init();
         
					}
				)
				$scope.init = function () {
					if($scope.store.getLang()=='en-us')
					{
						$scope.lang='English';
						$scope.changeLangBtnTxt='中文';
					}else if($scope.store.getLang='zh-cn'){
						$scope.lang="中文";
						$scope.changeLangBtnTxt='English';
					}
					$scope.loginTxt='登录';
				}
				/**
		         * 初始化登录事件
		         */
		        $scope.doLogin = function () {
		            var self = this;
		            // if (self.utils.browerVersion('iOS') && Cordova) {
		            //     Cordova.exec(function (_infoArray) {
		            //         phoneType = _infoArray[0];
		            //         versionNo = _infoArray[1];
		            //         self.iosToken = _infoArray[2];//iOS手机设备的token
		            //         self.login(phoneType, versionNo, self.iosToken);
		            //     }, function () {
		            //     }, "GetHardwareInfo", "getHardwareInfo", ["getHardwareInfo"]);
		            // } else {
		                $scope.login();
		            //}
		        }
		        $scope.login = function (phoneType, versionNo, token) {
				            var self = this;
				            var serviceCode = $scope.user.serviceCode;
				            var username = $scope.user.username;
				            var pwd = $scope.user.password;

				            //去掉空格
				            //COZYGO-705 对含有空格的服务代码的支持(服务代码只去掉左右空格，不要替换字符串中间的空格)
				            serviceCode = serviceCode.trim();//self.utils.removeStrBlank(serviceCode);
				            username = username.trim();//self.utils.removeStrBlank(username);
				            pwd = pwd.trim();//self.utils.removeStrBlank(pwd);
				            if (self.modulus && self.exponent) {//密码加密
				                var key = RSAUtils.getKeyPair(self.exponent, '', self.modulus);
				                pwd = RSAUtils.encryptedString(key, encodeURIComponent(pwd));
				            }
				            if (self.utils.browerVersion('iOS') && Cordova) {
				                var phoneTypeIos = phoneType;//ios手机设备型号
				                var versionNoIos = versionNo;//ios手机版本号
				            }
				            var phoneType = '';//手机设备型号
				            var versionNo = '';//手机版本号
				            var deviceCode = '';//手机IMEI号
				            var packSize = 0;//安装包包大小
				            var appName = '';//应用名称
				            if (self.utils.getBrowser().android) {//Android
				                /*
				                 * changed by zjf
				                 * 增加设备型号和版本号
				                 */
				                if (self.array.length > 0) {
				                    deviceCode = self.array[0];
				                    if (deviceCode == null || deviceCode == '') {//有些设备获取不到deviceCode
				                        deviceCode = self.store._getDeviceCode();
				                    }
				                    phoneType = self.array[1];
				                    versionNo = self.array[2];
				                    packSize = self.array[4];
				                    appName = self.array[5];
				                }
				                else {
				//                    self.store.getDeviceCode2(function (array) {//获取设备信息
				                	$scope.SGPlugin.getDeviceCode(function(array){
				                        deviceCode = array[0];
				                        if (deviceCode == null || deviceCode == '') {//有些设备获取不到deviceCode
				                            deviceCode = self.store._getDeviceCode();
				                        }
				                        phoneType = array[1];
				                        versionNo = array[2];
				                        packSize = array[4];
				                        appName = array[5];
				                    });
				                }
				            }
				            else {

				                if (!_.isEmpty(self.iosToken)) {
				                    deviceCode = self.iosToken;
				                } else {
				                    self.store.getDeviceCode(function (code) {
				                        deviceCode = code;
				                    });
				                }
				                phoneType = phoneTypeIos;
				                versionNo = versionNoIos;
				            }



				            /**
				             * 判断是否第一次登陆
				             */
				            var isFirstLogin = self.store.getData('$firstLogin');
				            isFirstLogin = (isFirstLogin == undefined || isFirstLogin == null) ? true : isFirstLogin;

				            var deviceModel = self.utils.getPhoneName();

				            deviceModel = deviceModel + "/" + phoneType + "/" + versionNo;

				            var deviceType = self.utils.browerVersion('iOS') ? 'ios' : (self.utils.browerVersion('android') ? 'android' : 'web');
				           // alert(self.store.getLang);
				            var loginData = {
				                'serviceCode': serviceCode,
				                'account': username,
				                'password': pwd,
				                'deviceModel': deviceModel,
				                'deviceCode': deviceCode,
				                'firstLogin': isFirstLogin,
				                'appVersion': self.utils.config.version,
				                'langName': self.store.getLang,
				                'deviceType': deviceType
				            };
				            if (self.utils.getBrowser().android) {
				                loginData.packSize = packSize;
				                loginData.appName = appName;
				            }
				            if (loginData.account == null || loginData.account == "" ||
				                loginData.password == null || loginData.password == "") {
				                self.showAlertIonic({text: self.lang.please_enter_all_loignInfo});
				                return;
				            }
				            /**
				             * COZYGO-661 在本手机更换账号登陆后，清空之前设置的手势密码
				             */
				            var lastLoginInfo = self.store.getData('$lastLoginInfo');
				            if (lastLoginInfo && (loginData.serviceCode != lastLoginInfo.serviceCode || loginData.account != lastLoginInfo.account)) {
				                self.store.setData("home_cordova", null);
				                self.store.setData("$settingLogoutAndroid", null);
				                self.store.setData("$settingLogoutchangaccount", 'chang');
				            }
				            //记忆最后使用的服务代码及用户名
				          //  self.store.setData('$lastLoginInfo', loginData);

				          //  self.showMessageIonic(self.lang.logining);
				            self.sgClient.login(loginData, function (data) {//登录
				                if (data && data.state == 1) {//success
				            		alert(data);
				                } else if (data) {//登录失败，有返回错误信息
				                    self.hideMessageIonic();
				                    if (data.data == null || data.data == 'null') {
				                        self.showAlertIonic({text: "Error"});
				                    }
				                    else {
				                        self.showAlertIonic({text: data.data});
				                    }
				                }
				                else {//登录失败，没有返回错误信息
				                    self.hideMessageIonic();
				                    self.showAlertIonic({text: "Error"});
				                }
				            });
                }

         
    }]);