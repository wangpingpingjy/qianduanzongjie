angular.module('App', ['ionic'])

.config(function($ionicConfigProvider) {
  $ionicConfigProvider.tabs.style('striped').position('bottom');
})

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})
